from pathlib import Path, PurePosixPath
import hashlib,json,shutil,subprocess,zipfile,ntpath,stat,unicodedata
work=Path('/workspace/rc14-release-work'); dist=Path('/workspace/rc14-distribution');out=Path('/workspace/rc14-downloads');assert not out.exists();out.mkdir()
seal=json.loads((dist/'SEAL_INITIAL.json').read_text());stage=Path(seal['stage']);ev=dist/'evidence';assert json.loads((ev/'POST_TEST_INTEGRITY.json').read_text())['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sums(root):
 (root/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(root).as_posix()}\n' for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'SHA256SUMS.txt'))
def pack(root,target):
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():assert not p.is_symlink();z.write(p,p.relative_to(root).as_posix())
shutil.copy2(seal['archive'],out/Path(seal['archive']).name)
pack(stage/'course-creator-kit',out/'TRAINING_ENGINE_ONE_COURSE_CREATOR_KIT_RC1R14.zip')
hand=work/'standalone-handoff';assert not hand.exists();shutil.copytree(stage/'course-authoring-handoff',hand);shutil.copytree(stage/'course-creator-kit',hand/'course-creator-kit')
p=hand/'README_FIRST.md';p.write_text('# Standalone RC1R14 authoring handoff\n\nExtract the entire ZIP. The complete current kit is in course-creator-kit. From that directory run `node tools/validate-course.mjs examples/M1_GUIDED_ACCEPTANCE.course.zip`. No installation or network is needed for validation. The runtime is a separate download. Full mandatory master-prompt engineering is complete; owner Windows/classroom/assistive acceptance remains separate.\n\n'+p.read_text())
p=hand/'HANDOFF_MANIFEST.json';v=json.loads(p.read_text());v.update(registry='course-creator-kit/registry/activity-component-registry.json',portable_validator='course-creator-kit/tools/validate-course.mjs',publication_status='OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL');p.write_text(json.dumps(v,indent=2)+'\n');sums(hand);pack(hand,out/'TRAINING_ENGINE_ONE_COURSE_AUTHORING_HANDOFF_RC1R14.zip')
for name in ['M1_GUIDED_ACCEPTANCE.course.zip','M1_GUIDED_ACCEPTANCE_EN.course.zip','COURSE_CREATOR_CAPABILITY_TEST.course.zip']:shutil.copy2(stage/'authoring-kit/examples'/name,out/name)
extract=work/'companions';extract.mkdir();results=[]
for a in sorted(out.glob('*.zip')):
 with zipfile.ZipFile(a) as z:
  names=z.namelist();assert z.testzip() is None;assert len(names)==len(set(names))==len(set(unicodedata.normalize('NFC',n).casefold() for n in names))
  for i in z.infolist():
   n=i.filename;p=PurePosixPath(n);assert n and not p.is_absolute() and not ntpath.splitdrive(n)[0] and '\\' not in n and '..' not in p.parts and ':' not in n;assert not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1
  count=0
  for n in names:
   if PurePosixPath(n).name!='SHA256SUMS.txt':continue
   for line in z.read(n).decode().splitlines():
    h,r=line.split('  ',1);assert hashlib.sha256(z.read((PurePosixPath(n).parent/r).as_posix())).hexdigest()==h;count+=1
  if 'HANDOFF_RC1R14' in a.name or 'CREATOR_KIT_RC1R14' in a.name:z.extractall(extract/a.stem)
 results.append(dict(file=a.name,bytes=a.stat().st_size,sha256=sha(a),crc='PASS',safe_unique_paths='PASS',checksum_manifest_entries=count))
logs=[]
for base in [extract/'TRAINING_ENGINE_ONE_COURSE_CREATOR_KIT_RC1R14',extract/'TRAINING_ENGINE_ONE_COURSE_AUTHORING_HANDOFF_RC1R14/course-creator-kit']:
 samples=sorted((base/'examples').glob('*.course.zip'));assert len(samples)==6
 for sample in samples:
  r=subprocess.run(['node','tools/validate-course.mjs',str(sample.relative_to(base))],cwd=base,text=True,capture_output=True);logs.append(str(base)+' / '+sample.name+'\n'+r.stdout+r.stderr);assert r.returncode==0,logs[-1]
 for p in (stage/'course-creator-kit').rglob('*'):
  if p.is_file():assert p.read_bytes()==(base/p.relative_to(stage/'course-creator-kit')).read_bytes(),p
(ev/'COMPANION_VALIDATOR_OUTPUT.txt').write_text('\n'.join(logs));(ev/'COMPANION_VERIFICATION.json').write_text(json.dumps(dict(status='PASS',archives=results,portable_kit_files_identical=104,fresh_extracted_kit_and_handoff_samples_validated=12),indent=2)+'\n')
shutil.copy2('/workspace/training/docs/RC1R12_REQUIREMENTS.md',out/'RC1R12_REQUIREMENTS.md')
for p in Path('/workspace/training/docs').glob('*RC1R14*'):
 if p.is_file():shutil.copy2(p,out/p.name)
shutil.copytree(ev,out/'evidence');shutil.copy2(work/'DOWNLOADS.md',out/'DOWNLOADS.md')
report={'status':'PASS','release_status':'OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL','version':'3.5.0-rc.1.14','source_commit':seal['source_commit'],'mandatory_engineering_deferred':[],'source_and_exact_extraction':{'node_commands_each':67,'browser_programs_each':11,'syntax_files':160,'independent_pdf_reports_each':34},'companions':results,'owner_manual_acceptance':'UNRUN; Windows/LAN, classroom, visual and actual assistive technology acceptance remain an owner gate','cloud_restore':'Separate environment publication/fresh-task restore not inferred from these tests'}
(out/'SEAL_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');(out/'SEAL_REPORT.md').write_text('# RC1R14 complete engineering candidate\n\nAll mandatory attached-prompt engineering is implemented. Full source and fresh exact-archive extraction each pass 67 Node commands, ten browser programs, syntax/contract/kit checks and independent readers for 34 PDF reports. Creator closure passes 145 contracts and 96 API assertions; complete M1 branches run in both languages and delivery modes, plus two isolated Creator previews. All original extracted bytes and all nested checksum manifests were reverified after tests; the application ZIP is unchanged. Portable kit and standalone handoff each validate six samples and contain the same 104 kit files.\n\nSee SEAL_RESULT.json, RC1R14_REQUIREMENTS.md, validation report, and evidence for receipts. Owner real Windows/LAN/classroom/assistive acceptance is UNRUN; status is OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL.\n')
critical=['Explicit Finish from live and class list','Finish keeps partial learning and permits Trash','Personal language/theme/color across tabs/accounts/devices','Six colors plus role default with 12 contrast cases','Full-width selected Student class without rail','Compact LIVE / مباشر above hero','Complete all-role activity history 10/25/50','Inclusive local dates/type/search and scoped audit','All 36 activities and 68 result cases','Full original 91-section guided Creator/runtime scope','Permissions/privacy/reveal/migration/backup/restart/reconnect']
text='# RC1R14 complete personal workspace release\n\nPreserved baseline: 8f773a64300ec516860fa537051fb484997dd3e9 (RC1R13). Current version: 3.5.0-rc.1.14. Source commit: '+seal['source_commit']+'. Status: OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL. Workspace schema 6 is additive; core 3.2/course 2.0 remain compatible. Existing users, published versions and learning records are preserved.\n\nFinish class is visible in the live header and Classes, independent from Hold/Break/Finish section, including stuck practice and break. It closes open/suspended activity instances and preserves answers, partial progress, workflow history and drawings. Learner tasks are not fabricated complete. The class can then go to distinct Trash. Language/light-dark/panel colors belong to each account with server persistence and scoped pending local choices. The Student class uses the full width, no redundant side links, top workspace/profile access and green LIVE / مباشر above the hero. All roles have complete SQL-paged own activity, separately scoped staff audit and 10/25/50/type/local-date/search filters. The entire previous master-prompt implementation and beginner Creator remain included.\n\n| Engineering gate | Result |\n|---|---|\n'+''.join('| '+name+' | PASS |\n' for name in critical)+'\nSource and fresh exact-archive extraction each pass all 67 Node commands, 11 browser programs, 160 syntax files, canonical/104-file kit checks and independent readers for 34 PDFs. New API checks pass 222 assertions; new browser passes eight complete personal/finish/history/classroom journeys; the six inherited operational journeys also pass. Own-history tests include 135 own and 87 other-user events, real pagination/disjoint pages/date/type filters and role denial. All twelve actual palette light/dark contrast cases pass. Inherited Creator 145 contracts, 96 API assertions, 12 browser groups and eight complete M1 delivery/preview routes pass, plus 107 workspace checks, 640 font layouts and the 20-learner rehearsal. Full receipts are in evidence.\n\nEvery original extracted file and nested checksum manifest was reverified after preserving test-generated certification outputs; immutable application ZIP SHA-256 remains '+seal['sha256']+'. Both portable kit and standalone handoff validate all six samples from fresh extraction and match the same 104 kit files. Normal production startup passes version 14, eight pages and unauthenticated export/preferences/activity 401 with QA mode disabled and existing data retained. No mandatory engineering feature is deferred.\n\n| Download | SHA-256 |\n|---|---|\n'+''.join('| '+x['file']+' | `'+x['sha256']+'` |\n' for x in results)+'\nThe reports ZIP is assembled last; its final hash appears in external SHA256SUMS.txt and ARTIFACTS.json for all seven downloads. Reports contain actual source/extracted logs, diagnosed earlier harness failure, screenshots, complete requirements, security/upgrade/rollback notes and the manual checklist.\n\nOwner real Windows/LAN/classroom/visual/assistive acceptance remains UNRUN. This is not a universal bug-free or security certification. The server is required for fresh loads/uploads/confirmed navigation; applicable answers/edits and personal choices retain pending local state. Another device sees preferences after server confirmation. Already-open other same-account tabs apply language on reload to preserve unsaved work. Live history can shift offsets when new records arrive; Refresh obtains the current view. External tools need connectivity. Cloud publication/fresh-task restoration is separate.\n'
(out/'SEAL_REPORT.md').write_text(text)
reports=work/'reports';reports.mkdir()
for p in out.iterdir():
 if p.is_dir():shutil.copytree(p,reports/p.name)
 elif p.suffix!='.zip':shutil.copy2(p,reports/p.name)
sums(reports);pack(reports,out/'TRAINING_ENGINE_ONE_RC1R14_REPORTS.zip')
with zipfile.ZipFile(out/'TRAINING_ENGINE_ONE_RC1R14_REPORTS.zip') as z:
 assert z.testzip() is None;assert len(z.namelist())==len(set(x.casefold() for x in z.namelist()))
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
archives=sorted(out.glob('*.zip'));assert len(archives)==7
(out/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in archives));(out/'ARTIFACTS.json').write_text(json.dumps([dict(file=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in archives],indent=2)+'\n');print('DOWNLOADS_PASS seven ZIPs, twelve fresh portable validations; '+sha(out/Path(seal['archive']).name))
