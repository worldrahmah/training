# Seal evidence boundary

This archive contains the complete candidate application, working-tree test/browser evidence, screenshots, upgrade notes, limitations and owner checklist. Exact ZIP SHA-256 and fresh-extraction test outcomes are attested in the companion seal report after this immutable ZIP is produced. A ZIP cannot contain its own final SHA-256 without changing that hash. Do not substitute source-tree tests for exact-ZIP verification.

Source commit: bd1999eed31c0909b7cd21b4d7c4e8d28fa535bb
Status: OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL.
