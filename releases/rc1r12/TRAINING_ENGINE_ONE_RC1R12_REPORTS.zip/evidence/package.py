from pathlib import Path, PurePosixPath
import hashlib,json,shutil,subprocess,zipfile,ntpath,stat,unicodedata
work=Path('/workspace/rc12-release-work'); dist=Path('/workspace/rc12-distribution');out=Path('/workspace/rc12-downloads');assert not out.exists();out.mkdir()
seal=json.loads((dist/'SEAL_INITIAL.json').read_text());stage=Path(seal['stage']);ev=dist/'evidence';assert json.loads((ev/'POST_TEST_INTEGRITY.json').read_text())['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sums(root):
 (root/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(root).as_posix()}\n' for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'SHA256SUMS.txt'))
def pack(root,target):
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():assert not p.is_symlink();z.write(p,p.relative_to(root).as_posix())
shutil.copy2(seal['archive'],out/Path(seal['archive']).name)
pack(stage/'course-creator-kit',out/'TRAINING_ENGINE_ONE_COURSE_CREATOR_KIT_RC1R12.zip')
hand=work/'standalone-handoff';assert not hand.exists();shutil.copytree(stage/'course-authoring-handoff',hand);shutil.copytree(stage/'course-creator-kit',hand/'course-creator-kit')
p=hand/'README_FIRST.md';p.write_text('# Standalone RC1R12 authoring handoff\n\nExtract the entire ZIP. The complete current kit is in course-creator-kit. From that directory run `node tools/validate-course.mjs examples/M1_GUIDED_ACCEPTANCE.course.zip`. No installation or network is needed for validation. The runtime is a separate download. Full mandatory master-prompt engineering is complete; owner Windows/classroom/assistive acceptance remains separate.\n\n'+p.read_text())
p=hand/'HANDOFF_MANIFEST.json';v=json.loads(p.read_text());v.update(registry='course-creator-kit/registry/activity-component-registry.json',portable_validator='course-creator-kit/tools/validate-course.mjs',publication_status='OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL');p.write_text(json.dumps(v,indent=2)+'\n');sums(hand);pack(hand,out/'TRAINING_ENGINE_ONE_COURSE_AUTHORING_HANDOFF_RC1R12.zip')
for name in ['M1_GUIDED_ACCEPTANCE.course.zip','M1_GUIDED_ACCEPTANCE_EN.course.zip','COURSE_CREATOR_CAPABILITY_TEST.course.zip']:shutil.copy2(stage/'authoring-kit/examples'/name,out/name)
extract=work/'companions';extract.mkdir();results=[]
for a in sorted(out.glob('*.zip')):
 with zipfile.ZipFile(a) as z:
  names=z.namelist();assert z.testzip() is None;assert len(names)==len(set(names))==len(set(unicodedata.normalize('NFC',n).casefold() for n in names))
  for i in z.infolist():
   n=i.filename;p=PurePosixPath(n);assert n and not p.is_absolute() and not ntpath.splitdrive(n)[0] and '\\' not in n and '..' not in p.parts and ':' not in n;assert not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1
  count=0
  for n in names:
   if PurePosixPath(n).name!='SHA256SUMS.txt':continue
   for line in z.read(n).decode().splitlines():
    h,r=line.split('  ',1);assert hashlib.sha256(z.read((PurePosixPath(n).parent/r).as_posix())).hexdigest()==h;count+=1
  if 'HANDOFF_RC1R12' in a.name or 'CREATOR_KIT_RC1R12' in a.name:z.extractall(extract/a.stem)
 results.append(dict(file=a.name,bytes=a.stat().st_size,sha256=sha(a),crc='PASS',safe_unique_paths='PASS',checksum_manifest_entries=count))
logs=[]
for base in [extract/'TRAINING_ENGINE_ONE_COURSE_CREATOR_KIT_RC1R12',extract/'TRAINING_ENGINE_ONE_COURSE_AUTHORING_HANDOFF_RC1R12/course-creator-kit']:
 samples=sorted((base/'examples').glob('*.course.zip'));assert len(samples)==6
 for sample in samples:
  r=subprocess.run(['node','tools/validate-course.mjs',str(sample.relative_to(base))],cwd=base,text=True,capture_output=True);logs.append(str(base)+' / '+sample.name+'\n'+r.stdout+r.stderr);assert r.returncode==0,logs[-1]
 for p in (stage/'course-creator-kit').rglob('*'):
  if p.is_file():assert p.read_bytes()==(base/p.relative_to(stage/'course-creator-kit')).read_bytes(),p
(ev/'COMPANION_VALIDATOR_OUTPUT.txt').write_text('\n'.join(logs));(ev/'COMPANION_VERIFICATION.json').write_text(json.dumps(dict(status='PASS',archives=results,portable_kit_files_identical=103,fresh_extracted_kit_and_handoff_samples_validated=12),indent=2)+'\n')
for p in Path('/workspace/training/docs').glob('*RC1R12*'):
 if p.is_file():shutil.copy2(p,out/p.name)
shutil.copytree(ev,out/'evidence');shutil.copy2(work/'DOWNLOADS.md',out/'DOWNLOADS.md')
report={'status':'PASS','release_status':'OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL','version':'3.5.0-rc.1.12','source_commit':seal['source_commit'],'mandatory_engineering_deferred':[],'source_and_exact_extraction':{'node_commands_each':64,'browser_programs_each':9,'syntax_files':149,'independent_pdf_reports_each':34},'companions':results,'owner_manual_acceptance':'UNRUN; Windows/LAN, classroom, visual and actual assistive technology acceptance remain an owner gate','cloud_restore':'Separate environment publication/fresh-task restore not inferred from these tests'}
(out/'SEAL_RESULT.json').write_text(json.dumps(report,indent=2)+'\n');(out/'SEAL_REPORT.md').write_text('# RC1R12 complete engineering candidate\n\nAll mandatory attached-prompt engineering is implemented. Full source and fresh exact-archive extraction each pass 64 Node commands, nine browser programs, syntax/contract/kit checks and independent readers for 34 PDF reports. Creator closure passes 145 contracts and 96 API assertions; complete M1 branches run in both languages and delivery modes, plus two isolated Creator previews. All original extracted bytes and all nested checksum manifests were reverified after tests; the application ZIP is unchanged. Portable kit and standalone handoff each validate six samples and contain the same 103 kit files.\n\nSee SEAL_RESULT.json, RC1R12_REQUIREMENTS.md, validation report, and evidence for receipts. Owner real Windows/LAN/classroom/assistive acceptance is UNRUN; status is OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL.\n')
critical=['Prompt renderer','Prompt Copy','Participant Choice Cards','Branch A','Branch B','Convergence','Evaluation','Resume','Arabic RTL','English LTR','Mobile','Creator exact-runtime preview','Semantic validation','Legacy demos','Full production runtime']
text='# RC1R12 full closure report\n\n## Baseline and current version\n\nPreserved continuation baseline: 925dab16f2ffcbd8bed44aa334641843e120b45d (RC1R11 artifacts; source 7728bd70e8ec623a7b9227205f4f53252c3c7f09). The latest supplied RC1R10 was recovered at 8a55bde1b93d67e84116135cbbef304986915307 before that continuation. Current version:3.5.0-rc.1.12. Source commit:'+seal['source_commit']+'. Status:OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL. Core schema3.2; course schema2.0; no reset.\n\n## Major changes\n\nComplete Creator block/property authoring, shared steps and typed variables/conditions, explicit branching/convergence, full route analysis and repair, exact guided preview, twelve prioritized embedded interactions and evaluations, file/image evidence, durable account-scoped reconnect with stale conflict review, participant-paced history and independence, guided reports and asset-aware publication/export validation. Running-class hero/current-task focus, closed secondary dashboard sections and recoverable course/class deletion are retained. See RC1R12_CHANGELOG.md and the91-section trace.\n\n## Critical acceptance results\n\n| Capability | Automated result |\n|---|---|\n'+''.join('| '+name+' | PASS |\n' for name in critical)+'\nFull production runtime means the built-in Node source, startup, syntax, canonical drift and full runtime/browser tests; this application defines no compilation/build script. Automated production evidence is in evidence/PRODUCTION_READINESS.json.\n\n## Validation\n\nSource and fresh exact-archive extraction each pass64 Node commands,9 browser programs,149 syntax files, canonical contract/103-file kit drift and independent readers for34 PDF reports. Creator passes145 contracts,96 API assertions and12 browser groups. Complete M1 passes6 delivery routes plus2 isolated previews. All original extracted files and nested checksum manifests are reverified after preserving generated certification reports; application ZIP SHA-256 stays unchanged. Fresh standalone kit/handoff each validate6 samples and contain identical103-file kit bytes.\n\n## Returned files\n\n| File | SHA-256 |\n|---|---|\n'+''.join('| '+x['file']+' | `'+x['sha256']+'` |\n' for x in results)+'\nThe reports ZIP is created after this report; its own final hash is in the external SHA256SUMS.txt and ARTIFACTS.json alongside all seven downloads.\n\n## Known limitations\n\nOwner Windows/LAN/classroom/visual/actual assistive-technology acceptance is UNRUN. Do not call this FINAL. The local server is required for uploads, fresh page loads and confirmed navigation; the durable outbox retains applicable edits/answers. External tools need their own connectivity. No mandatory engineering feature is deferred. Specialized/team/media responses use their canonical dedicated activities, and no arbitrary loop engine is introduced. Cloud settings publication/fresh-task restore is separate.\n'
(out/'SEAL_REPORT.md').write_text(text)
reports=work/'reports';reports.mkdir()
for p in out.iterdir():
 if p.is_dir():shutil.copytree(p,reports/p.name)
 elif p.suffix!='.zip':shutil.copy2(p,reports/p.name)
sums(reports);pack(reports,out/'TRAINING_ENGINE_ONE_RC1R12_REPORTS.zip')
with zipfile.ZipFile(out/'TRAINING_ENGINE_ONE_RC1R12_REPORTS.zip') as z:
 assert z.testzip() is None;assert len(z.namelist())==len(set(x.casefold() for x in z.namelist()))
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
archives=sorted(out.glob('*.zip'));assert len(archives)==7
(out/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in archives));(out/'ARTIFACTS.json').write_text(json.dumps([dict(file=p.name,sha256=sha(p),bytes=p.stat().st_size) for p in archives],indent=2)+'\n');print('DOWNLOADS_PASS seven ZIPs, twelve fresh portable validations; '+sha(out/Path(seal['archive']).name))
