from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path('/workspace/training');w=Path('/workspace/rc12-release-work')
assert 'CHECKS_PASS node: 64 commands' in Path('/tmp/rc12-frozen-node-v3.log').read_text();assert 'CHECKS_PASS browser: 9 commands' in Path('/tmp/rc12-frozen-browser-v3.log').read_text()
assert json.loads(Path('/workspace/rc12-source-evidence-v3/PDF_READER_RESULT.json').read_text())['status']=='PASS'
for name in ['release/version.json','RELEASE_MANIFEST.json','course-authoring-handoff/HANDOFF_MANIFEST.json']:
 p=r/name;v=json.loads(p.read_text())
 for k in ['release_status','publication_status']:
  if k in v:v[k]='OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL'
 p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/RC1R12_REQUIREMENTS.json';v=json.loads(p.read_text());v['engineering_status']='IMPLEMENTED_SOURCE_VERIFIED';v['immutable_gate']='Exact sealed ZIP evidence is attested in the companion SEAL_RESULT.json after fresh-extraction repetition; never inferred from source tests.'
for row in v['sections']:
 if row['status']!='OWNER_MANUAL_GATE':row['status']='IMPLEMENTED_SOURCE_VERIFIED'
p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/RC1R12_REQUIREMENTS.md';s=p.read_text().replace('Mandatory engineering scope is implemented; release verification is in progress.','Mandatory engineering scope is implemented and the complete source gates pass. Exact immutable-archive gates are attested by the release companion after fresh-extraction repetition.');p.write_text(s)
p=r/'RELEASE_MANIFEST.json';v=json.loads(p.read_text());v.update(manual_gate='docs/RC1R12_ACCEPTANCE.md',test_output='docs/verification/rc1r12/SOURCE_NODE_OUTPUT.txt',security_review='docs/RC1R12_SECURITY_REVIEW.md',known_limitations='docs/KNOWN_LIMITATIONS_RC1R12.md',current_requirements_trace='docs/RC1R12_REQUIREMENTS.json',current_browser_evidence='docs/verification/rc1r12/SOURCE_BROWSER_OUTPUT.txt',current_scope='Full mandatory Core Creator and Participant Guided Experience closure; running-class focus and recoverable deletion retained',preserved_continuation_baseline='925dab16f2ffcbd8bed44aa334641843e120b45d');p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(w/'VALIDATION_SOURCE.md',r/'docs/RC1R12_VALIDATION_REPORT.md')
p=r/'README.md';s=p.read_text().replace('Current release checks are in progress; this is not FINAL owner acceptance.','Full source checks pass; exact-archive results are attested in the release companion. This is an owner-acceptance candidate.');p.write_text(s)
p=r/'docs/CODEX_EXEC_PLAN.md';s=p.read_text()+'\n### RC1R12 final source gate PASS\n\nLatest frozen v3 passes all64 Node commands, all9 browser programs, syntax149, contract/103-file kit drift, and independent PDF readers34. Creator12 groups and M1 six delivery plus two isolated previews pass. Complete browser includes640 global-font layout cases and inherited role/data/lifecycle checks. Source is ready to commit and seal; exact immutable extraction still must repeat all gates before any download delivery. No mandatory engineering feature remains deferred. Owner manual acceptance stays unrun.\n';p.write_text(s)
shots=r/'docs/verification/rc1r12';shots.mkdir(parents=True,exist_ok=True)
for source_file,name in [('/tmp/rc12-frozen-node-v3.log','SOURCE_NODE_OUTPUT.txt'),('/tmp/rc12-frozen-browser-v3.log','SOURCE_BROWSER_OUTPUT.txt'),('/tmp/rc12-syntax-v3.log','SOURCE_SYNTAX_RESULT.json'),('/tmp/rc12-contracts-v3.log','SOURCE_CONTRACT_OUTPUT.txt'),('/workspace/rc12-source-evidence-v3/PDF_READER_RESULT.json','SOURCE_PDF_READER_RESULT.json')]:shutil.copy2(source_file,shots/name)
source=Path('/workspace/rc12-source-evidence-v3/browser')
for pattern in ['choice-*.png','prompt-*.png','evaluation-*.png','completion-*.png','creator-*.png']:
 for p in source.glob(pattern):shutil.copy2(p,shots/p.name)
subprocess.run(['node','tools/sync-contracts.mjs','--write'],cwd=r,check=True);subprocess.run(['node','tools/build-course-creator-kit.mjs'],cwd=r,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hand=r/'course-authoring-handoff';(hand/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(hand).as_posix()}\n' for p in sorted(hand.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt'))
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0');files=sorted(x for x in files if x and x!='SHA256SUMS.txt' and x.split('/')[0]!='releases' and (r/x).is_file());(r/'SHA256SUMS.txt').write_text(''.join(f'{sha(r/p)}  {p}\n' for p in files));print('FINAL_SOURCE_READY',len(files)+1)
