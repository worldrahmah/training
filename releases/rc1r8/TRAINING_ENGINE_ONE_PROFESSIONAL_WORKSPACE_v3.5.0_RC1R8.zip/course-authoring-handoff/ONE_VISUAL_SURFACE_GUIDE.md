# ONE Visual Surface Guide for External Course Authors

Courses target one canonical runtime but appear on distinct surfaces. Author content with those surfaces in mind.

## Projector
Use concise headings, room-scale text, strong visual hierarchy and minimal paragraphs. Projector content is presentation content, not a document.

## Participant
Provide actionable instructions, short prompts, clear choices and phone-friendly content. The participant surface should never require knowledge of trainer/admin terminology.

## Trainer Live Classroom
Private presenter notes may include talking points, expected answers, common mistakes, demo instructions, timing guidance and transition notes. These are not shown to participants or the Projector.

## Course Builder and Preview
All authored content must validate against the canonical ONE schemas and capability catalog. Do not rely on custom HTML/CSS or remote visual dependencies.

## Arabic and English
Treat both directions as native presentations. Avoid layouts that only make sense left-to-right. Keep labels concise enough to survive both English and Arabic UI expansion.
