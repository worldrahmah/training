# ExecPlan — RC1R9 branding, localization, authoring and security

Baseline: release/rc1r8-test commit db640e1047f210856a7b23d6ff5e469ffd10b89e, app 3.5.0-rc.1.8, core schema 3.2, course schema 2.0; 36 canonical activity IDs and 68 result-view cases. Existing AGENTS.md and .agent/PLANS.md read. Initial unchanged npm test encountered a 5-second startup timeout in backup-restore during concurrent browser load; the isolated test passed, and a serial baseline rerun is recorded. Browser baseline exposed an immediate focus assertion racing requestAnimationFrame after ArrowDown; use Playwright's eventual focus assertion, retain the keyboard requirement.

Architecture: extend shared core UI and canonical registry; reuse existing validated owner logo upload and backup storage. Labels are presentation metadata, never rewritten authored titles/IDs. Production bootstrap uses a private random initial password, explicit disposable QA mode retains test accounts, and legacy known defaults require local password replacement. Preserve database content and existing hashed passwords; no schema change. Strengthen HTTP/request/file boundaries with negative integration tests. Generate a self-contained Course Creator kit from the canonical runtime and registry, with executable validation, examples and milestone checkpoints.

Milestones / validation:
1. Baseline: HOST=127.0.0.1 npm test; npm run test:browser; inspect failures before edits. Capture logs outside checkout.
2. Shared logo + 36 bilingual display labels + account/security protections. node tests/rc1r9-security.mjs; node tests/rc1r9-contract.mjs; python tests/browser-rc1r9.py. Preserve all role APIs and classroom behavior except documented security denials.
3. Six current role/language guides; generated kit covering 36 activities, runtime schemas, content/results, workflows/private cues, assets, importable examples, intake and starting/final prompts. node tools/build-course-creator-kit.mjs --check; npm run contracts:check; import examples through runtime; validate negative examples.
4. Full Node/four existing browsers/new browser/PDF/static checks. EN/AR, light/dark/system, desktop/tablet/mobile, 16:9 Projector. Migration/restart/backup and certification remain required. Inspect screenshots.
5. Update release identity, evidence, security audit/limitations/owner acceptance; commit source; seal ZIP, check all hashes/CRC/paths; fresh extract and run same suites. Never alter sealed ZIP. Publish exact tested bytes plus SHA and seal evidence to GitHub.

Data/rollback: no schema migration or destructive reset. Existing users, courses, classes, content, IDs and passwords remain. Startup adds account-control flags only for unchanged known default hashes, invalidating their old sessions; owner changes password locally or administrator resets it. Existing configured file paths preserved. Use verified RC1R8 backups for rollback; protect private bootstrap credentials as local state, never package them. Course schemas 1.0/1.1/2.x and historical definitions remain unchanged.

Risks / non-goals: public LAN HTTP lacks transport encryption; use trusted LAN or owner TLS termination. No claims of formal penetration certification, SSO/MFA, tenant isolation or malware scanning. QA bootstrap opt-in must never be enabled on production state. Course resource access and user uploads require explicit audience/security handling. Owner Windows, LAN and final visual acceptance are pending manual gates. No rebranding of authored course text.

Decision log: testing exposed a pre-existing Draft clone defect (assets were omitted). RC1R9 copies checksummed source assets independently in a transaction and fails without overwriting an existing asset folder; new tests verify import/publication and source immutability. Encrypted portable backup decode is bounded to 512 MiB expanded JSON with authenticated metadata/path/collision validation; 14 scenarios pass; existing filesystem backup/restore remains available for larger state. Security audit also closed implicit-active-class privileged access by unassigned Trainers. Historical default-password setup additionally rejects forwarded requests and non-loopback Host names; a raw HTTP test verifies the Host boundary (fetch may normalize Host). Browser baseline timing assertions use eventual focus checks under unchanged CSP. The Ideas Board source inventory assertion now expects the corrected display name; runtime/role assertions remain unchanged. No schema change. Scope explicitly authorizes source/test/schema/docs changes and GitHub deliverable; onboarding-only tracked-file protection no longer applies. Use existing checkout, no worktree. No delegated agent work requested or used.

Progress: unchanged serial baseline Node suite passed (all RC1R8 commands). Initial concurrent run failed backup startup timeout; isolated backup and serial full rerun passed. Baseline browser repair suite passed, workspace suite failed immediate focus assertion; same focus requirement now waits for asynchronous UI outcome. Shared logo/36 bilingual labels and security/account groundwork implemented; dedicated security tests pass 78 assertions, kit/label/import/publication tests pass 326, six role-language guides and a deterministic 91-file kit are complete. Current full Node gate passes all 58 commands including 36/68 certification; new browser gate passes 52 visits. Five browser suites pass: repair 12 role/locale visits; workspace 107 view checks; workspace upgrade 12 gates; font matrix 640 layout cases; RC1R9 52 visits. PDF reader inspection passes 34 reports. Static syntax passes 120 files. Final full working-tree Node (58 commands), all five browser suites, 34 PDF reader reports, static syntax and canonical/kit drift checks pass. Current evidence is committed under docs/verification/rc1r9. Implementation is frozen; seal/fresh-extraction/retest/publication are the remaining gates. Owner continuation contract persisted in PROJECT_OPERATING_RULES.md and linked from AGENTS.md; no reset or worktree. Current branch release/rc1r9-test. Evidence: /tmp/rc1r9-baseline-node-retry.log and /tmp/rc1r9-baseline-browser.log. Runtime Node 24.19.0, Python 3.12.14, Playwright 1.62.0 and system Chromium.

---

# RC1R8 approved enterprise workspace milestone

Baseline: RC1R7 source/distribution commit 19dbfc36d0fad0175f386d3aaec4129d6e846cdd. Unchanged complete npm test passed (50 commands /49 programs) before modifications; output outside source at /workspace/one-review/rc1r8/BASELINE_TEST_OUTPUT.txt. Owner reports reopen manual acceptance.

Decisions and pre-migration impact: RC1R8_APPROVED_SCOPE_AND_MIGRATION.md. Registered-account-only code admissions confirmed separately. No school features, tenancy or rebuild. Extend the existing declarative authoring registry, scoped local-first runtime and separate role surfaces.

Milestones: (1) enrollment/deletion/diagnostics/layout/drill-down repairs; (2) journaled additive data migrations, Editor isolation/publishing, groups/admission/inbox/profiles/archive/audit/bulk previews; (3) 40 licensed local fonts and seven direct PDF report templates; (4) full working-tree regression/browser/persisted migration and PDF checks; immutable seal/fresh-extract/full retest/publication. Tests: npm test, npm run test:browser plus new operational/migration/report/font/role browser suites; node --check and canonical drift checks. Stop and repair each failed gate.

Acceptance: meaningful create/edit/re-add/approve/reject/archive/restore/export interactions and negative authorization assertions, retained history, every role EN/AR light/dark/system desktop/tablet/mobile, all fonts against long text/control metrics and Arabic shaping, PDF multi-page/logo/fonts/charts. Keep 36 activities/68 result cases, backup/restart/legacy migration evidence. Owner Windows/projector visual acceptance remains the FINAL gate.

Risks: staff CHECK widening, admission uniqueness/capacity/races, group scope leakage, course-editor legacy-route bypass, profile/logo assets in backup, bundled font/PDF dependencies and Arabic text shaping. Preserve baseline artifacts and pre-upgrade data backup; rollback limitations explicit. Source inspection/test ledger will distinguish actual review from inventory. Do not publish PASS with known defects.

Progress: baseline and implementation complete. Stateful operations (including stale/capacity/restore cases), 40-font proof, 34 PDF compatibility cases and three real browser suites pass. Source regression was repaired for the approved guest/admission, withdrawn-roster and configurable-font contracts. Complete working-tree Node/four-browser/PDF/static gates passed. Immutable seal/fresh-extraction/retest and publication are in progress. Owner Windows/Projector acceptance remains pending.

---

# ExecPlan — RC1R7 product experience and operational review

Owner scope: substantially improve the visible interface and deeply review existing feature/tool logic against enterprise operation. Screenshots identify crowded Builder controls, participant navigation, light-theme contrast, Arabic punctuation and confusing staff administration. RC1R6 is the preserved baseline; its complete suite passed again before changes (47 commands / 46 programs). No school-domain/schema expansion is assumed.

RC1R7 target: one accessible disclosure component for account/tools/context actions; a cohesive theme-driven design across entry, Admin, Trainer, Builder, Live and Participant; self-contained multilingual paragraphs; clear staff ownership; transactional, fail-closed staff changes; scope checks on course tools and search; truthful learning indicators. Preserve the existing canonical registry, course IDs, supported workflows, scoring, Projector privacy and data.

Stages and gates:
1. Inspect role screens, tool handlers and API/data boundaries. Record inspected vs indexed feature coverage and authoritative W3C/OWASP references. Reproduce reported issues and audit denied-write behavior.
2. Redesign shared navigation and affected role layouts. Correct staff administration and authorization defects. Add executable regression checks for denied operations and real-browser checks for interaction, contrast and punctuation.
3. Complete Node regression, syntax/contract checks, and EN/AR light/dark/system desktop/tablet/mobile browser review; inspect screenshots and repair findings. Verify real create/update/export/calendar operations, not just page loading.
4. Update release identity, guide, audit ledger, limitations and owner checklist. Seal clean application bytes without embedding earlier release distributions; freshly extract, verify CRC/path/checksums and rerun full suites. Publish exact test candidate ZIP on GitHub after successful verification.

Database impact: no new schema is planned. Existing tables and historical data remain authoritative. Staff mutation changes are transactional and retain at least one active super administrator. Role/session revocation preserves user/content/history while retiring authorization sessions. Negative authorization tests use disposable populated databases. Any later schema proposal requires a migration-impact document first.

Architecture decisions: extend the current local-first product; do not replace it or add a cloud dependency. Admin means authorized administrator or super administrator; system-wide permission grants remain protected. Ordinary trainers cannot provision staff. Course-language direction and application-language direction remain independent. Dropdowns use native popovers with keyboard support and truthful existing actions. No arbitrary executable course behavior is introduced.

Acceptance matrix: all existing Node functional suites including 36 activities/68 result cases, historic migration, restart, backups and rehearsal. Browser review covers each management page, all entry screens, Builder operations, participant saved response, Live/Projector, 1440/768/390 widths, EN/AR and light/dark/system. New checks cover readable menu/login controls, popup containment, actual staff creation, forbidden elevation with no partial writes, protected super-admin accounts, scoped course tools, authenticated calendar, and visual Arabic sentence-ending order inside LTR courses.

Known boundaries: owner visual acceptance remains a release gate. This stage does not certify SSO/MFA, multi-tenant isolation, regulated safeguarding, high-volume deployment or every school domain. Maintain an explicit enterprise gap register and distinguish indexed handlers from functionally verified paths.

Historical RC1R6 record follows.

Baseline: verified RC1R5 SHA-256 0262559de4464712888734e1addfbcd3de2b178822d1a188641e22daf8f24016; full unchanged suite passed (44 commands/43 programs, 36 activities/68 result views). Imported exact source into the existing empty checkout; pristine upload is retained outside it. Owner authorized baseline repairs and exceptional UI/UX. No worktree or remote push.

Target: explicit audience projections preserving required response choices while withholding Trainer guidance and solution mappings; server-authorized cohort analytics; verified bounded ZIP import; truthful Admin rendering/export; coherent accessible dialogs, readable constrained charts and actual local Montserrat/Cairo assets. Evolve existing Core, preserve roles and classroom identity.

Milestones:
1. Privacy/authorization/import fixes. New negative runtime/ZIP gates plus existing assessment/activity/scoring/variant gates.
2. Admin/export and affected UX. Real browser page/discovery/download/chart/keyboard/EN-AR and responsive checks.
3. Full npm test, browser repair tests, syntax checks, migration/restart/backup and 36/68 certification.
4. New release identity/contracts/notes; clean distribution; all checksums; seal; fresh exact-byte extraction and full suite/browser checks again; seal report, limitations, owner checklist and exact SHA-256.

Database: no schema migration planned. Runtime tests use external disposable data/storage. Existing course schemas 1.0/1.1/2.0, IDs, versions and stored definitions remain unchanged. Audience response projections may change where prior behavior disclosed private answers. Scoring remains server-side; tests inspect privileged/post-reveal evidence rather than a pre-reveal scoring oracle. Rollback: retain original RC1R5 artifact and verified database/storage backups.

Experience matrix: EN/LTR/Montserrat, AR/RTL/Cairo; light/dark; desktop/tablet/mobile; Projector 16:9 dark/light/high contrast; keyboard focus containment/return; visible named controls; honest loading/empty/error/zero states and chart table equivalents.

Risks: keep matching choices usable without associations, image labels without coordinates, path state and post-reveal feedback. Do not silently weaken scoring assertions. Non-goals: school schema/features, global rewrite, external ranking claims. School scope awaits owner decisions. Baseline code and historical archives are preserved.

Progress: imported baseline, repairs, full regression, syntax and browser gates complete. Exact candidate sealing/retest is the remaining gate; owner visual acceptance remains pending.

RC1R7 implementation and role-view exploration complete. Added current guides, official-source snapshots and honest feature/API ledgers. No schema migration. Complete final working-tree Node (50 commands / 49 programs) and browser suites passed. Exact sealed-ZIP retest and publication remain; owner acceptance is a separate gate.
