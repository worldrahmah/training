from pathlib import Path
import json,shutil,subprocess,hashlib
r=Path('/workspace/training');d=Path('/workspace/rc13-distribution');e=d/'evidence';w=Path('/workspace/rc13-release-work');root=Path('/workspace/rc13-exact-verification')
assert 'CHECKS_PASS node: 65 commands' in (e/'EXTRACTED_NODE_OUTPUT.txt').read_text()
assert 'CHECKS_PASS browser: 10 commands' in (e/'EXTRACTED_BROWSER_OUTPUT.txt').read_text()
assert json.loads((e/'EXTRACTED_PDF_READER_RESULT.json').read_text())['status']=='PASS'
assert json.loads((e/'EXTRACTED_SYNTAX_RESULT.json').read_text())['syntax_files']==153
assert 'CONTRACT_SYNC_PASS' in (e/'EXTRACTED_CONTRACT_OUTPUT.txt').read_text()
assert 'COURSE_CREATOR_KIT_CHECK_PASS 104 files' in (e/'EXTRACTED_KIT_OUTPUT.txt').read_text()
shutil.copytree(root/'.test-evidence',e/'browser-exact')
for name in ['finalize-source.py','seal-and-extract.py','finalize.py','package.py','finish-release.py']:shutil.copy2(w/name,e/name)
subprocess.run(['python',str(w/'finalize.py')],check=True)
v=json.loads((e/'POST_TEST_INTEGRITY.json').read_text());digest=v['archive_sha256_unchanged'];seal=json.loads((d/'SEAL_INITIAL.json').read_text())
p=r/'docs/RC1R13_REQUIREMENTS.json';x=json.loads(p.read_text());x['engineering_status']='IMPLEMENTED_VERIFIED';x['immutable_gate']={'status':'PASS','sha256':digest,'source_commit':seal['source_commit'],'original_files_reverified':v['original_files_verified_after_tests'],'node_commands_each':65,'browser_programs_each':10,'syntax_files':153,'kit_files':104,'independent_pdf_reports_each':34}
for row in x['sections']:
 if row['status']!='OWNER_MANUAL_GATE':row['status']='IMPLEMENTED_VERIFIED'
x['owner_operational_corrections']['status']='IMPLEMENTED_VERIFIED';p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/RC1R13_REQUIREMENTS.md';p.write_text(p.read_text().replace('exact immutable-archive gates are attested by the companion after fresh-extraction repetition','the complete exact immutable-archive gates also pass, with actual receipts in the companion'))
receipt='\nFinal immutable-extraction receipt: PASS. The exact sealed application repeats all 65 Node commands, 10 browser programs, 153 syntax files, canonical/104-file kit drift and independent PDF readers for 34 reports. All '+str(v['original_files_verified_after_tests'])+' original files and every manifest entry reverify after preserving the four generated certification reports. Application ZIP SHA-256 remains `'+digest+'`. Source commit: '+seal['source_commit']+'. The companion contains actual logs/screenshots and post-test integrity JSON. Normal startup version 13 passes eight HTML routes and unauthenticated export 401 with existing data retained and QA mode disabled.\n'
p=r/'docs/RC1R13_VALIDATION_REPORT.md';p.write_text(p.read_text()+receipt)
p=r/'docs/CODEX_EXEC_PLAN.md';p.write_text(p.read_text()+'\n### RC1R13 exact immutable release PASS\n'+receipt+'\nStandalone companion packaging and remote artifact verification finish delivery. Owner Windows/LAN/classroom/assistive acceptance and fresh cloud publication/restoration remain separate unrun gates. No mandatory engineering feature is deferred.\n')
p=r/'RELEASE_MANIFEST.json';m=json.loads(p.read_text());m['exact_zip_verification']={'status':'PASS','sha256':digest,'source_commit':seal['source_commit'],'files':v['original_files_verified_after_tests'],'receipt':'releases/rc1r13/SEAL_RESULT.json'};p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['python',str(w/'package.py')],check=True)
out=Path('/workspace/rc13-downloads');dest=r/'releases/rc1r13';assert not dest.exists();dest.mkdir(parents=True)
for p in out.iterdir():
 if p.is_file():shutil.copy2(p,dest/p.name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0');files=sorted(n for n in files if n and n!='SHA256SUMS.txt' and not n.startswith('releases/') and (r/n).is_file());(r/'SHA256SUMS.txt').write_text(''.join(f'{sha(r/n)}  {n}\n' for n in files))
print('FULL_RC1R13_RELEASE_PACKAGED',digest)
