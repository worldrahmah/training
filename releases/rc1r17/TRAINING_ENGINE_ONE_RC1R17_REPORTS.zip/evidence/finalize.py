from pathlib import Path
import hashlib,json,shutil,zipfile
out=Path('/workspace/rc17-distribution');e=out/'evidence';root=Path('/workspace/rc17-exact-verification')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'CHECKS_PASS node: 72 commands' in (e/'EXTRACTED_NODE_OUTPUT.txt').read_text()
assert 'CHECKS_PASS browser: 15 commands' in (e/'EXTRACTED_BROWSER_OUTPUT.txt').read_text()
assert json.loads((e/'EXTRACTED_PDF_READER_RESULT.json').read_text())['status']=='PASS'
assert json.loads((e/'EXTRACTED_SYNTAX_RESULT.json').read_text())['syntax_files']==186
assert 'CONTRACT_SYNC_PASS' in (e/'EXTRACTED_CONTRACT_OUTPUT.txt').read_text()
original=json.loads((e/'ARCHIVE_VERIFICATION.json').read_text());changed=[r for r,h in original['initial_file_hashes'].items() if sha(root/r)!=h]
expected={'docs/ACTIVITY_CERTIFICATION_MATRIX.json','docs/ACTIVITY_CERTIFICATION_MATRIX.md','docs/ACTIVITY_CERTIFICATION_RUNTIME_RESULT.json','docs/ACTIVITY_SURFACE_COVERAGE.json'};assert set(changed)<=expected,changed
preserved=e/'current-certification';preserved.mkdir(exist_ok=True);archive=out/'TRAINING_ENGINE_ONE_v3.5.0_RC1R17.zip'
with zipfile.ZipFile(archive) as z:
 for r in sorted(expected):
  shutil.copyfile(root/r,preserved/Path(r).name)
  if r in changed:(root/r).write_bytes(z.read(r))
 for r,h in original['initial_file_hashes'].items():assert sha(root/r)==h,r
 checked=0
 for manifest in root.rglob('SHA256SUMS.txt'):
  if manifest.relative_to(root).as_posix() not in original['initial_file_hashes']:continue
  for line in manifest.read_text().splitlines():h,r=line.split('  ',1);assert sha(manifest.parent/r)==h,r;checked+=1
assert sha(archive)==original['sha256']
result=dict(status='PASS',original_files_verified_after_tests=len(original['initial_file_hashes']),generated_certification_files_preserved=sorted(expected),changed_files_restored_from_immutable_archive=changed,checksum_manifest_entries_reverified=checked,archive_sha256_unchanged=original['sha256'])
(e/'POST_TEST_INTEGRITY.json').write_text(json.dumps(result,indent=2)+'\n');print('POST_TEST_INTEGRITY_PASS',len(original['initial_file_hashes']),checked)
