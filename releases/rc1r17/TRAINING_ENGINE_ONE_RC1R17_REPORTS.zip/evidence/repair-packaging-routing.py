from pathlib import Path
import json,shutil,subprocess,hashlib
r=Path('/workspace/training');w=Path('/workspace/rc17-work');e=Path('/workspace/rc17-distribution/evidence')
for name in ['seal-and-extract.py','finish-release.py','package.py','verify-remote.py','discover-final.py']:
 p=w/name;s=p.read_text().replace('rc1r16','rc1r17').replace('feature/guided-persistence-core-certification-rc1r17','feature/staff-experience-course-repair-rc1r17');p.write_text(s)
assert not subprocess.check_output(['git','diff','ce04e23','--','releases/rc1r16'],cwd=r)
old=w/'initial-routing-source-evidence';assert not old.exists();(e/'source').rename(old);shutil.copytree(r/'docs/verification/rc1r17',e/'source')
for name in ['finalize-source.py','seal-and-extract.py','finalize.py','package.py','finish-release.py','certify.py']:shutil.copy2(w/name,e/name)
shutil.copy2(w/'repair-packaging-routing.py',e/'repair-packaging-routing.py')
p=r/'RELEASE_MANIFEST.json';v=json.loads(p.read_text());v['exact_zip_verification']['receipt']='releases/rc1r17/SEAL_RESULT.json';p.write_text(json.dumps(v,indent=2)+'\n')
for a,b in [(Path('/workspace/rc17-downloads'),w/'initial-routing-downloads'),(w/'standalone-handoff',w/'initial-routing-handoff'),(w/'companions',w/'initial-routing-companions'),(w/'reports',w/'initial-routing-reports')]:
 assert a.exists()and not b.exists();a.rename(b)
subprocess.run(['python',str(w/'package.py')],check=True)
out=Path('/workspace/rc17-downloads');dest=r/'releases/rc1r17';assert not dest.exists();dest.mkdir(parents=True)
for p in out.iterdir():
 if p.is_file():shutil.copy2(p,dest/p.name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0');files=sorted(n for n in files if n and n!='SHA256SUMS.txt'and not n.startswith('releases/')and(r/n).is_file());(r/'SHA256SUMS.txt').write_text(''.join(f'{sha(r/n)}  {n}\n'for n in files));print('RC1R17_DOWNLOADS_FINAL_READY; prior RC1R16 unchanged')
