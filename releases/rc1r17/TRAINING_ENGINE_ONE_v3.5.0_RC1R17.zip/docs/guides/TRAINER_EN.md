# Trainer usage guide — RC1R17

## Enter your workspace

Obtain a registered staff account and class/course assignments from Admin. Open /trainer on the classroom host address. Enter your personal credentials; change any temporary password when prompted. An unchanged historical default can require local operator setup before network sign-in. No public demo passwords are shown. Use the account menu for English/Arabic and light/dark/system; these do not translate authored course content. Open your profile to maintain permitted details/photo and change your password. Sign out on shared devices. Course Editor accounts use /editor and stay isolated from classroom/report/administrative areas.

The home workspace summarizes assigned work. Search, filters, sorting and Reset help locate records without changing history. More opens mobile navigation. Keyboard users can Tab to controls, open menus with Arrow keys and dismiss with Escape. Read loading, empty, error and confirmation messages; an optimistic click is not evidence a write succeeded.

## Prepare a course and class

Courses lists content you may view/edit. Published versions cannot be changed in place. If authorized to author, create an editable Draft/new version, use Builder, save, resolve validation diagnostics and simulate. Activity type names are now capitalized English or fully Arabic metadata; authored names and IDs remain unchanged. Private facilitation belongs in Trainer cue/talking points/expected answer/common mistakes/transition, never public blocks. Public explanation belongs in the activity's public feedback field. Use only catalog components and their compatible result views. The current Course Creator kit includes all 36 activities and one-milestone-at-a-time authoring guidance. Do not invent graph transitions or change accepted IDs to fix labels.

Publishing requires permission; a saved incomplete draft is not a published course. Confirm the published version before creating a class. If a feature is absent, ask Admin for the required assignment rather than attempting another role's API. Course Editors can edit assigned courses and publish only when separately granted; they cannot operate classrooms.

In Classes open the intended class and check course version, schedule/session times, capacity, roster, Trainers, teams and delivery settings. Add/edit session details if permitted. Register participants through the authorized roster/import workflow or request Admin help. Group-to-class operations require reviewing exact affected people; groups are not classroom teams. Withdrawal preserves history and re-addition restores access without erasing prior progress. Only managing/lead assignments permit management operations; co-Trainer visibility does not imply every roster permission.

Copy the class code to registered participants. A code creates a pending request, not immediate admission. In Admission requests or the class admission panel, approve or decline eligible requests. Check the resulting enrollment and capacity. Unknown people need accounts from Admin first. Review attendance for the correct session and record the actual status/notes. No record is different from absent.

## Rehearse before teaching

Activate the intended class and open Live Classroom. Confirm the title/version and enrolled/connected counts. Pair the Projector using the classroom action, then open that public display on the room device. A pairing expires and can be revoked/replaced; old pairings must not be reused. Projector themes support dark/light/high contrast and 16:9 scenes. Trainer private notes stay on your console. Check actual assets, font legibility, English/Arabic direction and the Participant device before arrival.

Choose Trainer-paced for coordinated live activity; Participant-paced for the supported independent sequence; Front-of-room for presentation-oriented delivery. These settings do not invent new branching behavior. Use the course's explicit workflow when present: start its supported next node, observe requirements, complete personal work/convergence and end at an explicit terminal. A missing transition blocks authoring/validation; do not improvise a hidden route.

## Deliver the class

Select the milestone/activity and launch. Confirm Participants see a clear task. Collect responses; watch connected/responded counts and request help signals. Avoid reading private cues aloud. Close collection before discussing a solution where required. Reveal results deliberately, then explain using public feedback and transition. Before reveal, acknowledgements show saved responses without exposing correctness/points. Your authorized analysis can retain stored scoring; that does not make it safe to project. Result recall/history and alternate result views must use supported activity bindings.

Poll/choice/rating/ranking/short-answer controls differ. Matching keeps choices without associations; sorting and image interaction withhold solution order/coordinates until appropriate reveal. Word Cloud, Q&A, Ideas Board and Collaborative Board have distinct moderation/identity settings. Review pending entries where enabled and do not promise anonymity beyond the configured audience policy. Interactive Video uses local media and authored checkpoints; test playback before class. File/image/link submissions require the real supported submission flow; uploaded files are downloads and must be treated as untrusted. Team Challenge uses class teams and a team-scoped answer; verify team membership. Participant Choice and Practice Gate coordinate personal paths/work rather than generic answer forms.

For missions/personal paths, explain the goal, steps, deliverable and completion condition. Monitor help, review submitted work and give permitted feedback/rubrics. Complete the actual workflow stage; do not infer completion from a page being opened. Handle revisions and retries by checking saved state first. A stale revision needs a refreshed view. Restart/reconnect should retain persisted responses and progress; wait for the updated class state before navigating onward.

## After class and recovery

Use class history, participant profiles, learning reports and scoped analytics to review evidence. Charts have table equivalents; zero/no-data states are not missing learners. Recorded scores and participation counts have different meanings. Use professional PDF reports to choose an authorized subject, date range and EN/AR language, review then download; a reviewed snapshot does not silently incorporate later activity. Protect personal exports. Ordinary Trainers cannot use global backups or manage staff; refer those tasks to Admin.

Use notifications/messages and Audit & history for authorized operational follow-up. Archive completed work only when permitted; retained history remains available. Ask Admin for account resets, restored access, verified backups or publication permissions. For a failed write read the actual error and verify persisted state before retrying. For a missing resource check the course version, enrollment and Projector pairing. For LAN failure confirm the host is running and devices share the network; Internet is not required for bundled resources. Renew expired sessions/pairings. Sign out, document unresolved classroom issues and obtain owner visual acceptance before treating a candidate as FINAL.

## Current workspace repairs (RC1R17)

Your saved profile photo appears in the account menu and workspace identity. Change photo in My profile accepts validated PNG/JPEG up to 2 MiB. Returning to the Student workspace shows the main class/task before optional transcript, inbox and learning tools finish. Network or server failure can still delay the main task; this is not a guarantee of a fixed loading time.

Admission requests: a registered Student signs in, chooses Join class, enters the class code and sees Pending. A Trainer with enrollment/admission permission opens Admission requests (or the class admission panel), reviews identity/capacity/prerequisites and approves or declines. Admin may intervene. Approval creates/restores enrollment without erasing history. A request alone never enrolls someone. The bell provides notifications; mark individual messages read after reviewing them. Notifications are in-app, not email or operating-system push.

Messages: use the bell → New message (Admin also has Messages). Select one or more available audiences: Trainers, Participants, class, class Trainers/Participants, reusable groups or classroom teams. Admin can select System. Labels include recipient counts. The server resolves active recipients when sending, rejects inaccessible audiences, deduplicates overlaps and protects retries using the send request. A group changed later does not redirect an already sent message. Empty/inaccessible audiences are not offered. A Trainer's role audiences cover their authorized classes, not every account in the installation.

Teams: Classes → open class → Manage teams. Create, rename and select members. Selecting someone from another team moves them within this class; each belongs to at most one team per class. Student My profile → Learning history shows the class team and member names. Team edits retain the team identity and historical responses. Deletion and automatic regeneration are blocked when recorded team responses exist; rename or edit members instead. Empty teams without response history can be deleted. Reusable groups are separate from classroom teams.

Attendance: Classes → open class → Attendance. Add a class session first if needed. Select its session, choose Present, Late, Absent, Excused or Left early and an optional note, then Save attendance. Mark all present is an explicit shortcut. Unmarked people stay Not recorded. Changing session retains unsaved choices within the open dialog. Only changed records save; the result reports the actual count. Attendance is not inferred from login, connectivity or response submission. A multi-session save uses a separate atomic batch per session; if a later session fails, earlier saved sessions remain saved and retry sends remaining changes.

Classroom tools → Pointer: move continuously with mouse or touch; arrow keys move a focused Pointer pad and Escape hides the pointer. Select Pen, a contrasting color and width, then drag to write. Text annotation prompts for text at the chosen position. Undo stroke removes the last saved stroke; Clear ink preserves text; Clear all annotations removes ink, text and pointer. Drawing and text stay across slides/restarts until cleared; pointer movement is transient and expires after inactivity. The pad is a normalized control surface mapped to the whole Projector stage, not a handwriting recognition or screen-sharing service. Closing it does not erase ink. Limits: 200 strokes, 500 points per stroke, 20,000 points total, 20 text annotations. Check color contrast against your Projector scene. No pressure sensitivity, OCR, multi-user ink merging or pixel eraser is claimed.

Analytics opens with real scoped summary cards and default response/attendance/completion charts, followed by PDF reports, Chart builder and detailed sections. Tables accompany default charts. Export opens a chooser: select a CSV dataset/class scope or PDF template, authorized subject, language and dates; review the PDF before download. Course/Trainer CSV summaries cover full authorized scope; the class filter applies to class/participant/response/history datasets. Empty charts say No recorded data and do not invent scores.


## RC1R12 Creator and guided delivery

In Builder, open a path and edit its goal, steps, canonical blocks, resources, prompts and embedded questions. Apply edits before Save draft. Use Variables and shared steps, the insertion control, ten step presets, safe layouts/direction and typed visibility conditions. Duplicate/reorder steps without losing their stable identities; duplicated questions receive distinct canonical identities. Workflow → Connect learning paths creates explicit choices, branches, convergence and closing; the graph/simulator lists every route. Validation provides affected-item navigation and safe identifier repairs. Export produces a checked package; import and publish repeat the critical checks.

Preview as Participant executes the real renderer with temporary state, adjustable size and direction. Rehearse both complete M1 fixtures and the capability course. Trainer-Paced class convergence remains facilitator controlled while learner steps are independent. Participant-Paced mode preserves guided units and ordinary activities with return/resume and blocks premature exit; Front-of-Room pauses personal writes. Review scoped path/step/evaluation reports and CSV. Use existing submission review for file/image evidence. Recoverable class/course deletion retains history and restoration according to permissions.

## RC1R14 — your panel and activity

Open your account menu → Personalize my panel. Choose English/Arabic, Light/Dark/System, and Workspace default, Teal, Blue, Indigo, Violet, Rose or Amber. Choices belong to your account, including when several users share a browser; another user's choices do not change your panel. The same account loads its saved choices on another device. UI language stays independent from course language. If disconnected, a pending choice stays on this device and syncs after reconnection.

My activity shows your complete recorded activity, 10, 25 or 50 rows per page. Filter by activity type, All time/Today/Last 7 days/Last 30 days/Custom dates, or search. From/Through dates include both selected local calendar dates. Previous/Next and the total reflect the full filtered history. Use Refresh for new records. The own profile also contains this panel for every role; Course Editors can open it from their account menu. Authorized staff Audit & history is separate and respects assigned class/group scope.

The running Student class is full width: a compact green LIVE marker sits above the hero, and the current task is below it. Use My workspace or the profile menu at the top; there is no duplicate learning sidebar. When the Trainer finishes this selected class, it stays ended and offers a workspace return without silently switching to another class.

## Finish a class, then delete if needed

Use Finish class in the live classroom header or beside the running class in Classes. Review the confirmation. This exits a stuck activity, practice or break without requiring the course workflow to finish first. Saved responses, uploads, partial progress and history remain; unfinished learner tasks are not marked complete. The class becomes Completed, learners/Projector see it ended, and new live submissions stop. You can then use Delete → Trash. Hold, Break and Finish section do not finish the class. Only authorized classroom staff can finish it; a completed class can be explicitly reopened through the existing activation flow when appropriate.

Delete still uses the distinct Trash with history-preserving Restore. Permanent deletion requires an administrator to type the exact name and respects dependent classes. Old intentional Archive stays separate. Preserve data/storage/configuration during upgrades; follow RC1R14_UPGRADE_AND_ROLLBACK.md.


# RC1R15 — staff collaboration and scalable workspace

Notifications remain the existing notification inbox and Send notification. Staff chat is a separate private staff workspace, linked from Admin/Trainer sidebars and all staff account menus, including Course Editor. Participants cannot use staff chat/tasks. Direct/group text, bounded authenticated attachments, browser-recorded voice notes, read receipts and two-person WebRTC audio/video calls are available according to administrator policy and per-user permissions. Group creators manage membership. Only members can read messages/files; administrator status does not grant access to private conversations. Removed members lose access. Calls need HTTPS or loopback for devices and working ICE connectivity; optional administrator STUN/TURN is supported, including TCP relays. This is not WhatsApp feature parity or end-to-end encrypted message storage.

Staff Tasks & calendar supplies own tasks, supervisor assignments with assign_tasks permission, statuses, priority, start/due dates, notes, checklists, daily/weekly/monthly/yearly recurrence and day/week/month/year views. Calendar counts cover the complete authorized range; the agenda is paged. Completing a recurring task creates its next scheduled task. Both creator and assignee can update shared task progress; only creator can reassign/remove. Administrator does not gain access to unrelated private tasks. Export the authorized calendar as ICS.

Participants use My class notes inside the running class, save/edit their own text notes and export them. Workspace/profile notes remain accessible after class finish. No Trainer/Admin/other participant can read personal notes. Permanently deleting the class also removes its personal notes; export first.

Visible Admin/Trainer overview panels now have the same complete 10/25/50 activity paging, search/type/time/date filters as the Student panel. Click an event for an accessible detail dialog. Details use a human-readable allowlist, never raw event JSON, answers, tokens, private cues or message/note content. The live replay uses the same safe dialog. The live-operations hero now follows the account panel color and light/dark theme.

Selection forms use searchable, scrollable paginated tables, page select/remove, clear and selected-only actions. Form selections and assignment roles remain stable across pages. Group, audience, team, class participant/staff/course and other large native selection controls share this behavior. Existing people lists are paged locally after authorized retrieval; staff chat directory is SQL paged. Class creation fetches authorized published course-version options once instead of one request per course. Bulk roster selection adds/removes up to 500 participants atomically and preserves historical progress.

The staff calendar uses each browser’s local time zone, including tasks close to midnight. Personal-note export streams the full authorized selection.


## RC1R16: reliable Guided saves

Acknowledge, evidence and answers must receive server confirmation before required Next/Finish. Actual offline edits remain saved on this device and replay when the server is reachable. A server/authentication/validation error has its own message; use Saved guided changes to review, retry or discard unresolved work. Do not clear browser storage. Reload old tabs after upgrade; an old queued answer without a revision needs review, preserving newer work. Uploads and fresh page loads need a connection. Staff workspace tools from RC1R15 remain included. See the release certification and root-cause reports for tested scope and deployment limits.


## Messaging and work planning — RC1R17

The Messages icon beside Notifications shows received unread messages on staff pages. Open a conversation to send text, files or a voice note. Removing your own message requires confirmation. Audio/video calls can arrive while you are in another staff workspace; accept/decline, mute, camera and end controls are explicit. The message cue lasts about2seconds; calling rings until answered/ended. Use Enable sound if browser activation is required. Personal preferences, permissions and Admin policy apply. Media needs HTTPS or loopback and suitable connectivity. Keep the call page open and use a separate tab to navigate during a call.

Tasks and Calendar are separate pages outside Chat. Filter by ownership, status, priority, due date and search, and choose10/25/50 rows. Open task details for notes, checklists, dates and recurrence, or complete/reopen from the list. Calendar offers day/week/month/year with day drilldown and matching agenda. Export calendar uses current filters. Assigning others requires permission; only the creator may reassign/remove.
