# Admin usage guide — RC1R17

## First launch and sign-in

The operator needs Node 22.5 or newer. Extract the candidate to a new application folder and run START_TRAINING_ENGINE.bat on Windows, bash START_TRAINING_ENGINE.sh on Linux/macOS, or npm start from that folder. Connect devices to the trusted classroom LAN. The host terminal prints addresses, never passwords. The default port is 3000; the operator can configure HOST/PORT and data/storage/backup/export paths. Keep persistent paths during upgrades and stop the old instance first.

A new production installation creates TRAINER with a random initial password in the private local data/INITIAL_ADMIN_PASSWORD.txt file. Read it locally, sign in at /admin and set a personal password before entering the workspace. Delete the file securely after changing it. No demo users/courses are seeded in production. Existing users remain; an unchanged historical default password is gated until locally replaced. Contact the installation operator or another authorized administrator if you cannot access the host. Do not enable QA accounts on production data. Sign-in screens display no demo credentials.

Use the account menu for language, light/dark/system appearance and sign-out. Arabic changes the full interface direction; authored course language stays unchanged. Tab navigates controls; Enter activates; Escape closes menus/dialogs. On phones, use More for navigation. Search/filter/reset affect visible records, not stored history. An empty result is not proof a record was deleted.

## People and permissions

Open Trainers & staff to create staff accounts with personal usernames and temporary passwords meeting policy. Choose Trainer, Assistant, Administrator or Course Editor deliberately. Super administrator controls protected privileges; the last active super administrator cannot be removed. Role changes/deactivation revoke affected sessions. A Course Editor works only on assigned authoring resources, with separate publishing permission; it does not grant classroom, report or administrative access. Give the least required grants and review course/class assignments. Ordinary Trainers cannot provision staff or use system backups.

Open Participants to create registered accounts or use the supported roster workflow. Check names, identifiers, email and temporary passwords before applying. Participant and staff usernames cannot be confused to bypass roles. Password reset is an administrative action; deliver temporary passwords privately and require replacement. Deactivate access when appropriate; preserve the account and learning history. Open a profile to review permitted details and classes. Contact information is private to the person and authorized staff. Profile photos accept validated PNG/JPEG within displayed size/dimension limits.

Groups organize reusable participant/staff membership without changing permissions or classroom teams. Create a group, select members, save, then preview the exact class enrollment or Trainer-assignment impact before applying. Future group membership changes do not silently rewrite an existing class. Archive & restore retains history. A removal or withdrawal is not erasure of responses or reports; restore/re-add as needed and verify prior progress.

## Courses and publishing

Open Courses to search current courses, create/import with authorized permission and inspect versions. Imports validate the package before use; a rejected package has not been accepted. Use the current Course Creator kit, not historical v1.3 prompts, for new authoring. Open Builder on an editable Draft. Select a milestone/activity/path, supply content, settings and private Trainer guidance, save, resolve diagnostics and simulate. Incomplete drafts can be saved, but publishing blockers must be resolved. A published/delivered version is immutable: create a Draft/new version rather than overwriting history. Accepted IDs must remain stable. Course Editors require explicit per-course publishing permission. Confirm the newly published version before creating a class.

## Classes and admission

Open Classes, select a published course version, enter the title/schedule/capacity and assign appropriate Trainers. Configure delivery and join policy intentionally. Sessions, attendance, participants and class teams are separate concerns. Registered participants request admission with the class code; requests remain pending until an assigned managing Trainer approves or Admin intervenes. Review capacity and duplicates; do not treat a copied code as enrollment. Admission requests provides approve/decline controls and real resulting status. Archived or capacity-limited classes can refuse operations; read the error rather than repeatedly applying.

Preview roster/group/bulk changes, inspect affected people and apply the reviewed operation. A stale/conflicting preview may require a new preview. Check the resulting roster/status. Withdrawal retains history; re-adding must resume existing learning evidence. Activate the intended class, then use Live classes to monitor delivery. Administration monitoring and Trainer classroom control have different purposes. Pair the actual Projector from the authorized live classroom; keep Trainer private notes off the audience screen.

## Reporting, communication and settings

Analytics provides authorized class/course/participant summaries and chart/table views. Filter deliberately; missing attendance does not mean absence. Recorded points are not a universal mastery percentage. Seven professional PDF templates cover Class, Learner, Course, Attendance, Assessment, Participant Group and Trainer Activity. Choose resource, language and date range, preview the actual evidence and download. The reviewed snapshot preserves branding/data; prepare a new report to include later changes. CSV exports contain authorized records; use their headers and date ranges correctly. Do not redistribute personal reports indiscriminately.

Messages/notifications and Audit & history support authorized communication and operational review. Use recorded outcome, actor and time to investigate; this is not a forensic tamper-proof audit service. Settings controls system typography using the accepted bundled font catalog. Preview English and Arabic before applying. Company branding accepts owner name/contact/footer and a validated logo. That logo appears across sign-in/workspaces/Projector and reports; see RC1R9_BRANDING.md. Do not upload an SVG/script as an owner logo.

Use backup tools to create and verify a complete backup of database plus storage. Encrypted portable export needs a strong private passphrase supplied outside course content. Restore is a privileged destructive state replacement: stop concurrent work, verify the intended backup and keep a safety copy. Restoring revokes sessions and requires sign-in. Keep recovery files if restore reports incomplete recovery. For upgrade/rollback follow RC1R9_UPGRADE_AND_ROLLBACK.md; never reset SQLite or copy sample data over real state.

## Troubleshooting and daily close

A permission denial means assignment/grants need review; do not edit the database. A stale-version conflict requires refresh/review, not forced overwrite. Check data is saved before retrying after a network interruption. An expired Projector pairing must be renewed. For missing files check the supported version/enrollment/pairing and asset packaging. For startup failures check Node version, log and occupied port; do not run two servers against one data directory. Sign out on shared devices, verify backup, and stop only the intended instance. Owner Windows/LAN/browser/Projector visual acceptance remains required; automation does not establish FINAL release acceptance.

## Current workspace repairs (RC1R17)

Your saved profile photo appears in the account menu and workspace identity. Change photo in My profile accepts validated PNG/JPEG up to 2 MiB. Returning to the Student workspace shows the main class/task before optional transcript, inbox and learning tools finish. Network or server failure can still delay the main task; this is not a guarantee of a fixed loading time.

Admission requests: a registered Student signs in, chooses Join class, enters the class code and sees Pending. A Trainer with enrollment/admission permission opens Admission requests (or the class admission panel), reviews identity/capacity/prerequisites and approves or declines. Admin may intervene. Approval creates/restores enrollment without erasing history. A request alone never enrolls someone. The bell provides notifications; mark individual messages read after reviewing them. Notifications are in-app, not email or operating-system push.

Messages: use the bell → New message (Admin also has Messages). Select one or more available audiences: Trainers, Participants, class, class Trainers/Participants, reusable groups or classroom teams. Admin can select System. Labels include recipient counts. The server resolves active recipients when sending, rejects inaccessible audiences, deduplicates overlaps and protects retries using the send request. A group changed later does not redirect an already sent message. Empty/inaccessible audiences are not offered. A Trainer's role audiences cover their authorized classes, not every account in the installation.

Teams: Classes → open class → Manage teams. Create, rename and select members. Selecting someone from another team moves them within this class; each belongs to at most one team per class. Student My profile → Learning history shows the class team and member names. Team edits retain the team identity and historical responses. Deletion and automatic regeneration are blocked when recorded team responses exist; rename or edit members instead. Empty teams without response history can be deleted. Reusable groups are separate from classroom teams.

Attendance: Classes → open class → Attendance. Add a class session first if needed. Select its session, choose Present, Late, Absent, Excused or Left early and an optional note, then Save attendance. Mark all present is an explicit shortcut. Unmarked people stay Not recorded. Changing session retains unsaved choices within the open dialog. Only changed records save; the result reports the actual count. Attendance is not inferred from login, connectivity or response submission. A multi-session save uses a separate atomic batch per session; if a later session fails, earlier saved sessions remain saved and retry sends remaining changes.

Classroom tools → Pointer: move continuously with mouse or touch; arrow keys move a focused Pointer pad and Escape hides the pointer. Select Pen, a contrasting color and width, then drag to write. Text annotation prompts for text at the chosen position. Undo stroke removes the last saved stroke; Clear ink preserves text; Clear all annotations removes ink, text and pointer. Drawing and text stay across slides/restarts until cleared; pointer movement is transient and expires after inactivity. The pad is a normalized control surface mapped to the whole Projector stage, not a handwriting recognition or screen-sharing service. Closing it does not erase ink. Limits: 200 strokes, 500 points per stroke, 20,000 points total, 20 text annotations. Check color contrast against your Projector scene. No pressure sensitivity, OCR, multi-user ink merging or pixel eraser is claimed.

Analytics opens with real scoped summary cards and default response/attendance/completion charts, followed by PDF reports, Chart builder and detailed sections. Tables accompany default charts. Export opens a chooser: select a CSV dataset/class scope or PDF template, authorized subject, language and dates; review the PDF before download. Course/Trainer CSV summaries cover full authorized scope; the class filter applies to class/participant/response/history datasets. Empty charts say No recorded data and do not invent scores.

## Detailed Trainer permissions

Staff → Permissions now separates course View/Edit/Publish/Delete (archive), class View/Edit details and sessions/Control/Enrollment and admission/Teams/Attendance/Messages/Participant profile editing/Participant account deactivation/Delete (archive)/Full management, and workspace Reports/Messages/Groups/Admissions/Audit/Archive visibility. Group and messaging editing can be restricted independently. Creation has separate grants. Course Editors retain authoring isolation; administrators retain administrative privileges.

Select Use only these permissions to override implicit assignment rights for a resource. View is required; selecting the restriction without View hides that resource. Otherwise selected actions add to assignment defaults. Specific and All current and future resources grants combine; a wildcard grant is deliberately broad. Existing grants and assignments are unchanged until saved. Reload the affected Trainer workspace to refresh visible controls; server enforcement takes effect on the next request. With a custom policy, enrollment alone does not authorize participant profile edits or account deactivation. Deactivation is global and revokes that account's sessions; withdrawal removes class membership while retaining the active account. Published course content stays immutable even with editing grants. Review a view-only Trainer, a co-Trainer and a managing Trainer with real accounts before deployment.

Course grants govern course management/authoring. An authorized class continues delivering its published course content and scoped class reports even if course management is hidden. Report View includes preparing and downloading a reviewed PDF; it does not permit changing source learning records.

Saving the dialog preserves existing grants for resources not represented in its controls (for example historical individual participant grants or archived courses). Listed unchecked grants are removed. Explicit grants outside a class policy can still grant their own resource access; review them through the supported permissions API when needed, never by editing SQLite.


## RC1R12 guided experience update

The current build retains all existing administration and adds complete guided authoring/runtime acceptance. During a running class the Participant sees the class hero/current task first; personal learning/history/tools stay behind expandable arrows. Course/class Delete is recoverable and preserves history; active classes are protected. Use Reports → Guided learning report for path/drop-off/step timing/optional use/evaluation data and CSV within your authorized scope. Publication/export now verify actual assets as well as semantic readiness. Use the current RC1R12 acceptance and upgrade guides before an installation upgrade.

## RC1R14 — your panel and activity

Open your account menu → Personalize my panel. Choose English/Arabic, Light/Dark/System, and Workspace default, Teal, Blue, Indigo, Violet, Rose or Amber. Choices belong to your account, including when several users share a browser; another user's choices do not change your panel. The same account loads its saved choices on another device. UI language stays independent from course language. If disconnected, a pending choice stays on this device and syncs after reconnection.

My activity shows your complete recorded activity, 10, 25 or 50 rows per page. Filter by activity type, All time/Today/Last 7 days/Last 30 days/Custom dates, or search. From/Through dates include both selected local calendar dates. Previous/Next and the total reflect the full filtered history. Use Refresh for new records. The own profile also contains this panel for every role; Course Editors can open it from their account menu. Authorized staff Audit & history is separate and respects assigned class/group scope.

The running Student class is full width: a compact green LIVE marker sits above the hero, and the current task is below it. Use My workspace or the profile menu at the top; there is no duplicate learning sidebar. When the Trainer finishes this selected class, it stays ended and offers a workspace return without silently switching to another class.

## Finish a class, then delete if needed

Use Finish class in the live classroom header or beside the running class in Classes. Review the confirmation. This exits a stuck activity, practice or break without requiring the course workflow to finish first. Saved responses, uploads, partial progress and history remain; unfinished learner tasks are not marked complete. The class becomes Completed, learners/Projector see it ended, and new live submissions stop. You can then use Delete → Trash. Hold, Break and Finish section do not finish the class. Only authorized classroom staff can finish it; a completed class can be explicitly reopened through the existing activation flow when appropriate.

Delete still uses the distinct Trash with history-preserving Restore. Permanent deletion requires an administrator to type the exact name and respects dependent classes. Old intentional Archive stays separate. Preserve data/storage/configuration during upgrades; follow RC1R14_UPGRADE_AND_ROLLBACK.md.


# RC1R15 — staff collaboration and scalable workspace

Notifications remain the existing notification inbox and Send notification. Staff chat is a separate private staff workspace, linked from Admin/Trainer sidebars and all staff account menus, including Course Editor. Participants cannot use staff chat/tasks. Direct/group text, bounded authenticated attachments, browser-recorded voice notes, read receipts and two-person WebRTC audio/video calls are available according to administrator policy and per-user permissions. Group creators manage membership. Only members can read messages/files; administrator status does not grant access to private conversations. Removed members lose access. Calls need HTTPS or loopback for devices and working ICE connectivity; optional administrator STUN/TURN is supported, including TCP relays. This is not WhatsApp feature parity or end-to-end encrypted message storage.

Staff Tasks & calendar supplies own tasks, supervisor assignments with assign_tasks permission, statuses, priority, start/due dates, notes, checklists, daily/weekly/monthly/yearly recurrence and day/week/month/year views. Calendar counts cover the complete authorized range; the agenda is paged. Completing a recurring task creates its next scheduled task. Both creator and assignee can update shared task progress; only creator can reassign/remove. Administrator does not gain access to unrelated private tasks. Export the authorized calendar as ICS.

Participants use My class notes inside the running class, save/edit their own text notes and export them. Workspace/profile notes remain accessible after class finish. No Trainer/Admin/other participant can read personal notes. Permanently deleting the class also removes its personal notes; export first.

Visible Admin/Trainer overview panels now have the same complete 10/25/50 activity paging, search/type/time/date filters as the Student panel. Click an event for an accessible detail dialog. Details use a human-readable allowlist, never raw event JSON, answers, tokens, private cues or message/note content. The live replay uses the same safe dialog. The live-operations hero now follows the account panel color and light/dark theme.

Selection forms use searchable, scrollable paginated tables, page select/remove, clear and selected-only actions. Form selections and assignment roles remain stable across pages. Group, audience, team, class participant/staff/course and other large native selection controls share this behavior. Existing people lists are paged locally after authorized retrieval; staff chat directory is SQL paged. Class creation fetches authorized published course-version options once instead of one request per course. Bulk roster selection adds/removes up to 500 participants atomically and preserves historical progress.

The staff calendar uses each browser’s local time zone, including tasks close to midnight. Personal-note export streams the full authorized selection.


## RC1R16: reliable Guided saves

Acknowledge, evidence and answers must receive server confirmation before required Next/Finish. Actual offline edits remain saved on this device and replay when the server is reachable. A server/authentication/validation error has its own message; use Saved guided changes to review, retry or discard unresolved work. Do not clear browser storage. Reload old tabs after upgrade; an old queued answer without a revision needs review, preserving newer work. Uploads and fresh page loads need a connection. Staff workspace tools from RC1R15 remain included. See the release certification and root-cause reports for tested scope and deployment limits.


## Messaging and work planning — RC1R17

The Messages icon beside Notifications shows received unread messages on staff pages. Open a conversation to send text, files or a voice note. Removing your own message requires confirmation. Audio/video calls can arrive while you are in another staff workspace; accept/decline, mute, camera and end controls are explicit. The message cue lasts about2seconds; calling rings until answered/ended. Use Enable sound if browser activation is required. Personal preferences, permissions and Admin policy apply. Media needs HTTPS or loopback and suitable connectivity. Keep the call page open and use a separate tab to navigate during a call.

Tasks and Calendar are separate pages outside Chat. Filter by ownership, status, priority, due date and search, and choose10/25/50 rows. Open task details for notes, checklists, dates and recurrence, or complete/reopen from the list. Calendar offers day/week/month/year with day drilldown and matching agenda. Export calendar uses current filters. Assigning others requires permission; only the creator may reassign/remove.
