from pathlib import Path, PurePosixPath
import hashlib, json, ntpath, re, stat, unicodedata, zipfile, subprocess

out=Path('/workspace/rc1r11-downloads')
evidence=Path('/workspace/rc1r11-distribution')
extract=Path('/workspace/rc1r11-companion-verification')
assert not extract.exists(), 'Refusing to overwrite companion extraction'
extract.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
results=[]
for archive in sorted(out.glob('*.zip')):
 with zipfile.ZipFile(archive) as z:
  names=z.namelist(); assert len(names)==len(set(names))==len(set(unicodedata.normalize('NFC',n).casefold() for n in names))
  assert z.testzip() is None
  for i in z.infolist():
   n=i.filename; p=PurePosixPath(n)
   assert n and not p.is_absolute() and not ntpath.splitdrive(n)[0] and '\\' not in n and '..' not in p.parts and ':' not in n
   assert not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1
  count=0
  for n in names:
   if PurePosixPath(n).name!='SHA256SUMS.txt':continue
   for line in z.read(n).decode().splitlines():
    expected,rel=line.split('  ',1); key=(PurePosixPath(n).parent/rel).as_posix()
    assert re.fullmatch('[a-f0-9]{64}',expected) and sha(z.read(key))==expected, key
    count+=1
  if 'HANDOFF_RC1R11' in archive.name or 'CREATOR_KIT_RC1R11' in archive.name:
   dest=extract/archive.stem; dest.mkdir(); z.extractall(dest)
  results.append({'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'crc':'PASS','safe_unique_paths':'PASS','checksum_manifest_entries':count})
kit=extract/'TRAINING_ENGINE_ONE_COURSE_CREATOR_KIT_RC1R11'
handoff=extract/'TRAINING_ENGINE_ONE_COURSE_AUTHORING_HANDOFF_RC1R11'/'course-creator-kit'
logs=[]
for base in [kit,handoff]:
 for sample in sorted((base/'examples').glob('*.course.zip')):
  r=subprocess.run(['node','tools/validate-course.mjs',str(sample.relative_to(base))],cwd=base,text=True,capture_output=True)
  logs.append(str(base)+' / '+sample.name+'\n'+r.stdout+r.stderr)
  assert r.returncode==0, logs[-1]
 assert len(list((base/'examples').glob('*.course.zip')))==6
canonical=Path('/workspace/rc1r11-distribution/TRAINING_ENGINE_ONE_v3.5.0_RC1R11_source/course-creator-kit')
for base in [kit,handoff]:
 for p in canonical.rglob('*'):
  if p.is_file():assert p.read_bytes()==(base/p.relative_to(canonical)).read_bytes(),str(p)
(evidence/'COMPANION_VALIDATOR_OUTPUT.txt').write_text('\n'.join(logs))
(evidence/'COMPANION_VERIFICATION.json').write_text(json.dumps({'status':'PASS','archives':results,'portable_kit_files_identical':101,'fresh_extracted_kit_and_handoff_samples_validated':12},indent=2)+'\n')
print('COMPANION_VERIFICATION_PASS six archives, all manifest entries, fresh-extracted kit/handoff, twelve sample validations')
