from pathlib import Path, PurePosixPath
import hashlib, json, shutil, zipfile

e=Path('/workspace/rc1r11-distribution'); root=Path('/workspace/rc1r11-verification')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert 'CHECKS_PASS node: 62 commands' in (e/'EXTRACTED_NODE_OUTPUT.txt').read_text()
assert 'CHECKS_PASS browser: 7 commands' in (e/'EXTRACTED_BROWSER_OUTPUT.txt').read_text()
assert json.loads((e/'EXTRACTED_PDF_READER_RESULT.json').read_text())['status']=='PASS'
original=json.loads((e/'ARCHIVE_VERIFICATION.json').read_text())
changed=[rel for rel,h in original['initial_file_hashes'].items() if sha(root/rel)!=h]
expected={'docs/ACTIVITY_CERTIFICATION_MATRIX.json','docs/ACTIVITY_CERTIFICATION_MATRIX.md','docs/ACTIVITY_CERTIFICATION_RUNTIME_RESULT.json','docs/ACTIVITY_SURFACE_COVERAGE.json'}
assert set(changed)<=expected,changed
preserved=e/'current-certification';preserved.mkdir(exist_ok=True)
with zipfile.ZipFile(e/'TRAINING_ENGINE_ONE_v3.5.0_RC1R11.zip') as z:
 for rel in sorted(expected):
  shutil.copyfile(root/rel,preserved/Path(rel).name)
  if rel in changed:(root/rel).write_bytes(z.read(rel))
 for rel,h in original['initial_file_hashes'].items():assert sha(root/rel)==h,rel
 checked=0
 for manifest in root.rglob('SHA256SUMS.txt'):
  if manifest.relative_to(root).as_posix() not in original['initial_file_hashes']:continue
  for line in manifest.read_text().splitlines():
   expected_hash,rel=line.split('  ',1);assert sha(manifest.parent/rel)==expected_hash,rel;checked+=1
assert sha(e/'TRAINING_ENGINE_ONE_v3.5.0_RC1R11.zip')==original['sha256']
result={'status':'PASS','original_files_verified_after_tests':len(original['initial_file_hashes']),'generated_certification_files_preserved':sorted(expected),'changed_files_restored_from_immutable_archive':changed,'checksum_manifest_entries_reverified':checked,'archive_sha256_unchanged':original['sha256'],'new_test_output_boundary':'Ignored .test-evidence and external disposable directories; no original application file differs.'}
(e/'POST_TEST_INTEGRITY.json').write_text(json.dumps(result,indent=2)+'\n')
print('POST_TEST_INTEGRITY_PASS',len(original['initial_file_hashes']),'files,',checked,'manifest entries, immutable ZIP SHA-256 unchanged')
