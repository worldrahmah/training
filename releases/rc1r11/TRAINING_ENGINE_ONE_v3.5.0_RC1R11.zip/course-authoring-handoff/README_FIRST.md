# RC1R11 guided contract update

Current Core: 3.5.0-rc.1.11, core schema 3.2, authoring schema 2.0. Use the current generated Creator kit and canonical validator. See [Guided experience](GUIDED_EXPERIENCE.md) and [Gap matrix](CREATOR_GAP_MATRIX.md) for actual supported behavior and explicit limitations; do not promise completion of the whole master closure. Historical text below remains reference only where consistent with that contract.

> RC1R9 current authoring entry point: [generated Course Creator kit](../course-creator-kit/README.md). The external v1.3 archives are historical evidence only. This retained synchronized handoff is compatibility material; use the current kit for new milestone authoring.

# Training Engine ONE RC1R8 — current AI Course Creator contract

This in-tree kit is synchronized to the RC1R8 canonical registry, runtime capabilities and course schemas. Read CORE_CAPABILITIES.json completely before authoring. The kit is current for this owner-acceptance candidate; FINAL requires owner acceptance. The separate v1.3 package is historical RC4 evidence. Course schema remains 2.0; core/data schema is 3.2 with journaled workspace extensions.

## Authority order
1. `CORE_CAPABILITIES.json`
2. `WORKFLOW_AND_AUTHORING_RULES.md`
3. `COMPONENT_CATALOG_ONE.md`
4. `ONE_PLATFORM_CAPABILITIES.md`
5. `schemas/*` and `templates/*`
6. `examples/*` (reference only)
7. `CHATGPT_MASTER_COURSE_AUTHORING_PROMPT.md`

## Authoring rule
Use only capability IDs exposed by `CORE_CAPABILITIES.json`. Courses remain declarative; do not embed arbitrary executable code. Explicit workflows must be complete executable graphs. Preserve stable activity/objective IDs for analytics.

## Required course output
Return an importable course package, exact SHA-256, validation report, workflow simulation report when applicable, asset/reference coverage and known limitations.

## RC1R8 operation boundaries
Course Editors can author their own or assigned drafts and publish only with the per-course publishing grant. New class-code admission requires a registered account and assigned-manager approval. Historic guest learners and sessions are preserved; do not author instructions that promise new anonymous joining. Fonts are centrally chosen from 20 English and 20 Arabic bundled families; current global choices override old per-course font overrides. Course content language remains independent of the interface language.
