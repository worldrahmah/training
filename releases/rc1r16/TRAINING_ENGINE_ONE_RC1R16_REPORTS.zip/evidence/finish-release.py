from pathlib import Path
import json,shutil,subprocess,hashlib
r=Path('/workspace/training');d=Path('/workspace/rc16-distribution');e=d/'evidence';w=Path('/workspace/rc16-work');root=Path('/workspace/rc16-exact-verification')
assert 'CHECKS_PASS node: 71 commands'in(e/'EXTRACTED_NODE_OUTPUT.txt').read_text();assert 'CHECKS_PASS browser: 14 commands'in(e/'EXTRACTED_BROWSER_OUTPUT.txt').read_text()
assert 'STAFF_COLLABORATION_PASS 162'in(e/'EXTRACTED_NODE_OUTPUT.txt').read_text();assert json.loads((e/'EXTRACTED_PDF_READER_RESULT.json').read_text())['status']=='PASS';assert json.loads((e/'EXTRACTED_SYNTAX_RESULT.json').read_text())['syntax_files']==178
assert 'CONTRACT_SYNC_PASS'in(e/'EXTRACTED_CONTRACT_OUTPUT.txt').read_text();assert 'COURSE_CREATOR_KIT_CHECK_PASS 106 files'in(e/'EXTRACTED_KIT_OUTPUT.txt').read_text()
subprocess.run(['python',str(w/'certify.py'),str(root),str(e/'guided-certification-exact')],check=True)
shutil.copytree(root/'.test-evidence',e/'browser-exact')
for name in ['finalize-source.py','seal-and-extract.py','finalize.py','package.py','finish-release.py','certify.py']:shutil.copy2(w/name,e/name)
subprocess.run(['python',str(w/'finalize.py')],check=True);v=json.loads((e/'POST_TEST_INTEGRITY.json').read_text());seal=json.loads((d/'SEAL_INITIAL.json').read_text());digest=seal['sha256']
receipt='\nGuided Core exact-repeat certification PASS: all25 areas,88 official AR/EN step-route cases, four ten-answer grouped offline checks,46 technical rows and15 error/recovery checks;76 new persistence unit and896 persistence API/database assertions.\nExact immutable extraction PASS: all71 Node commands (162 new API/security assertions and expanded 4255-request workload), all14 browser programs (14 new journeys), 178 syntax files, canonical/106-file kit checks and independent readers for34 PDFs. Every original file and manifest entry was reverified after preserving generated certification outputs. ZIP SHA-256 '+digest+'; source commit '+seal['source_commit']+'. See companion actual receipts. Owner Windows/LAN/real devices/classroom/assistive acceptance and environment publication/fresh restore remain separate.\n'
for name in ['docs/RC1R16_VALIDATION_REPORT.md','docs/CODEX_EXEC_PLAN.md']:
 p=r/name;p.write_text(p.read_text()+receipt)
p=r/'docs/RC1R16_REQUIREMENTS.json';x=json.loads(p.read_text());x.update(engineering_status='IMPLEMENTED_VERIFIED',immutable_gate={'status':'PASS','sha256':digest,'source_commit':seal['source_commit'],'original_files':v['original_files_verified_after_tests']});
for row in x['requirements']:row['status']='IMPLEMENTED_VERIFIED'
p.write_text(json.dumps(x,indent=2)+'\n')
p=r/'RELEASE_MANIFEST.json';m=json.loads(p.read_text());m['exact_zip_verification']={'status':'PASS','sha256':digest,'source_commit':seal['source_commit'],'files':v['original_files_verified_after_tests'],'receipt':'releases/rc1r16/SEAL_RESULT.json'};p.write_text(json.dumps(m,indent=2)+'\n')
subprocess.run(['python',str(w/'package.py')],check=True);out=Path('/workspace/rc16-downloads');dest=r/'releases/rc1r16';assert not dest.exists();dest.mkdir(parents=True)
for p in out.iterdir():
 if p.is_file():shutil.copy2(p,dest/p.name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0');files=sorted(n for n in files if n and n!='SHA256SUMS.txt'and not n.startswith('releases/')and(r/n).is_file());(r/'SHA256SUMS.txt').write_text(''.join(f'{sha(r/n)}  {n}\n'for n in files));print('FULL_RC1R16_RELEASE_PACKAGED',digest)
