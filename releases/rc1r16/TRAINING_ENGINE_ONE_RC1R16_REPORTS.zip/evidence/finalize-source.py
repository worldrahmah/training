from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('/workspace/training');w=Path('/workspace/rc16-work');source=Path('/workspace/rc16-source-origin-final');ev=r/'docs/verification/rc1r16';ev.mkdir(parents=True,exist_ok=True)
assert 'CHECKS_PASS node: 71 commands' in (w/'SOURCE_NODE_OUTPUT.txt').read_text()
assert 'CHECKS_PASS browser: 14 commands' in (w/'SOURCE_BROWSER_OUTPUT.txt').read_text()
assert 'GUIDED_PERSISTENCE_PASS 76' in (w/'SOURCE_NODE_OUTPUT.txt').read_text()
assert 'GUIDED_PERSISTENCE_API_PASS 896' in (w/'SOURCE_NODE_OUTPUT.txt').read_text()
assert 'GUIDED_PERSISTENCE_BROWSER_PASS 46' in (w/'SOURCE_TECHNICAL_CONFIRMATION_OUTPUT.txt').read_text()
assert 'GUIDED_UPLOAD_OFFLINE_PASS 4' in (w/'SOURCE_UPLOAD_OFFLINE_OUTPUT.txt').read_text()
assert 'STAFF_COLLABORATION_PASS 162' in (w/'SOURCE_NODE_OUTPUT.txt').read_text()
assert json.loads((w/'SOURCE_SYNTAX_RESULT.json').read_text())['syntax_files']==178
pdf=json.loads((w/'SOURCE_PDF_READER_RESULT.json').read_text());assert pdf['status']=='PASS' and len(pdf['reports'])==34
assert 'CONTRACT_SYNC_PASS' in (w/'SOURCE_CONTRACT_OUTPUT.txt').read_text();assert 'CHECK_PASS 106 files' in (w/'SOURCE_KIT_OUTPUT.txt').read_text()
# Ensure application and executable test/authoring sources still match the validated copy.
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0')
for name in files:
 if name and (name.startswith('app/')or name.startswith('tests/')or name.startswith('tools/')or name=='validation/commands.json')and(r/name).is_file():assert (source/name).read_bytes()==(r/name).read_bytes(),name
subprocess.run(['python',str(w/'certify.py'),str(source),str(ev)],check=True)
load=json.loads((source/'.test-evidence/staff-load/RESULT.json').read_text());assert load['ok'] and load['requests']==4255 and not load['errors']
feature=json.loads((source/'.test-evidence/staff-collaboration/RESULT.json').read_text());assert feature['ok'] and len(feature['journeys'])==14
for name in ['SOURCE_NODE_OUTPUT.txt','SOURCE_BROWSER_OUTPUT.txt','SOURCE_ADDITIONAL_RECOVERY_OUTPUT.txt','SOURCE_TECHNICAL_CONFIRMATION_OUTPUT.txt','SOURCE_UPLOAD_OFFLINE_OUTPUT.txt','SOURCE_SYNTAX_RESULT.json','SOURCE_CONTRACT_OUTPUT.txt','SOURCE_KIT_OUTPUT.txt','SOURCE_PDF_READER_RESULT.json','SOURCE_PDF_READER_OUTPUT.txt','PRODUCTION_READINESS.json']:shutil.copy2(w/name,ev/name)
for folder in ['staff-load','staff-collaboration']:shutil.copytree(source/'.test-evidence'/folder,ev/folder,dirs_exist_ok=True)
shutil.copy2('/workspace/qa-turn/VERIFICATION.json',ev/'QA_RELAY_VERIFICATION.json')
shutil.copy2('/workspace/rc15-release-work/baseline-node.log',ev/'UNCHANGED_RC14_BASELINE_NODE_OUTPUT.txt')
shutil.copy2(w/'initial-source-node-pass.txt',ev/'INITIAL_71_NODE_OUTPUT.txt')
for name in ['ACTIVITY_CERTIFICATION_MATRIX.json','ACTIVITY_CERTIFICATION_MATRIX.md','ACTIVITY_CERTIFICATION_RUNTIME_RESULT.json','ACTIVITY_SURFACE_COVERAGE.json']:shutil.copy2(source/'docs'/name,r/'docs'/name)
hand=r/'course-authoring-handoff/acceptance';hand.mkdir(exist_ok=True)
for name in ['GUIDED_CERTIFICATION_MATRIX.json','GUIDED_CERTIFICATION_MATRIX.md','SOURCE_NODE_OUTPUT.txt','SOURCE_BROWSER_OUTPUT.txt','SOURCE_ADDITIONAL_RECOVERY_OUTPUT.txt','SOURCE_TECHNICAL_CONFIRMATION_OUTPUT.txt','SOURCE_UPLOAD_OFFLINE_OUTPUT.txt','SOURCE_SYNTAX_RESULT.json']:shutil.copy2(ev/name,hand/name)
shutil.copy2(r/'docs/RC1R16_ROOT_CAUSE.md',hand/'ROOT_CAUSE.md')
changed=sorted(set(subprocess.check_output(['git','diff','--name-only','538d6be30bb9bf76de3215bbd72e607ab4655bbf'],cwd=r,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines()))
(r/'docs/RC1R16_FILES_CHANGED.json').write_text(json.dumps({'relative_to_rc14':'538d6be30bb9bf76de3215bbd72e607ab4655bbf','includes_preserved_rc15_scope':True,'files':changed},indent=2)+'\n')
requirements=r/'docs/RC1R16_REQUIREMENTS.json';v=json.loads(requirements.read_text());v['engineering_status']='SOURCE_VERIFIED_PENDING_IMMUTABLE_REPEAT'
for row in v['requirements']:row.update(status='SOURCE_VERIFIED_PENDING_IMMUTABLE_REPEAT',evidence='docs/verification/rc1r16 and RC1R16_ROOT_CAUSE.md')
requirements.write_text(json.dumps(v,indent=2)+'\n')
receipt=f'''# RC1R16 source validation\n\nPASS: all71 Node commands (76 new persistence unit assertions,896 new persistence API/database assertions,162 staff collaboration assertions), all14 browser programs,178 syntax files, canonical/106-file kit drift and34 independently parsed/rendered PDF reports. Guided report:25 areas,88 official AR/EN route-step cases,46 technical both-path rows,4 ten-answer offline grouped evaluation checks and15 browser online-error/recovery cases. Full logs and machine matrices accompany this report.\n\nThe170-client/five-class authenticated workload passed{load['requests']} requests with zero errors; measured p50/p95/p99{load['latency_ms']['p50']}/{load['latency_ms']['p95']}/{load['latency_ms']['p99']}ms and peak RSS{load['peak_server_rss_bytes']}bytes. The14 staff browser journeys include actual two-person audio/video streams, authenticated files/voice, assigned tasks/calendar, notes/export,1000participant/100course selection and theme/RTL/responsive checks. Timing under concurrent cloud QA is a measurement, not a universal deployment guarantee.\n\nNormal startup schema8 retained existing data, passed9HTML routes and6auth denials with QA accounts disabled. Initial five-second legacy backup readiness failures were retained and diagnosed; the fixture now uses a bounded30-second deadline, early child-exit diagnostics, ephemeral ports and confirmed cleanup without altering backup/restore assertions. Immutable fresh extraction and remote artifact verification remain mandatory pending gates. Owner physical Windows/LAN/devices/classroom/visual/assistive acceptance is separate.\n'''
(r/'docs/RC1R16_VALIDATION_REPORT.md').write_text(receipt)
p=r/'docs/CODEX_EXEC_PLAN.md';p.write_text(p.read_text()+'\n'+receipt)
p=r/'RELEASE_MANIFEST.json';v=json.loads(p.read_text());v.update(source_validation='PASS_71_NODE_14_BROWSER_178_SYNTAX_106_KIT_34_PDF',exact_zip_verification='Pending full immutable extraction repeat');p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
subprocess.run(['node','tools/sync-contracts.mjs','--write'],cwd=r,check=True);subprocess.run(['node','tools/build-course-creator-kit.mjs'],cwd=r,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();hand=r/'course-authoring-handoff';(hand/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(hand).as_posix()}\n'for p in sorted(hand.rglob('*'))if p.is_file()and p.name!='SHA256SUMS.txt'))
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0');files=sorted(n for n in files if n and n!='SHA256SUMS.txt'and not n.startswith('releases/')and(r/n).is_file());(r/'SHA256SUMS.txt').write_text(''.join(f'{sha(r/n)}  {n}\n'for n in files));print('FINAL_SOURCE_READY',len(files)+1)
