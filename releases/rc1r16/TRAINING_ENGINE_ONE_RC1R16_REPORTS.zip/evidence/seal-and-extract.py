from pathlib import Path
import subprocess,json,shutil
r=Path('/workspace/training');d=Path('/workspace/rc16-distribution');e=d/'evidence';e.mkdir(parents=True,exist_ok=True)
p=subprocess.run(['python','tools/seal-release.py','--output',str(d)],cwd=r,text=True,capture_output=True);assert p.returncode==0,p.stderr;(d/'SEAL_INITIAL.json').write_text(p.stdout);v=json.loads(p.stdout)
subprocess.run(['python','tools/verify-release.py','--archive',v['archive'],'--extract','/workspace/rc16-exact-verification','--output',str(e/'ARCHIVE_VERIFICATION.json'),'--expected-version','3.5.0-rc.1.16'],cwd=r,check=True)
p=subprocess.run(['python','tools/verify-package.py',v['archive'],'--expected-sha256',v['sha256']],cwd=r,text=True,capture_output=True);(e/'PACKAGE_VERIFICATION.txt').write_text(p.stdout+p.stderr);assert p.returncode==0
shutil.copytree(r/'docs/verification/rc1r16',e/'source')
shutil.copy2('/workspace/rc16-work/PRODUCTION_READINESS.json',e/'PRODUCTION_READINESS.json')
print('SEALED_FRESH_EXTRACTION_READY',v['sha256'],v['files'])
