from pathlib import Path, PurePosixPath
import hashlib,json,shutil,subprocess,zipfile,ntpath,stat,unicodedata
work=Path('/workspace/rc16-work'); dist=Path('/workspace/rc16-distribution');out=Path('/workspace/rc16-downloads');assert not out.exists();out.mkdir()
seal=json.loads((dist/'SEAL_INITIAL.json').read_text());stage=Path(seal['stage']);ev=dist/'evidence';assert json.loads((ev/'POST_TEST_INTEGRITY.json').read_text())['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sums(root):
 (root/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(root).as_posix()}\n' for p in sorted(root.rglob('*')) if p.is_file() and p!=root/'SHA256SUMS.txt'))
def pack(root,target):
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():assert not p.is_symlink();z.write(p,p.relative_to(root).as_posix())
shutil.copy2(seal['archive'],out/Path(seal['archive']).name)
pack(stage/'course-creator-kit',out/'TRAINING_ENGINE_ONE_COURSE_CREATOR_KIT_RC1R16.zip')
hand=work/'standalone-handoff';assert not hand.exists();shutil.copytree(stage/'course-authoring-handoff',hand);shutil.copytree(stage/'course-creator-kit',hand/'course-creator-kit')
p=hand/'README_FIRST.md';p.write_text('# Standalone RC1R16 authoring handoff\n\nExtract the entire ZIP. The complete current kit is in course-creator-kit. From that directory run `node tools/validate-course.mjs examples/M1_GUIDED_ACCEPTANCE.course.zip`. No installation or network is needed for validation. The runtime is a separate download. Full mandatory master-prompt engineering is complete; owner Windows/classroom/assistive acceptance remains separate.\n\n'+p.read_text())
exact=hand/'acceptance/exact';shutil.copytree(ev/'guided-certification-exact',exact)
for name in ['EXTRACTED_NODE_OUTPUT.txt','EXTRACTED_BROWSER_OUTPUT.txt','POST_TEST_INTEGRITY.json']:shutil.copy2(ev/name,exact/name)
p=hand/'HANDOFF_MANIFEST.json';v=json.loads(p.read_text());v.update(registry='course-creator-kit/registry/activity-component-registry.json',portable_validator='course-creator-kit/tools/validate-course.mjs',publication_status='OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL',guided_core_certification='acceptance/exact/GUIDED_CERTIFICATION_MATRIX.json');p.write_text(json.dumps(v,indent=2)+'\n');sums(hand);pack(hand,out/'TRAINING_ENGINE_ONE_COURSE_AUTHORING_HANDOFF_RC1R16.zip')
for name in ['M1_GUIDED_ACCEPTANCE.course.zip','M1_GUIDED_ACCEPTANCE_EN.course.zip','COURSE_CREATOR_CAPABILITY_TEST.course.zip','GUIDED_PERSISTENCE_ACCEPTANCE.course.zip']:shutil.copy2(stage/'authoring-kit/examples'/name,out/name)
extract=work/'companions';extract.mkdir();results=[]
for a in sorted(out.glob('*.zip')):
 with zipfile.ZipFile(a) as z:
  names=z.namelist();assert z.testzip() is None;assert len(names)==len(set(names))==len(set(unicodedata.normalize('NFC',n).casefold() for n in names))
  for i in z.infolist():
   n=i.filename;p=PurePosixPath(n);assert n and not p.is_absolute() and not ntpath.splitdrive(n)[0] and '\\' not in n and '..' not in p.parts and ':' not in n;assert not stat.S_ISLNK(i.external_attr>>16) and not i.flag_bits&1
  count=0
  for n in names:
   if PurePosixPath(n).name!='SHA256SUMS.txt':continue
   for line in z.read(n).decode().splitlines():
    h,r=line.split('  ',1);assert hashlib.sha256(z.read((PurePosixPath(n).parent/r).as_posix())).hexdigest()==h;count+=1
  if 'HANDOFF_RC1R16' in a.name or 'CREATOR_KIT_RC1R16' in a.name:z.extractall(extract/a.stem)
 results.append(dict(file=a.name,bytes=a.stat().st_size,sha256=sha(a),crc='PASS',safe_unique_paths='PASS',checksum_manifest_entries=count))
logs=[]
for base in [extract/'TRAINING_ENGINE_ONE_COURSE_CREATOR_KIT_RC1R16',extract/'TRAINING_ENGINE_ONE_COURSE_AUTHORING_HANDOFF_RC1R16/course-creator-kit']:
 samples=sorted((base/'examples').glob('*.course.zip'));assert len(samples)==7
 for sample in samples:
  r=subprocess.run(['node','tools/validate-course.mjs',str(sample.relative_to(base))],cwd=base,text=True,capture_output=True);logs.append(str(base)+' / '+sample.name+'\n'+r.stdout+r.stderr);assert r.returncode==0,logs[-1]
 for p in (stage/'course-creator-kit').rglob('*'):
  if p.is_file():assert p.read_bytes()==(base/p.relative_to(stage/'course-creator-kit')).read_bytes(),p
(ev/'COMPANION_VALIDATOR_OUTPUT.txt').write_text('\n'.join(logs));(ev/'COMPANION_VERIFICATION.json').write_text(json.dumps(dict(status='PASS',archives=results,portable_kit_files_identical=106,fresh_extracted_kit_and_handoff_samples_validated=14),indent=2)+'\n')
shutil.copy2('/workspace/training/docs/RC1R12_REQUIREMENTS.md',out/'RC1R12_REQUIREMENTS.md')
for p in Path('/workspace/training/docs').glob('*RC1R16*'):
 if p.is_file():shutil.copy2(p,out/p.name)
shutil.copytree(ev,out/'evidence');shutil.copy2(work/'DOWNLOADS.md',out/'DOWNLOADS.md')
report={'status':'PASS','release_status':'OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL','version':'3.5.0-rc.1.16','source_commit':seal['source_commit'],'source_and_exact_extraction':{'node_commands_each':71,'browser_programs_each':14,'syntax_files':178,'independent_pdf_reports_each':34,'kit_files':106},'new_guided_unit_assertions':76,'new_guided_api_assertions':896,'new_security_api_assertions':162,'guided_certification':json.loads((ev/'guided-certification-exact/GUIDED_CERTIFICATION_MATRIX.json').read_text()),'new_browser_journeys':14,'exact_load':json.loads((ev/'browser-exact/staff-load/RESULT.json').read_text()),'companions':results,'manual_gates':'Owner Windows/LAN/real microphone/camera/classroom/visual/assistive acceptance UNRUN; cloud publication/fresh-task restore separate','limitations':'docs/KNOWN_LIMITATIONS_RC1R16.md'}
(out/'SEAL_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
text='# RC1R16 complete engineering candidate\n\nGuided persistence now preserves HTTP failures instead of mislabeling them offline, requires exact mutation/revision acknowledgement and uses atomic durable receipts for safe retry. Required evidence/navigation stays enforced. All eight official AR/EN M1 route combinations and four ten-answer offline grouped evaluations pass; all eight evidence modes/twelve interactions pass both-path online/offline/reconnect/refresh certification. The canonical two-path ChatGPT/prompt/shared-variable technical pattern passes, including refresh during a pending request, lost replies and stale tabs. Read the precise root cause, full changed-file list and database/API changes in the included reports.\n\nStaff chat (text/groups/files/voice and two-person audio/video), staff tasks/calendar/checklists/assignment/recurrence, own participant class notes/export, activity detail dialogs on fully paged visible staff dashboards, scalable selection tables and theme correction are implemented. Notifications remain distinct. All previous Finish/Trash/account preferences, guided Creator/runtime, 36 activities and 68 result cases remain.\n\nFull source and the exact immutable ZIP extraction each pass all 71 Node commands, 14 browser programs, 178 syntax files, canonical/106-file kit drift and independent PDF readers for 34 reports. The collaboration suite passes 162 API/security assertions and 14 browser journeys, including real WebRTC streams with synthetic devices through an authenticated TCP relay under the unchanged managed browser policy, 1000 participant/100 course selectors and actual class creation. Existing populated migration/auth/reveal/privacy/backup/restart/reconnect/Creator and complete classroom checks remain. Full actual logs/screenshots and generated certification results are in evidence.\n\nThe source expanded load and exact extraction exercise 170 authenticated HTTP clients (15 staff + 5 Trainers + 150 participants), five concurrent live classes, chat, tasks, notes, responses, 20 attachments and five call signaling sessions. Read exact measured timing, memory and persisted counts in SEAL_RESULT.json. This does not simulate 170 physical devices or 170 simultaneous media streams, excludes a mass login/hash burst, and is not a universal latency guarantee.\n\nAll original extracted bytes and checksum manifests reverify after retaining four generated certification reports externally and restoring their original ZIP bytes. Immutable app SHA-256: `'+seal['sha256']+'`. Source commit: `'+seal['source_commit']+'`. Portable kit and standalone handoff each validate seven samples after fresh extraction and match the same 106 kit files. Normal startup schema8 preserves existing data with QA mode disabled.\n\nMedia capture needs HTTPS or loopback and network connectivity; optional STUN/TURN is administrator-configurable. Calls connect two staff members; group messaging does not imply group conferencing. Chat is not end-to-end encrypted at rest and attachments are not an antivirus guarantee. Private chat/tasks/notes use authenticated membership/ownership and granular permissions. See security review and upgrade/rollback guide. Owner real Windows/LAN/media/classroom/accessibility acceptance remains UNRUN. Status OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL; no 100% security claim.\n\n| Download | SHA-256 |\n|---|---|\n'+''.join('| '+x['file']+' | `'+x['sha256']+'` |\n'for x in results)+'\nThe reports ZIP is assembled last; its final hash is in the external SHA256SUMS.txt and ARTIFACTS.json with all eight downloads. Independent GitHub byte verification is published separately after upload.\n'
(out/'SEAL_REPORT.md').write_text(text)
reports=work/'reports';reports.mkdir()
for p in out.iterdir():
 if p.is_dir():shutil.copytree(p,reports/p.name)
 elif p.suffix!='.zip':shutil.copy2(p,reports/p.name)
sums(reports);pack(reports,out/'TRAINING_ENGINE_ONE_RC1R16_REPORTS.zip')
with zipfile.ZipFile(out/'TRAINING_ENGINE_ONE_RC1R16_REPORTS.zip')as z:
 assert z.testzip()is None;assert len(z.namelist())==len(set(x.casefold()for x in z.namelist()))
 for line in z.read('SHA256SUMS.txt').decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h,n
archives=sorted(out.glob('*.zip'));assert len(archives)==8
(out/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n'for p in archives));(out/'ARTIFACTS.json').write_text(json.dumps([dict(file=p.name,sha256=sha(p),bytes=p.stat().st_size)for p in archives],indent=2)+'\n');print('DOWNLOADS_PASS eight ZIPs, fourteen fresh portable validations; '+sha(out/Path(seal['archive']).name))
