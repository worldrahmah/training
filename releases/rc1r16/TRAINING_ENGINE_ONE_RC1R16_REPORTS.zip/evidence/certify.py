from pathlib import Path
import json,sys,shutil
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
ev=source/'.test-evidence';official=json.loads((ev/'guided-official/result.json').read_text());assert official['status']=='PASS';routes=json.loads((ev/'guided-official/routes.json').read_text());assert len(routes)==88 and all(r['status']=='PASS' for r in routes)
checks=official['checks'];groups=[r for r in checks if r.get('grouped_evaluation_offline_edit_all_ten_reconnect_refresh')=='PASS'];assert {(r['language'],r['path'])for r in groups}=={(language,path)for language in ['ar','en']for path in ['path-sleep','path-scholarship']}
pattern=json.loads((ev/'guided-persistence/result.json').read_text());assert pattern['status']=='PASS' and pattern['matrix_rows']==46 and pattern['fault_cases'] in [12,14,15]
matrix=json.loads((ev/'guided-persistence/matrix.json').read_text());faults=json.loads((ev/'guided-persistence/faults.json').read_text());
recovery=ev/'guided-persistence/recovery/faults.json'
if recovery.exists():
 for case in json.loads(recovery.read_text()):
  if case not in faults:faults.append(case)
assert len(faults)==15
api=json.loads((ev/'guided-persistence/api-result.json').read_text());assert api['status']=='PASS' and api['assertions']>=896
upload=ev/'guided-upload-offline/result.json'
if upload.exists():
 u=json.loads(upload.read_text());assert u['status']=='PASS' and len(u['checks'])==4 and all(c['offline_rejected_without_false_saved_claim']=='PASS'for c in u['checks'])
else:
 assert all(r.get('offline_upload_honesty') is True for r in matrix if r['area'] in ['file','image'])
paths={'path-a','path-b'};result=[]
for area,tag in [(t,'completion')for t in ['none','acknowledge','external','text','url','checklist','file','image']]+[(t,'interaction')for t in ['single_choice','multiple_choice','rating','confidence','reaction','short_answer','long_answer','numeric_answer','checklist','reflection','self_assessment','true_false']]:
 rows=[r for r in matrix if r['area']==area and ('-question-' in r['step'])==(tag=='interaction') and ('-evidence-' in r['step'] or tag=='interaction')]
 assert {r['path']for r in rows}==paths,(area,tag)
 assert all(r['result']=='PASS' and all(r[k]=='PASS'for k in ['online','offline','reconnect','refresh'])for r in rows),(area,rows)
 result.append({'area':area,'kind':tag,**{k:'PASS'for k in ['online','offline','reconnect','refresh','both_paths','result']},'notes':'Offline covers retained submission reference/text edits; binary upload requires server connection.' if area in ['file','image']else''})
for area in ['grouped evaluation','path progress','convergence','shared variables/concrete step identities','terminal/resume']:
 result.append({'area':area,'kind':'runtime',**{k:'PASS'for k in ['online','reconnect','refresh','both_paths','result']},'offline':'NOT_APPLICABLE' if area in ['convergence','terminal/resume'] else 'PASS','notes':'Class convergence itself requires a server connection.' if area=='convergence'else''})
report={'format':'training-engine-guided-certification','version':'3.5.0-rc.1.16','engineering_status':'PASS','core_schema':'3.2','course_schema':'2.0','workspace_schema':'8','rows':result,'official_routes':routes,'official_grouped_offline_checks':groups,'browser_faults':faults,'api_assertions':api['assertions'],'scope_limits':['Binary uploads and fresh page loading require the local server.','Owner physical Windows/LAN/media/visual/assistive acceptance is separate.','Original deployment response was not supplied; reproduced non-JSON500 path is documented precisely.']}
(out/'GUIDED_CERTIFICATION_MATRIX.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
text='# RC1R16 Guided Experience engineering certification\n\nCore/app3.5.0-rc.1.16; core schema3.2, course schema2.0, workspace schema8. This report derives from actual API/database/browser results; no unrun cell is marked PASS. All88 official M1 route-step cases pass across AR/EN, both paths and both remediation outcomes. Four actual grouped ten-answer offline edit/reconnect checks cover both paths/languages.\n\n| Area | Mode | Online | Offline | Reconnect | Refresh | Both paths | Result |\n|---|---|---|---|---|---|---|---|\n'
for r in result:text+='| '+r['area']+' | '+r['kind']+' | '+' | '.join(r[k]for k in ['online','offline','reconnect','refresh','both_paths','result'])+' |\n'
text+='\nFile/image offline PASS means already uploaded reference and local text/prompt edits queue and reconcile; binary uploads require a connection. Convergence requires the server. The detailed machine report contains all route IDs, fault cases and limitations. No universal security or physical-device certification is implied.\n'
(out/'GUIDED_CERTIFICATION_MATRIX.md').write_text(text)
for name in ['guided-official','guided-persistence','guided-upload-offline']:
 if (ev/name).exists():shutil.copytree(ev/name,out/name,dirs_exist_ok=True)
print('GUIDED_CERTIFICATION_PASS',len(result),'areas;',len(routes),'official step-route cases; four ten-question offline grouped checks;',len(matrix),'technical rows;',len(faults),'failure/recovery checks')
