# Seal evidence boundary

This archive contains the complete candidate application, working-tree test/browser evidence, screenshots, upgrade notes, limitations and owner checklist. Exact ZIP SHA-256 and fresh-extraction test outcomes are attested in the companion seal report after this immutable ZIP is produced. A ZIP cannot contain its own final SHA-256 without changing that hash. Do not substitute source-tree tests for exact-ZIP verification.

Source commit: ac1a976a846a1888bf2ab8fa4614dba3193f492a
Status: OWNER_ACCEPTANCE_CANDIDATE_NOT_FINAL.
