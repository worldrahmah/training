# Student / Participant usage guide — RC1R10

## Get an account and sign in

Your administrator supplies a registered Participant account. A class code does not create an account. Open /student at the classroom host address provided by your Trainer, using a modern browser on the same trusted LAN. Internet is not required for the application and bundled course assets. Enter your own username/password; never share it. No demo credentials appear on sign-in. Change a temporary password when prompted. If an old installation requires local setup, ask the operator/Admin; do not try to edit files or create a new identity to bypass it.

Use the menu for English/Arabic, light/dark/system appearance and sign-out. Arabic uses right-to-left navigation, but a course keeps its authored language and text. A changed activity-type label does not rename your saved work. Use Tab and Enter for keyboard navigation; Escape closes menus/dialogs. On narrow screens scroll the page/appropriate table and use visible navigation controls. If a control is disabled or missing, your class state or permissions may not allow the action.

## Join and find your class

Select Join class, enter the code given by your Trainer and submit the request. The request stays Pending until an assigned managing Trainer approves; Admin may intervene. Do not assume success means enrollment. Look for the actual status/notification. A rejected or capacity-limited request requires Trainer help. You must use a registered account; an anonymous person cannot enter using only the code. Do not repeatedly submit different usernames or accounts.

Your dashboard lists your enrolled classes, sessions/schedule and progress. Select the intended class, especially if several are active. Withdrawing from a class does not delete your previous responses/history. If you are re-added, existing evidence should remain. Contact Admin/Trainer when the expected class is absent. Do not create duplicate submissions to reconstruct missing history.

## Participate in live learning

The Trainer launches the current activity. Read the question, constraints, time and instructions. Respond through the matching control: select one or several choices, write text, enter a number, rate, rank, allocate points, match, sort, label/place on an image, draw, interact with video checkpoints or use the specified submission control. Use the shown options; do not assume every question accepts a free-text answer. Word Cloud may accept several words/phrases within length limits. Q&A and Ideas Board can require moderation; a saved item may remain hidden until approved. Voting and identity visibility depend on activity settings.

Submit once, wait for the actual saved confirmation and inspect your saved answer when supported. Before the Trainer reveals, the application confirms persistence without showing your score/correctness. Do not infer an answer from temporary ordering or other participants. Matching choices are intentionally separated from the correct associations. After reveal, read the permitted results/explanation and any personal feedback. Participation points do not automatically prove mastery.

For Team Challenge follow the assigned team instructions; the answer can be shared at team scope. For local file/image work, choose the intended file and check the saved submission. Do not upload executables, credentials or others' private data. Treat downloaded files as untrusted; a file download is not an instruction to run it. Link work must use a valid permitted URL. Video/checkpoint tasks depend on local media and browser codec support; ask for assistance if playback fails.

## Paths, missions and independent work

When offered a personal path, read the alternatives, choose the appropriate one and complete its steps. Follow the current milestone; do not assume all later work is open. Use the supplied prompts/resources as tools, not permission to send private data to an external AI service. External resources may need separate access and are not guaranteed offline. Submit the requested evidence, mark completion only when requirements are met and use Need help for Trainer support. If no submission is required, follow the explicit completion control. Read review feedback and revise when requested; opening a resource is not automatic completion.

In Participant-paced classes, use supported Previous/Next controls and keep saved work before moving. In Trainer-paced classes the live classroom follows the Trainer. In front-of-room delivery some scenes only ask you to observe. The Projector is a public display and does not expose your private profile or Trainer notes. Never put personal information in a response expected to be public.

## Saved work, feedback and profile

Use Saved responses to inspect any local pending queue. A queued response is not confirmed on the server until a successful retry. Keep the browser/device while resolving connectivity and check the current class/activity before retrying; do not assume every file submission is queued offline. Refresh/reconnect can restore persisted answers. If an activity has closed, ask the Trainer rather than forcing repeated retries. Do not clear browser storage during an unresolved queued response.

Open My profile to maintain your permitted contact/name/learning-goal details and photo. Some course/profile completion prompts require both Arabic/English names, email and mobile; enter accurate information only. Your contact information is restricted to yourself and authorized staff. Review communication/privacy consents; changing a preference retains consent history. Change your password through the provided form and keep it private. Administrators cannot safely receive your password in public messages.

Review learning history, class schedule/calendar, mission feedback, achievements/certificates and own learner reports where available. A certificate or progress indicator reflects recorded rules/evidence, not an external accreditation guarantee. If a report/download requires a current session, sign in again. Do not share report links containing credentials or private verification information. Ask the Trainer to correct missing attendance/review records; do not alter a downloaded report to make a false claim.

## Problems and safe departure

If you cannot join, confirm account, code, approval and capacity with the Trainer. If a response fails, read the error, check saved state/queue and retry only when appropriate. If the host is unavailable, keep your work and wait for reconnection; Internet access will not replace the classroom server. Expired sessions require sign-in. Unexpectedly visible private answers or another person's details should be reported immediately to the Trainer. Sign out on shared devices and close downloaded personal reports when finished.

## Current workspace repairs (RC1R10)

My profile → Change photo accepts validated PNG/JPEG up to 2 MiB. The saved picture appears in your account menu on return to the workspace. The main class/task loads before optional transcript/tools/inbox data; those sections can finish afterward. Loading still depends on the host and LAN.

To request admission, sign in with a registered participant account, choose Join class, enter the class code and wait for approval. Pending is not enrollment. Your assigned managing Trainer or Admin approves/declines subject to capacity/prerequisites. Check the request status and bell notifications. Read messages from the bell; Students do not send staff announcements. A role/group/team message reaches the recipients selected when it was sent.

My profile → Learning history lists your team under each class, including member names. Ask an authorized Trainer to move you or correct a team. A reusable group is different from a classroom team. The Trainer records Present/Late/Absent/Excused/Left early for a specific session; being online does not automatically record attendance. Ask for a correction when necessary; Not recorded differs from Absent.

The Trainer can move a live Projector pointer and add colored handwriting/text. These are presentation aids, not Student response submissions or automatic grading. They persist until the Trainer clears them. Continue submitting your own task through its activity control.

Your profile provides your authorized learner PDF report. Choose its language/dates, preview then download and protect it as private data. Installation-wide analytics and export choices belong to authorized staff. Check the current class, response acknowledgement and personal history when troubleshooting; do not treat a visible page as proof that a write saved.


## Your running class and saved work

When a class starts, its hero and current task lead your dashboard. Your learning, Learning tools, Learning record and Recent activity begin closed; use the arrow or keyboard to open them. Your open-section choices survive ordinary refreshes. The normal dashboard returns after delivery ends.

Choose one learning path and follow its steps. Copy copies only the prompt; long prompts scroll inside their card. Editable prompts, evidence and answers save for resume. Required evidence controls Next/Finish; optional support can be skipped honestly. Resource cards identify the source/tool and offer Open/Copy link. File/image completion uses the upload control. Your path and answers remain personal; another learner's actions do not advance you.

An already loaded page can preserve applicable edits/answers during a connection loss. They remain pending until confirmed. Reconnect to advance; review rejected/conflicting changes through Saved guided changes in your account menu. Newer work from another device is never overwritten automatically. Uploads/new page loads need the local server and external tools need their own connectivity. Your transcript/history remain available after class.

## RC1R14 — your panel and activity

Open your account menu → Personalize my panel. Choose English/Arabic, Light/Dark/System, and Workspace default, Teal, Blue, Indigo, Violet, Rose or Amber. Choices belong to your account, including when several users share a browser; another user's choices do not change your panel. The same account loads its saved choices on another device. UI language stays independent from course language. If disconnected, a pending choice stays on this device and syncs after reconnection.

My activity shows your complete recorded activity, 10, 25 or 50 rows per page. Filter by activity type, All time/Today/Last 7 days/Last 30 days/Custom dates, or search. From/Through dates include both selected local calendar dates. Previous/Next and the total reflect the full filtered history. Use Refresh for new records. The own profile also contains this panel for every role; Course Editors can open it from their account menu. Authorized staff Audit & history is separate and respects assigned class/group scope.

The running Student class is full width: a compact green LIVE marker sits above the hero, and the current task is below it. Use My workspace or the profile menu at the top; there is no duplicate learning sidebar. When the Trainer finishes this selected class, it stays ended and offers a workspace return without silently switching to another class.

Delete still uses the distinct Trash with history-preserving Restore. Permanent deletion requires an administrator to type the exact name and respects dependent classes. Old intentional Archive stays separate. Preserve data/storage/configuration during upgrades; follow RC1R14_UPGRADE_AND_ROLLBACK.md.


# RC1R15 — staff collaboration and scalable workspace

Notifications remain the existing notification inbox and Send notification. Staff chat is a separate private staff workspace, linked from Admin/Trainer sidebars and all staff account menus, including Course Editor. Participants cannot use staff chat/tasks. Direct/group text, bounded authenticated attachments, browser-recorded voice notes, read receipts and two-person WebRTC audio/video calls are available according to administrator policy and per-user permissions. Group creators manage membership. Only members can read messages/files; administrator status does not grant access to private conversations. Removed members lose access. Calls need HTTPS or loopback for devices and working ICE connectivity; optional administrator STUN/TURN is supported, including TCP relays. This is not WhatsApp feature parity or end-to-end encrypted message storage.

Staff Tasks & calendar supplies own tasks, supervisor assignments with assign_tasks permission, statuses, priority, start/due dates, notes, checklists, daily/weekly/monthly/yearly recurrence and day/week/month/year views. Calendar counts cover the complete authorized range; the agenda is paged. Completing a recurring task creates its next scheduled task. Both creator and assignee can update shared task progress; only creator can reassign/remove. Administrator does not gain access to unrelated private tasks. Export the authorized calendar as ICS.

Participants use My class notes inside the running class, save/edit their own text notes and export them. Workspace/profile notes remain accessible after class finish. No Trainer/Admin/other participant can read personal notes. Permanently deleting the class also removes its personal notes; export first.

Visible Admin/Trainer overview panels now have the same complete 10/25/50 activity paging, search/type/time/date filters as the Student panel. Click an event for an accessible detail dialog. Details use a human-readable allowlist, never raw event JSON, answers, tokens, private cues or message/note content. The live replay uses the same safe dialog. The live-operations hero now follows the account panel color and light/dark theme.

Selection forms use searchable, scrollable paginated tables, page select/remove, clear and selected-only actions. Form selections and assignment roles remain stable across pages. Group, audience, team, class participant/staff/course and other large native selection controls share this behavior. Existing people lists are paged locally after authorized retrieval; staff chat directory is SQL paged. Class creation fetches authorized published course-version options once instead of one request per course. Bulk roster selection adds/removes up to 500 participants atomically and preserves historical progress.

The staff calendar uses each browser’s local time zone, including tasks close to midnight. Personal-note export streams the full authorized selection.


## RC1R16: reliable Guided saves

Acknowledge, evidence and answers must receive server confirmation before required Next/Finish. Actual offline edits remain saved on this device and replay when the server is reachable. A server/authentication/validation error has its own message; use Saved guided changes to review, retry or discard unresolved work. Do not clear browser storage. Reload old tabs after upgrade; an old queued answer without a revision needs review, preserving newer work. Uploads and fresh page loads need a connection. Staff workspace tools from RC1R15 remain included. See the release certification and root-cause reports for tested scope and deployment limits.
