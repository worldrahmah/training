# Required Final Course Deliverables

1. Import-ready `<COURSE>_vX.Y.course.zip`.
2. Authoring/source package containing Course Freeze, Decision Log and every approved Module Specification.
3. Workflow Tree specifications / integration ledgers.
4. Complete asset/source ledger.
5. Independent course review report.
6. Exact Core validator report.
7. Preview/rehearsal report with branch/path coverage.
8. Version/release notes.
9. SHA256SUMS and release manifest for the final return.
10. Optional class-setup template/roster starter if requested.
