# Course Assembly Guide

A Training Engine v2.0 course package uses one canonical model whether authored externally or edited in the Visual Course Builder.

Recommended structure:

```text
COURSE_vX.Y.course.zip
├── manifest.json
├── course.json
├── modules/
│   ├── module_01.json
│   └── ...
└── assets/
```

## When modules are authored one at a time
1. Keep one owner-approved Course Freeze and Decision Log as course authority.
2. Every module return includes an Integration Ledger.
3. Integrate only into an editable Draft package/version.
4. Recalculate course duration/module order/objective references after integration.
5. Detect duplicate IDs, achievement keys and asset paths.
6. Run the exact validator after every integration.
7. Preview the integrated module in context, not only standalone.
8. Before final publication, run full-course independent review and full-path simulation.

Never modify a historical published/delivered package in place.
