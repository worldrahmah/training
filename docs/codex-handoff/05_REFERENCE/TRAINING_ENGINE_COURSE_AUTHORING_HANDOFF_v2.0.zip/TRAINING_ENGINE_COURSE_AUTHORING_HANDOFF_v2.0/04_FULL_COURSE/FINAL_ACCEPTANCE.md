# Final Course Acceptance — Training Engine Core v2.0 FINAL

Only claim `COURSE_READY_FOR_CLASS_SETUP` when all applicable checks pass.

## Frozen architecture
- owner-approved Course Freeze exists;
- total timing adds exactly;
- module order/objective mapping complete;
- no unresolved material scope item remains.

## Complete course content
- every module passes Module Acceptance;
- Trainer/Projector/Participant journeys are complete;
- all walkthroughs, missions, activities, workflows and participant paths contain final content;
- all prompts/answer keys/submissions/scoring/achievements are complete;
- every required asset exists with provenance;
- Internet dependencies have truthful fallback where required.

## Workflow/runtime compatibility
- new course targets schema 2.0;
- only Core v2.0 Component Catalog types used;
- every workflow graph resolves;
- class-level vs participant-level branching correct;
- every participant path can run independently and converge as designed;
- no custom executable runtime content exists;
- exact Core validator has zero blocking errors and material warnings are repaired/adjudicated.

## Preview/rehearsal
- Trainer view and cues verified;
- Projector scenes are room-readable/presentation-ready;
- Student mobile/desktop experience verified;
- every class branch and participant path simulated;
- result charts/reveals/timers/submissions validated;
- relevant Arabic RTL/English LTR and theme behavior verified;
- restart/resume-sensitive course behavior reviewed.

## Release
- final `.course.zip` sealed;
- authoring/source bundle complete;
- Course Freeze + module specs + review + validator + asset ledger included;
- manifest/checksums pass;
- SHA-256 reported;
- package imports into untouched Core v2.0 FINAL without Core-source modification.
