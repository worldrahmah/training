# Permanent Course Production Workflow v2.0

1. Discovery/resource intake.
2. Owner-approved Course Freeze.
3. Module specification (one-by-one or all modules).
4. Module content/assets production.
5. Module independent review + validation + Preview.
6. Integrate into editable Draft.
7. Repeat until all modules pass.
8. Full-course assembly and timing/reference reconciliation.
9. Independent full-course review.
10. Exact Core validation.
11. Trainer/Projector/Participant rehearsal and branch/path simulation.
12. Seal `.course.zip` and authoring return.
13. Import into Core, create Class, assign Trainers, enroll/import Participants, teams/sessions/readiness.
14. Publish/freeze exact course version; future edits derive a new Draft.
