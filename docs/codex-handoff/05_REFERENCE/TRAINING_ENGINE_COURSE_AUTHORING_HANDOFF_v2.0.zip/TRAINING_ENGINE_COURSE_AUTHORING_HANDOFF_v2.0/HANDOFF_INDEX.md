# Training Engine Course Authoring Handoff v2.0 — Index

Exact Core: `TRAINING_ENGINE_CORE_v2.0_FINAL.zip`  
SHA-256: `449387c10b5b87e67b8c1c8f6bfd331b77dd0757af4ade9a532b3dd860914055`

## Purpose
Reusable new-chat package for:
- brainstorming/freeze of a new course;
- building a complete course;
- building one module/milestone/section at a time;
- integrating approved modules into a course Draft;
- updating/repairing a course while preserving version history.

## Fast start
- Full course: `00_START/QUICK_START_FULL_COURSE.txt`
- One module: `00_START/QUICK_START_MODULE.txt`
- Master rules: `00_START/MASTER_COURSE_OR_MODULE_EXECUTION_PROMPT.md`

The exact v2 authoring kit, schemas, validator contract, example packages and selected Core documentation are nested under `01_CORE_AUTHORITY/`.
