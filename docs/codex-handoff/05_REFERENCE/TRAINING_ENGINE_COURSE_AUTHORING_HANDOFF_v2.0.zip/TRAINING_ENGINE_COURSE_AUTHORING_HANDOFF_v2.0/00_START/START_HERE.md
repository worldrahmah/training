# Start Here — Training Engine Course Authoring Handoff v2.0

This package is the reusable authority for creating **any new Training Engine v2.0 course**, either as a complete course in one project/chat or **one module/milestone/section at a time**.

Exact Core authority: `TRAINING_ENGINE_CORE_v2.0_FINAL.zip`  
SHA-256: `449387c10b5b87e67b8c1c8f6bfd331b77dd0757af4ade9a532b3dd860914055`

The Core source is not part of course authoring scope. Course packages are declarative. Use only the exact Component Catalog, schemas and templates shipped here.

## Supported working modes
1. **DISCOVERY MODE** — idea/resources exist but course architecture is not frozen.
2. **FULL COURSE MODE** — freeze/design and build the complete course.
3. **MODULE MODE** — design/build one approved module or milestone at a time against a frozen course architecture or existing course package.
4. **COURSE UPDATE MODE** — derive a new course version from an existing package; never mutate a delivered historical version.
5. **REPAIR MODE** — repair a package or module that failed validation/review without unrelated redesign.

Always read `00_START/READ_ORDER.md` before authoring.
