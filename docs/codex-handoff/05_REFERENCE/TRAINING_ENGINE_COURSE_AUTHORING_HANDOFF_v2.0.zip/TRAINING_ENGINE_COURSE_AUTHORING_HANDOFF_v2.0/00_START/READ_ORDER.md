# Mandatory Read Order

Before designing or editing course content, read in this order:

1. `00_START/START_HERE.md`
2. `00_START/MASTER_COURSE_OR_MODULE_EXECUTION_PROMPT.md`
3. `01_CORE_AUTHORITY/CORE_SHA256.txt`
4. `01_CORE_AUTHORITY/authoring-kit/AUTHORING_GUIDE.md`
5. `01_CORE_AUTHORITY/authoring-kit/COMPONENT_CATALOG.md`
6. `01_CORE_AUTHORITY/authoring-kit/VALIDATION_RULES.md`
7. Every schema under `01_CORE_AUTHORITY/authoring-kit/schemas/`
8. Every template under `01_CORE_AUTHORITY/authoring-kit/templates/`
9. `01_CORE_AUTHORITY/docs/ARCHITECTURE.md`
10. `01_CORE_AUTHORITY/docs/BACKWARD_COMPATIBILITY.md`
11. `01_CORE_AUTHORITY/docs/LOCALIZATION.md`
12. `01_CORE_AUTHORITY/docs/REPORTING.md`
13. `02_DISCOVERY_AND_FREEZE/COURSE_FREEZE_TEMPLATE.md`
14. `03_MODULE_AUTHORING/MODULE_SPECIFICATION_TEMPLATE.md`
15. `03_MODULE_AUTHORING/WORKFLOW_TREE_TEMPLATE.md`
16. `03_MODULE_AUTHORING/MODULE_ACCEPTANCE.md`
17. `04_FULL_COURSE/COURSE_ASSEMBLY_GUIDE.md`
18. `04_FULL_COURSE/FINAL_ACCEPTANCE.md`
19. `04_FULL_COURSE/FINAL_DELIVERABLES.md`
20. The prompt matching the selected mode under `05_PROMPTS/`

If source files/resources are attached, inventory them after Core authority is read and before freezing content.

## Mandatory checkpoint
Record, before authoring:
- exact Core v2.0 FINAL SHA verified;
- selected mode;
- frozen/not-frozen course status;
- existing course package/version, if any;
- resources inventoried;
- supported components understood;
- no unsupported runtime behavior will be invented;
- next approval gate.
