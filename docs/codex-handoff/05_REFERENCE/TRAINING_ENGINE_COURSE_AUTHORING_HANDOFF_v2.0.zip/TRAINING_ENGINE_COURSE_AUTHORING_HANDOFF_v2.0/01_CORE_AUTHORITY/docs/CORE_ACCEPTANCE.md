# Training Engine Core v2.0 FINAL — Verification Record

RC4 completed the automated gates and was promoted to v2.0 FINAL after owner acceptance. The checklist below remains the reusable verification contract for any installation.

## Automated gates

- [x] JavaScript/MJS syntax checks
- [x] Complete Arabic/English translation check
- [x] Responsive UI contract check
- [x] v1.2 smoke regression
- [x] v1.2 permission/report/content regression
- [x] restart persistence
- [x] backup/restore
- [x] Super Admin regression
- [x] granular Trainer permission regression
- [x] schema-2 workflow course import
- [x] immutable version -> Draft -> validate -> publish
- [x] Class creation with assigned trainer(s)
- [x] Class session CRUD creation path
- [x] Participant enrollment and historical-preserving removal
- [x] rich participant profile/account
- [x] notifications/messages
- [x] participant-independent branching
- [x] Need Help / Help Queue lifecycle
- [x] milestone progress and completion
- [x] projector navigation control
- [x] analytics
- [x] non-interactive Super Admin live monitoring
- [x] populated v1.2 -> v2 migration regression


## Owner acceptance — Responsive UI/UX

Test both English LTR and Arabic RTL where applicable.

- [ ] 320px phone: no page-level horizontal scrolling or clipped primary controls.
- [ ] 375/390px phone: Super Admin, Trainer and Participant navigation remain complete and usable.
- [ ] 430/480px phone: forms, modals, class setup, reports and Builder controls reflow without overlap.
- [ ] 768px tablet portrait: mobile shell/navigation is intentional and no desktop sidebar crushes content.
- [ ] 1024px tablet/compact laptop: Course Builder, live delivery and Class Management remain readable and operable.
- [ ] 1366x768 laptop: all primary workflows fit without browser zoom.
- [ ] 1920x1080 desktop: layouts use available space without excessive stretching.
- [ ] Mobile landscape: navigation/actions remain reachable and dialogs remain usable.
- [ ] Data tables scroll only inside their table container; the overall page never requires horizontal scrolling.
- [ ] Workflow graph scrolls locally when wider than its panel.
- [ ] Modals/drawers fit narrow screens and all save/cancel/destructive actions remain reachable.
- [ ] Touch targets are comfortably usable and form inputs do not trigger mobile zoom.
- [ ] Long Arabic/English names, course titles and labels truncate/wrap without breaking layout.
- [ ] Light/Dark/System themes remain legible at every tested breakpoint.

## Owner acceptance — Courses

- [ ] Create a new Course from Super Admin.
- [ ] Confirm an editable initial Draft is created automatically.
- [ ] Open the Course Builder without editing JSON.
- [ ] Add/reorder/duplicate/delete a milestone/module.
- [ ] Add an objective, activity, mission and participant path.
- [ ] Add presentation blocks and guided steps.
- [ ] Build a visual workflow with nodes and edges.
- [ ] Configure a class-level branch and a participant-level branch.
- [ ] Preview as Trainer, Projector and Participant.
- [ ] Validate and publish the Draft.
- [ ] Confirm the published version cannot be edited in place.
- [ ] Derive a new Draft from the published version.
- [ ] Import an older schema 1.0/1.1 course and confirm it remains usable.

## Owner acceptance — Classes

- [ ] Create a Class and choose the exact Course Version.
- [ ] Enter dates, start/end times, location, timezone and capacity.
- [ ] Assign exactly one Lead Trainer.
- [ ] Assign an additional Trainer or Assistant Trainer.
- [ ] Select existing participants during Class creation.
- [ ] Preview and import participants from CSV.
- [ ] Reopen Manage Class and verify trainers and roster persisted.
- [ ] Add another existing participant.
- [ ] Remove a participant and verify history is preserved rather than deleted.
- [ ] Add a Class Session.
- [ ] Create/manage Teams.
- [ ] Open Attendance.
- [ ] Run Classroom Readiness.
- [ ] Move the Class through Draft/Scheduled/Active/Completed/Archived as appropriate.

## Owner acceptance — Permissions

- [ ] Create a secondary Trainer.
- [ ] Assign Course View/Edit permissions visually.
- [ ] Assign Class View/Manage permissions visually.
- [ ] Confirm the Trainer sees only permitted Courses/Classes.
- [ ] Confirm a Lead Trainer can administer the assigned Class.
- [ ] Confirm an unauthorized Trainer cannot alter unrelated Classes/participants.

## Owner acceptance — Live delivery

- [ ] Super Admin can observe every live class without taking classroom control.
- [ ] Trainer sees connected/present/working/help/finished participants for their Class.
- [ ] Two participants can choose different personal paths simultaneously.
- [ ] NEED HELP enters the Trainer Help Queue with participant/path/step/time.
- [ ] Resolving one help request does not interrupt other participants.
- [ ] Refresh/reconnect restores participant path and current step.
- [ ] Restart during active practice preserves/reconstructs state.

## Owner acceptance — Projector

- [ ] Uses the display as a true presentation stage, not a small webpage card.
- [ ] Titles/body/results are readable from the back of a room.
- [ ] Images/charts/results use presentation scale.
- [ ] Chrome is minimal during delivery.
- [ ] Previous/Next works.
- [ ] Arrow/PageUp/PageDown/Space presentation navigation works.
- [ ] Arabic RTL and English LTR both render correctly.
- [ ] Course presentation/title/body font choices are respected.

## Owner acceptance — Reports and recovery

- [ ] Course/Class/Participant/Trainer analytics open correctly.
- [ ] Path/help/attendance/completion analytics reflect delivered data.
- [ ] Exports work.
- [ ] Backup succeeds.
- [ ] Restart preserves data.
- [ ] Restore reproduces the backed-up state.

Promotion status: **COMPLETE — v2.0 FINAL**.


## Projector presentation acceptance — v2.0 FINAL

- [ ] Live Projector shows no Course/Class utility chrome or language/theme buttons.
- [ ] Simple heading/body content renders as one intentionally composed presentation scene, not separated webpage columns.
- [ ] Titles and body are readable from the back of a room on a 1080p display.
- [ ] Question/options scenes use presentation-scale composition.
- [ ] Charts/results, images, cards, statistics, quotes and timers scale for projection.
- [ ] 16:9 and ultrawide displays preserve a centered presentation-safe composition.
- [ ] Arabic RTL and English LTR remain visually correct.
- [ ] Previous/Next/keyboard/clicker navigation still works without persistent audience-facing controls.
