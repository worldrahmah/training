# Training Engine Core v2.0 FINAL — Release Record

- Final version: `2.0.0`
- Promotion source: owner-accepted `v2.0 RC4` runtime
- Baseline lineage: accepted `v1.2 FINAL` -> v2 RC1 -> RC2 -> RC3 -> RC4 -> v2.0 FINAL
- Promotion policy: no runtime feature/code changes during RC4-to-FINAL promotion; release metadata and documentation only.
- Backward compatibility: schema 1.0, 1.1 and 2.0 course packages remain supported under the v2 contract.
- Course-authoring authority: use the `authoring-kit/` shipped inside this exact FINAL release.
- Historical delivered course versions remain immutable; edits derive new drafts/versions.
- FINAL status: owner accepted for course authoring and controlled delivery.
