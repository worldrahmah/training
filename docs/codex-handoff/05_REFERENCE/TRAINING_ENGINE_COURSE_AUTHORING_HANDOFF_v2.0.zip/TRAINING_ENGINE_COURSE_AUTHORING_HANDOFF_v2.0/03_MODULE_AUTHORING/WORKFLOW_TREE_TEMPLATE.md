# Milestone Workflow Tree Specification

## Start node
`[node-id]`

## Nodes
| Node ID | Node type | Human purpose | References activity/mission/path |
|---|---|---|---|

Supported node types only: `trainer_scene`, `class_interaction`, `trainer_walkthrough`, `practice_start`, `participant_choice`, `participant_path`, `convergence`, `closing`, `activity`, `mission`.

## Edges
| From | To | Scope | Condition | Rationale |
|---|---|---|---|---|

Scope is only `class` or `participant`.

## Simulation cases
- default trainer path;
- each class-level winning/conditional branch;
- every participant choice/path;
- convergence and closing;
- no-answer/low-response fallback where relevant;
- Internet-unavailable fallback where relevant.
