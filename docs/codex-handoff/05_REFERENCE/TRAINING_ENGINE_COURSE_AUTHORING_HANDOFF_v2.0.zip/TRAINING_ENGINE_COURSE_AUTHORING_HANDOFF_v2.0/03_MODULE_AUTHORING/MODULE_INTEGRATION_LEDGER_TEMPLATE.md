# Module Integration Ledger

- Course ID/version authority:
- Course Freeze hash/reference:
- Module ID/title:
- Module version/status:
- Intended insertion/order:
- Objective IDs referenced:
- New asset paths:
- New achievement keys:
- New internal IDs introduced:
- Cross-module dependencies:
- Course-level fields requiring update (duration/objectives/branding/etc.):
- Validator result:
- Independent review result:
- Integration status: NOT_INTEGRATED / INTEGRATED_IN_DRAFT
