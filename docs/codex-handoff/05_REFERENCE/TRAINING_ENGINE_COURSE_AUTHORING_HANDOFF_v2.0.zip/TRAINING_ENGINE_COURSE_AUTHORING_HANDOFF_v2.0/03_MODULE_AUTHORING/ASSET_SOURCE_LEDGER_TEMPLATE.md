# Asset and Source Ledger

| Asset ID | File/path | Type | Used in | Source/provenance | Rights/status | Alt/caption | Offline role |
|---|---|---|---|---|---|---|---|
