# Module Acceptance — v2.0

Only claim `MODULE_READY_FOR_COURSE_INTEGRATION` when all applicable checks pass:

## Authority
- frozen Course Freeze/existing course authority identified;
- module does not redesign unrelated approved course architecture;
- exact timing matches its frozen allocation.

## Complete experience
- Trainer journey complete with private cues/controls/fallbacks;
- Projector journey is true presentation content, not webpage copy;
- Participant journey complete;
- every walkthrough, activity, mission and path has final copy;
- all class-level and participant-level branches are explicit;
- convergence/closing exists where required;
- every path has completion behavior and resume-safe steps;
- assets/prompts/submissions/scoring/achievements/fallbacks complete.

## Core compatibility
- schema 2.0 valid;
- only supported Component Catalog types used;
- workflow node/edge scopes valid;
- all IDs/objectives/assets/references resolve;
- no executable custom code;
- exact Core validator returns zero blocking errors for the containing package/test fixture.

## Quality
- independent review complete;
- Preview/simulation covers trainer path, class branches and every participant path;
- Arabic/English direction/accessibility as applicable;
- offline behavior truthful;
- reporting evidence is naturally capturable by Core.

## Return
- module specification;
- module JSON;
- assets;
- asset/source ledger;
- workflow tree spec;
- review report;
- validator report;
- integration ledger;
- SHA/checksums for sealed return.
