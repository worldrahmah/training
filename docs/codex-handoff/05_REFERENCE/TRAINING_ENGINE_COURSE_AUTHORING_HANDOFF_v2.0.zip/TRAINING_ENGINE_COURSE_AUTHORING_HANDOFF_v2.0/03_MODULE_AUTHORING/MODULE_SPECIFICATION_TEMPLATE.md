# Module/Milestone Specification — [Title]

Status: PROPOSED / OWNER-APPROVED-FROZEN / IMPLEMENTED

## Identity
- module ID:
- title/subtitle:
- exact duration:
- objective IDs:
- transformation/purpose:
- completion evidence:

## Timing map
Exact minute-by-minute or segment timing. Total must equal module duration.

## Trainer journey
For every segment: what Trainer sees, says/does, controls available, cue, expected classroom state, fallback.

## Projector journey
Every true presentation scene in order: purpose, content blocks, reveal behavior, result visualization, typography/media requirement, navigation relationship.

## Participant journey
Waiting/live states, choices, responses, individual/team scope, personal practice paths, Back/Next/Finished behavior, submissions and feedback.

## Walkthroughs
For each: objective, trainer demonstration steps, private cues, projector scenes, student micro-interactions, tools/assets, fallback.

## Activities/interactions
For each: Core activity type, question/copy, choices/answer key if applicable, response scope, result display, completion gate, scoring, trainer reveal/control.

## Missions
Goal, estimated time, instructions/steps, prompts/editable prompts, assets/resources/tool links, submission, score, achievement, offline fallback.

## Participant paths
Each independent path and ordered step list; step completion types; Internet requirement; offline fallback; convergence.

## Workflow
Reference the Workflow Tree spec. Clearly identify class-scoped vs participant-scoped edges.

## AI/help/live progress expectations
State which steps may trigger participant NEED HELP and what path/step/progress evidence should be visible to Trainer. Runtime help queue/progress UI is Core-owned.

## Assets/source ledger
List every required asset and provenance.

## Data/reporting evidence
What the Core should naturally capture: responses, completion, scores, objective evidence, path choice, time, help requests, submissions, achievement.

## Accessibility/localization/privacy
RTL/LTR, alt text, readable projector composition, consent/privacy considerations.

## Acceptance
No placeholders; all IDs/branches/assets resolve; validator clean; Preview covers trainer/class branch and every participant path.
