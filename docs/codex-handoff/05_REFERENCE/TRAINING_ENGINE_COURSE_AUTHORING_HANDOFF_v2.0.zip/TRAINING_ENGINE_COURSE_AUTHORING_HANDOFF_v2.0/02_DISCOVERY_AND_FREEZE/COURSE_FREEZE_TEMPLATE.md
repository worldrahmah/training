# Course Freeze — [Course Title] [Version]

Status: PROPOSED / OWNER-APPROVED-FROZEN

## Identity
- Course ID/version:
- Public title/subtitle:
- Language/direction:
- Audience/prerequisites:
- Class size/delivery model:
- Total instructional duration:
- Session/day pattern:

## Promise and objectives
- Course promise/transformation:
- Course objectives (stable IDs + measurable evidence):
- Cross-course skills/safety/judgment requirements:

## Frozen module map
For each module: title, exact minutes, purpose/transformation, objective mapping, primary walkthrough/practice/assessment concept.

## Assessment/completion
- course completion rule:
- scoring policy:
- achievements/badges:
- trainer-reviewed items:

## Delivery/tool policy
- external tools:
- Internet assumptions:
- offline fallback policy:
- asset/source policy:
- privacy/consent policy:

## Branding/presentation
- UI/course language:
- presentation/title/body typography overrides if any:
- projector visual direction:

## Version rules
- published versions immutable;
- future change creates a new draft/version;
- unresolved items: NONE / list explicitly.
