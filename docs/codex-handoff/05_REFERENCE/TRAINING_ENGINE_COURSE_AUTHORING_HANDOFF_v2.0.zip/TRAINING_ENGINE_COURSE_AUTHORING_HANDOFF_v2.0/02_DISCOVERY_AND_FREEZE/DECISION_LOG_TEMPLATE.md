# Course Decision Log

| ID | Date | Decision | Status | Rationale | Affects |
|---|---|---|---|---|---|
| D-001 | | | PROPOSED/APPROVED | | |
