# Resource Intake Guide

For every supplied PDF/document/deck/dataset/image/link, record:
- identifier and filename;
- owner/provenance;
- what it can support;
- authoritative source vs inspiration;
- freshness/date sensitivity;
- copyright/licensing concern;
- privacy/sensitive-data concern;
- candidate use: trainer reference, projector asset, participant resource, mission input, quiz evidence, background only;
- required transformation/rewrite;
- whether external verification is required.

Do not copy copyrighted source material into course assets unless permitted. Prefer original teaching assets based on cited facts.
