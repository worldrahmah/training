# New Course Brief

- Working title:
- Topic/domain:
- Why this course should exist:
- Target audience:
- Starting knowledge/prerequisites:
- Desired transformation/outcome:
- Delivery language(s):
- Class size:
- Total duration:
- Session pattern:
- Delivery setting (classroom/online/hybrid):
- Practical vs theory preference:
- Required tools/resources:
- Known constraints:
- Available source material:
- Assessment/certification expectations:
- Accessibility/localization needs:
- Items explicitly out of scope:
