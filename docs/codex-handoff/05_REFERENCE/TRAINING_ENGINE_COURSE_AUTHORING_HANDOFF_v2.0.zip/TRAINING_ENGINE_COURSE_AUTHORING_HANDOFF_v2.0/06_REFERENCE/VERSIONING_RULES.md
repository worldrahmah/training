# Course Versioning Rules

1. Published/delivered course versions are immutable.
2. Editing a published/imported version creates a new editable Draft derived from it.
3. Drafts may be freely edited/deleted before publication.
4. A module authored for an existing course must bind to the correct Course Freeze/version lineage.
5. Historical Classes remain tied to the exact version delivered.
6. New schema 2.0 content must not require mutation of old schema 1.x packages.
