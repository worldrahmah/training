# Core v2 Features Available to Course Authors

Course authors may rely on the Core for:
- professional responsive Trainer, Projector and Participant rendering;
- Arabic RTL / English LTR and theme handling;
- course typography overrides through safe slots;
- true projector slide/scene navigation;
- polls, quizzes, answers, ratings, ranking and live result charts;
- presentation blocks including hero/image/image_text/cards/steps/comparison/table/callout/statistic/quote/checklist/chart/gallery/prompt/editable_prompt/resource_list/media;
- missions and guided participant paths;
- class-scoped and participant-scoped workflow branching;
- independent simultaneous participant paths;
- participant resume state;
- Back/Next/Finished path navigation;
- NEED HELP and Trainer Help Queue;
- live per-participant milestone/path progress;
- submissions, scores, achievements and objective evidence;
- timers, reveal and practice gates;
- safe packaged assets and external links;
- import/validation/versioning/backup/reporting handled by Core.

Authors configure these declaratively; they do not implement them with custom code.
