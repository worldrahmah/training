# Which Mode to Use

- Only an idea/resources, no approved architecture -> DISCOVERY.
- Approved course map, want everything built -> FULL_COURSE.
- Approved course, want Milestone/Module N only -> MODULE.
- Existing published course needs content changes -> COURSE_UPDATE (derive new Draft/version).
- Validator/reviewer found bounded defects -> REPAIR.

For complex courses, prefer MODULE mode one milestone at a time, then assemble. This keeps owner review precise and reduces cross-module defects.
