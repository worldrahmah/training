# Do Not Invent Runtime Behavior

Never invent:
- unsupported activity/component/chart/submission types;
- arbitrary JavaScript/HTML/CSS/SQL;
- external API integrations not implemented by Core;
- hidden background automation;
- unsupported conditional expressions;
- unsafe asset types;
- fields claimed to have runtime effect when Core treats them as metadata only.

If the design genuinely requires a missing runtime capability, stop and label it `CORE_EXTENSION_REQUIRED` before course implementation.
