# Core Upgrade Scope

## Requested version
TBD

## Requested features / repairs
- 

## Explicitly out of scope
- Course-specific content changes unless supplied strictly as regression fixtures.

## Data/schema impact expected?
TBD

## New UI surfaces?
TBD

## New course component types?
TBD

## New roles/permissions?
TBD

## New external dependencies?
TBD

## Owner-supplied compatibility fixtures
- Existing `.course.zip` packages: TBD
- Existing database/backup: TBD

## Acceptance notes
Every requested feature must be implemented without breaking the backward-compatibility contract.
