# Compatibility Fixture Intake

For the strongest possible upgrade verification, attach these to the new chat when available:

- exact current Core ZIP (already included in this handoff);
- any real `.course.zip` packages already imported/used;
- a sanitized backup/export of the current Core database/workspace if real delivery data already exists;
- screenshots or notes for any workflow whose exact UI behavior must remain unchanged;
- any external operational scripts used with the Core.

Do not modify historical course packages merely to make them pass the new Core. They are regression fixtures.
