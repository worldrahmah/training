# Regression Test Protocol

The upgrade must prove both **new capability** and **old capability preservation**.

## Phase A — Untouched baseline
On the exact v1.2 baseline:
- verify ZIP/path safety and hash;
- run the supplied self-tests;
- run course validator on bundled demo course;
- record baseline outputs/checkpoints.

## Phase B — Upgrade implementation
For each new feature:
- add direct tests;
- add authorization tests where relevant;
- add persistence/restart tests where relevant;
- add EN/AR and responsive UI checks where relevant;
- add validation/schema tests for new course components.

## Phase C — Backward compatibility
On the upgraded Core:
- run the complete old v1.2 test suite unchanged where technically possible;
- validate/import the exact old demo course unchanged;
- preview and deliver its activities without editing it;
- migrate a populated v1.2 database fixture;
- verify classes, users, students, answers, scores, notes, reports, history and exports;
- restart and re-check persistence;
- test backup and restore.

## Phase D — User-supplied production fixtures
When the owner supplies real historical course packages/database backups, they become mandatory compatibility fixtures. Test them unchanged.

## Phase E — UI/UX regression
Check at minimum:
- Trainer, Participant, Projector, Preview;
- English LTR and Arabic RTL;
- Light/Dark/System;
- mobile widths (~320/375/430), tablet, desktop, projector;
- same-browser multi-tab sessions;
- LAN/mobile access;
- refresh/reconnect/current-activity recovery;
- no visible developer/internal labels.

## Phase F — Failure-path testing
Exercise malformed import, permission denial, duplicate/invalid roster data, missing asset, invalid branch, interrupted connection, server restart, invalid migration state, and restore failure behavior.

## Final rule
Do not claim success based only on new-feature smoke tests. Compatibility evidence is a release requirement.
