# Training Engine v1.2 — Validation Rules

## Package safety
- ZIP paths must be relative and path-safe.
- `manifest.json` must exist and identify a Training Engine course package.
- `course.json` (or the declared course file) must exist and parse as JSON.
- Manifest checksums, when supplied, must match exactly.
- Executable/active package assets are rejected.
- Referenced assets must exist in ZIP imports.

## Course
- `format` must be `training-engine-course`.
- `schema_version` must be `1.0` or `1.1`; new packages should use `1.1`.
- course ID/title are required.
- direction is `ltr` or `rtl`.
- module IDs are unique.
- activity IDs are unique across the course.
- mission IDs are unique across the course.

## Activities
- type must exist in `COMPONENT_CATALOG.md`.
- title should be human-facing and not expose internal IDs.
- poll/single/multiple-choice require at least two options.
- true/false correct answers must be valid.
- numeric/rating ranges must be coherent.
- response scope is `individual` or `team`.
- result display must be supported or will trigger a warning/fallback.
- content blocks must use supported types.
- image/media/resource blocks require a safe asset or HTTPS source.
- chart blocks require supported chart type and a data array.
- flow/branch targets must exist within the same module.
- completion rates must be > 0 and <= 1; minimum response count >= 1.

## Missions
- ID and title required.
- guided steps strongly recommended.
- submission type must be `none`, `text`, `url`, `file`, or `image`.
- referenced objective IDs must exist when objectives are defined.

## Objectives
When course objectives are defined, every referenced objective ID must exist.

## Human-facing quality checks
The engine validator focuses on structural safety. An independent reviewer should additionally verify:
- timing realism
- clear learning objectives
- no dead-end flow
- no hidden prerequisite
- understandable Arabic/English copy
- appropriate privacy and safety language
- valid prompt/tool instructions
- meaningful completion evidence
- accessibility of images via alt text

## Import behavior
Errors block import. Warnings require review but may not block import. Course import is transactional; validation failure must leave installed course data unchanged.
