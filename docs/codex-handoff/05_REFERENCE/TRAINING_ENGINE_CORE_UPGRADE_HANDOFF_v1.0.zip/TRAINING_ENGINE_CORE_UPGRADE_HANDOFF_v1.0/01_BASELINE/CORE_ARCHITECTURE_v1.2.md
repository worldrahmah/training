# Training Engine Architecture v1.2

## Product boundary

```text
AUTHORING KIT / AI CHAT
        │
        ▼
  .course.zip package
        │
        ▼
VALIDATOR → PREVIEW → TRANSACTIONAL IMPORT
        │
        ▼
 IMMUTABLE COURSE VERSION
        │
    ┌───┼───────────────┐
    ▼   ▼               ▼
 TRAINER   PROJECTOR   PARTICIPANT
    └────────┬───────────┘
             ▼
      LIVE CLASSROOM STATE
             ▼
           SQLITE
 users / classes / responses / progress / reports / audit
```

Course content and delivery records are deliberately separate. A class points to one exact course version so historical delivery remains reproducible.

## Runtime

- Node.js built-in HTTP server.
- Node.js built-in SQLite (`node:sqlite`).
- Server-Sent Events for live classroom push/reconnect.
- HTTP APIs for actions, responses and submissions.
- Plain responsive HTML/CSS/JavaScript clients.
- No npm runtime dependencies.
- No cloud dependency.

## Roles and access

- **Administrator**: system, course import, staff, workspace, demo and backup authority.
- **Lead Trainer**: administers assigned class roster/trainers/lifecycle and can deliver it.
- **Trainer / Assistant Trainer**: can deliver and inspect assigned classes within their scope.
- **Participant**: sees only own enrolled classes, own learning record and current live activity.

Reports, history and student directories are scoped to authorized classes for non-administrators.

## Content engine

The Core renders declarative content blocks and activities. Course packages cannot execute arbitrary JavaScript, server code or custom CSS.

Supported presentation families include hero/text/images/cards/steps/comparison/table/callout/statistic/quote/checklist/assets/charts/media. Supported interaction families include polls/quizzes/text/numeric/rating/reaction/confidence/ranking/timer/team/checklist/URL/file/image/reflection/self-assessment.

The same definition is interpreted for three audiences:
- Trainer: controls, status, private cue.
- Projector: clean presentation/result surface.
- Participant: permitted response/mission experience.

## Live lifecycle

Typical response activity:

`Open → Accept responses → Close → Reveal → Finish`

One open activity per class is enforced. Completion gates can require a minimum count/rate before close, with an explicit trainer override. Branching can point to subsequent activities based on configured outcomes.

## Assets

Course packages may include validated local assets such as PNG/JPEG/WebP images, PDF, text/CSV, office documents, video and audio. Unsafe executable web assets are rejected from imported packages.

## Sessions and persistence

Each browser tab stores its own bearer token in `sessionStorage`, which allows Trainer and Participant tabs in one browser without replacing one another. Session records and classroom state live in SQLite; refresh and server restart preserve the persisted state.

## Backup and recovery

Administrator backup uses SQLite `VACUUM INTO` plus local storage copying. Restore replaces DB/storage and intentionally signs active sessions out.
