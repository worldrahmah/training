# Training Engine Core v1.2 — Acceptance Checklist

This checklist freezes the Core before production-course authoring.

## UI / UX
- [ ] Trainer, Participant and Projector are professional and expose no internal IDs/debug/state labels.
- [ ] Participant dashboard opens on a wide current-learning hero before Your Learning / تعلّمك.
- [ ] 320–430 px mobile, tablet, desktop and projector layouts are usable without page-level horizontal overflow.
- [ ] Light, Dark and System appearance work.
- [ ] English LTR and full Arabic RTL work throughout system UI.
- [ ] Course language/direction remains independent from system UI language.

## Identity / administration
- [ ] Administrator can add/edit/deactivate staff and reset trainer passwords.
- [ ] Lead/Trainer/Assistant assignments work per class.
- [ ] Non-admin trainers cannot access unassigned classes or system backups.
- [ ] Trainer reports/history are restricted to assigned classes.
- [ ] Participant account activation/password reset works under allowed administration.

## Courses / authoring
- [ ] Multiple courses and immutable versions can exist.
- [ ] `.course.zip` and JSON validation fail closed.
- [ ] Invalid package never partially imports.
- [ ] Local assets import and serve correctly.
- [ ] Preview renders Trainer / Projector / Participant interpretations.
- [ ] Official templates, schemas, Component Catalog and AI prompts are present.

## Universal renderer
- [ ] Text/hero/image/image+text/cards/steps/comparison/table/callout/stat/quote/checklist/asset/media blocks render.
- [ ] Static charts render from course data.
- [ ] Live answer charts render after reveal.
- [ ] Unsupported content/activity types are rejected by validation.

## Classes / participants
- [ ] Class lifecycle Draft → Scheduled → Active → Completed → Archived works.
- [ ] Manual class creation and class JSON import work.
- [ ] Manual participant creation and CSV roster preview/import work.
- [ ] Teams, class sessions, attendance and private trainer notes work.
- [ ] Historical records remain after class completion/archive.

## Live delivery
- [ ] Projector and Participant follow Trainer state automatically.
- [ ] Same-browser multi-tab use works.
- [ ] Phone access over same LAN works using physical Wi-Fi/LAN address.
- [ ] Single/multiple/true-false/short/long/numeric/rating/reaction/confidence/ranking activities work.
- [ ] Team-scoped response works.
- [ ] Timer/reveal/announcement/presentation behaviors work.
- [ ] Close/reveal/finish lifecycle and completion gates work.
- [ ] Refresh/reconnect/restart preserve relevant state/results.

## Learning records / reports
- [ ] Missions and text/URL/file/image submissions persist.
- [ ] Objective evidence and achievements persist.
- [ ] Participant dashboard shows own progress/activity.
- [ ] Trainer individual report shows classes, attendance, responses, missions, objectives, achievements and submissions.
- [ ] Course/Class/Participant/Trainer report center loads.
- [ ] Report/history CSV exports obey access scope.

## Operations
- [ ] Classroom readiness checks DB/course/trainers/participants/network.
- [ ] Demo removal preserves real data; demo reset works.
- [ ] Backup/restore works.
- [ ] Self-test passes on a clean copy.

## External-course proof
- [ ] Example course validates/imports.
- [ ] A fresh course generated from Authoring Kit can validate/import.
- [ ] It can be delivered without editing Core source.
