# Localization Contract v1.2

The system interface supports:
- English — LTR
- العربية — RTL

Localization covers Trainer, Participant, Projector, Preview, Settings, course/class/participant administration, reports, history, notes, validation/import and user-facing errors.

System UI language and course-content language are independent. An Arabic Trainer UI may deliver English or bilingual course content, and vice versa.

Preferences are stored in the browser/device. Course definitions carry their own `language` and `direction` fields.

## Authoring rule

Never encode interface-control text inside course packages. The Core owns system UI translation. Course authors provide translations only for course content that must be bilingual.
