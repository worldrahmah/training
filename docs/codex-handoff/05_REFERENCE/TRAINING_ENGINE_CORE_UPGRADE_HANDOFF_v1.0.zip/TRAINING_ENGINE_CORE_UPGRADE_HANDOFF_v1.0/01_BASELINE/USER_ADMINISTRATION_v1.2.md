# User and Class Administration v1.2

## Roles
- Administrator
- Trainer
- Assistant Trainer
- Participant

A class can have one Lead Trainer plus additional Trainers/Assistants. Administrators have global authority. Lead Trainers can administer their assigned class. Other assigned trainers can deliver and inspect that class without gaining global system authority.

## Participants
Participants can be created individually or imported by CSV. Roster import provides a validation preview before write. Accounts can be activated/deactivated and passwords reset by authorized administration.

## Class lifecycle
`Draft → Scheduled → Active → Completed → Archived`

Archiving never deletes learning history.

## Safe deletion
Normal operational records should be deactivated/archived rather than destroyed. Demo content has a dedicated safe removal/reset path. Backup is recommended before major administrative changes.
