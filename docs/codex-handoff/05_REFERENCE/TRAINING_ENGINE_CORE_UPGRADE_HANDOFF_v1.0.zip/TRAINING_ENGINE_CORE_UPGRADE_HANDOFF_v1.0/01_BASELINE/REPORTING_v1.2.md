# Reporting Center v1.2

Four report levels are built into the Core:

1. **Course** — classes, participants, completed classes, responses, completed missions and scored-response average.
2. **Class** — exact course version, lifecycle, participants, responses, missions, objective evidence, achievements and average score.
3. **Participant** — profile, attendance, class history, responses, missions, objectives, achievements, submissions, score and recent activity.
4. **Trainer** — assigned classes and participant reach.

CSV exports are available from Reports. Non-administrator reports and history are limited to authorized classes.

Reports remain tied to real delivery records and the immutable course version used by each class.
