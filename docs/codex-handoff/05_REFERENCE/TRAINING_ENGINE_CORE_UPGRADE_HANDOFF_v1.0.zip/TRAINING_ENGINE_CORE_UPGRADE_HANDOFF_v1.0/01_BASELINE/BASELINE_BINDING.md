# Exact Baseline Binding

This handoff upgrades the **Training Engine Core only**. It is deliberately independent from any individual course.

## Frozen baseline
- Artifact: `TRAINING_ENGINE_CORE_v1.2_FINAL.zip`
- SHA-256: `73e2a8f473a55eebdd7f61d894951093bb9fa90d7fa6db26eb670140b13f771b`
- Status: frozen baseline for all upgrade work

The upgrade must start from this exact archive. Do not reconstruct the Core from memory, another chat, or a later course package.

## Baseline preservation principle
All existing functionality, data contracts, imported course behavior, user accounts, class history, results, reports, localization behavior, and supported course component semantics are compatibility obligations unless an owner explicitly approves a specific change.

Course-specific projects such as “AI for Everyone — Level 1” are **not authority for Core design**. They may be supplied only as regression fixtures to prove compatibility.
