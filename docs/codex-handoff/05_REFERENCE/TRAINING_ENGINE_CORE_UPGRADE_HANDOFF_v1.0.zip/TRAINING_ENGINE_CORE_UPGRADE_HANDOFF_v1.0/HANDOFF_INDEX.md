# Training Engine Core Upgrade Handoff v1.0

Reusable handoff for safely upgrading the frozen Training Engine Core while preserving existing courses and historical data.

## Use this package when
- adding new Core features;
- changing Trainer/Participant/Projector functionality;
- adding new report/admin/security capabilities;
- adding new generic course component types;
- changing database structures;
- repairing Core defects.

## Do not use it for
- authoring a new course;
- editing a particular course's content;
- class setup only.

For those, use the separate generic course-authoring handoff.

Start with `00_START/QUICK_START_PROMPT.txt` in a fresh chat.
