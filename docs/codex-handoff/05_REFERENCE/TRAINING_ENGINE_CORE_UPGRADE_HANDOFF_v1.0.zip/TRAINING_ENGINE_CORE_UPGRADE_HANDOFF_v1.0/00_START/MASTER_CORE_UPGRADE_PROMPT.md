# Master Core Upgrade Prompt

You are upgrading the **Training Engine Core**, not authoring or redesigning a particular course.

## Baseline
Use only the exact supplied baseline:
- `TRAINING_ENGINE_CORE_v1.2_FINAL.zip`
- SHA-256 `73e2a8f473a55eebdd7f61d894951093bb9fa90d7fa6db26eb670140b13f771b`

## Mandatory process
1. Verify the outer upgrade-handoff ZIP CRC/path safety, `RELEASE_MANIFEST.json`, and `SHA256SUMS.txt`.
2. Follow `00_START/READ_ORDER.md` exactly.
3. Verify the nested Core baseline hash.
4. Extract a working copy. Preserve the exact baseline archive untouched.
5. Run the untouched baseline test suite before any edit and record the mandatory checkpoint.
6. Read the user's requested upgrade scope and convert it into explicit acceptance conditions.
7. Inspect architecture/code before designing changes; prefer additive implementation.
8. Implement the requested Core features while preserving `02_UPGRADE_AUTHORITY/BACKWARD_COMPATIBILITY_CONTRACT.md` and `DATABASE_MIGRATION_POLICY.md`.
9. If persistent schema changes are required, create a deterministic versioned migration and prove populated v1.2 -> upgraded migration without data loss.
10. Update authorization, localization, responsive UI, documentation, backup/restore and audit behavior where the new feature requires them.
11. If the upgrade changes the course-authoring surface, update the Component Catalog, JSON schema(s), templates, validator, example course and authoring documentation together. Existing schema 1.1 packages must remain supported.
12. Run all new-feature tests and the complete regression protocol in `03_TESTING/REGRESSION_TEST_PROTOCOL.md`.
13. Test the exact bundled old demo course unchanged. Also test every historical real course/database fixture supplied by the owner unchanged.
14. Seal the final upgraded Core and return every artifact required by `04_RELEASE/REQUIRED_DELIVERABLES.md`.
15. Verify final ZIP CRC/path safety, manifest and checksums and report the exact SHA-256.

## Prohibited shortcuts
- Do not rebuild the Core from memory.
- Do not start from a course-specific handoff.
- Do not edit historical courses to make the upgrade pass.
- Do not reset or discard existing data as an upgrade strategy.
- Do not silently remove/rename/reinterpret existing course component types.
- Do not expose internal IDs/debug state in the UI.
- Do not weaken server-side permissions because a UI control is hidden.
- Do not introduce mandatory cloud infrastructure without explicit owner approval.
- Do not claim backward compatibility unless it was actually reproduced on supplied fixtures.

## Final verdict
Only claim:

`CORE_UPGRADE_READY_FOR_OWNER_ACCEPTANCE`

if every applicable condition in `04_RELEASE/FINAL_ACCEPTANCE.md` passes on the exact sealed upgraded Core.
Otherwise return:

`CORE_UPGRADE_REPAIR_REQUIRED`
