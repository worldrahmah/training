# Final Core Upgrade Acceptance

The exact sealed upgraded Core may claim `CORE_UPGRADE_READY_FOR_OWNER_ACCEPTANCE` only if all applicable conditions pass:

- exact frozen v1.2 baseline verified;
- mandatory read order completed;
- untouched baseline tests reproduced before edits;
- requested features implemented and tested;
- existing v1.2 test suite passes or documented equivalent proves unchanged behavior;
- bundled v1.2 demo course validates/imports/runs unchanged;
- every owner-supplied historical course fixture validates/imports/runs unchanged;
- populated v1.2 data migrates without material loss;
- users/roles/classes/students/history/results/reports survive migration;
- restart persistence passes;
- backup/restore and rollback path pass;
- EN/AR parity passes for new UI;
- responsive/mobile/projector checks pass;
- permissions enforced server-side;
- new course-authoring surface (if any) has updated catalog/schema/template/validator/example;
- no old component semantics silently changed;
- no required cloud dependency introduced without approval;
- no visible internal/developer labels introduced;
- release manifest/checksums/ZIP CRC/path safety pass;
- no unresolved material warning remains.

If any material compatibility item fails, use `CORE_UPGRADE_REPAIR_REQUIRED` instead.
