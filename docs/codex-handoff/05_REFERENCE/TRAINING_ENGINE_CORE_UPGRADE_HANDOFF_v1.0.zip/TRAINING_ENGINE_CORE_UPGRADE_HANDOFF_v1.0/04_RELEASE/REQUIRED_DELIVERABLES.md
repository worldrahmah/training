# Required Deliverables for Every Core Upgrade

Return a sealed upgrade release containing, at minimum:

1. Upgraded Core source/package ZIP.
2. Exact SHA-256 of the upgraded ZIP.
3. `RELEASE_MANIFEST.json` and `SHA256SUMS.txt` for the release.
4. Upgrade scope/requirements document.
5. Change log listing added/changed behavior.
6. Backward Compatibility Report.
7. Database Migration Report (or explicit `NO_SCHEMA_CHANGE`).
8. Regression Test Report.
9. Security/Authorization impact note.
10. Localization/UI parity report for new visible features.
11. Updated Component Catalog, schemas, templates and validator whenever authoring surface changes.
12. Updated documentation for any changed workflow.
13. Rollback/backup instructions.
14. Known limitations, if any.
15. Exactly one final readiness verdict.

No upgrade is complete merely because source code exists.
