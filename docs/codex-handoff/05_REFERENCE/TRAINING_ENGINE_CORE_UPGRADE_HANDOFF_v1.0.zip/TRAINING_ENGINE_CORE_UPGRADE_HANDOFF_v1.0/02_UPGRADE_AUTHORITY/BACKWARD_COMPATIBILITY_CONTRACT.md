# Backward Compatibility Contract

The upgraded Core must preserve already-created courses and historical delivery data.

## Non-negotiable compatibility rules
1. Existing `.course.zip` packages valid under the v1.2 authoring contract must remain valid and importable without editing their content.
2. Courses already imported into a v1.2 database must continue to open, preview, deliver, report, and export after upgrade without re-authoring or re-import.
3. Existing course versions remain immutable historical records.
4. Existing classes, sessions, enrollments, teams, student profiles, answers, submissions, scores, achievements, notes, attendance, reports, and audit/history data must survive upgrade intact.
5. Existing users, roles, permissions, password hashes, activation states, and relevant settings must survive upgrade.
6. Existing component identifiers and semantics are stable public contracts. New components are additive. Do not silently rename, repurpose, or remove old component types.
7. Existing JSON schema 1.1 course packages remain supported. A newer schema may be introduced only additively with explicit version dispatch and continued 1.1 support.
8. Existing Trainer, Projector, Participant and Preview behavior must not regress for supported v1.2 content.
9. English LTR and Arabic RTL remain complete supported system interfaces.
10. Light/Dark/System themes and mobile/tablet/desktop/projector responsiveness remain supported.
11. Existing report/export fields may be extended, but existing fields/meaning must not silently change.
12. Existing local-first behavior, LAN delivery and restart persistence must remain functional.

## Compatibility corpus
At minimum, test the bundled `ENGINE_DEMO_COURSE_v1.0.course.zip` unchanged.

For any real courses already used in production, the owner should attach their exact exported `.course.zip` packages and, when available, a sanitized backup of the current Core data. Those become mandatory regression fixtures for that upgrade.

## Fail-closed rule
If compatibility cannot be proved for a supplied historical fixture, the upgrade is **not ready**. Do not paper over the failure by modifying the old course.
