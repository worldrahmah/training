# Core Upgrade Policy

## Purpose
Add new Training Engine capabilities while preserving the frozen v1.2 Core contracts and all existing course/delivery behavior.

## Upgrade discipline
1. Work on a copy of the exact frozen baseline; never edit the only copy of the baseline archive.
2. Reproduce the baseline tests before changes.
3. Turn every requested feature into explicit acceptance conditions before implementation.
4. Prefer additive architecture and reuse established abstractions.
5. Preserve declarative course content. Do not force old courses to contain new fields unless defaults make them optional.
6. Do not introduce course-specific assumptions into the Core.
7. Keep UI professional and human-facing. Never expose debug IDs, schema keys, internal states or development labels.
8. Preserve complete EN LTR / AR RTL parity for every new visible feature.
9. Preserve responsive behavior and accessibility for every new visible feature.
10. New privileges/actions must be covered by authorization checks, not only hidden UI.
11. New persistent features require backup/restore and audit/history consideration.
12. New authoring features require Component Catalog, schema, template, validation and example updates together.
13. No external cloud dependency may become mandatory for the local-first Core unless explicitly approved.
14. Never mutate or delete historical course/class results merely to fit a new feature.
15. Any upgrade that cannot meet backward compatibility must stop for explicit owner decision rather than silently breaking the contract.

## Versioning
- Compatible feature additions normally increment the minor version (e.g. v1.2 -> v1.3).
- Repairs without feature changes may increment patch version.
- A major-version label does not waive the backward-compatibility requirements unless the owner explicitly authorizes a migration/breaking transition.
