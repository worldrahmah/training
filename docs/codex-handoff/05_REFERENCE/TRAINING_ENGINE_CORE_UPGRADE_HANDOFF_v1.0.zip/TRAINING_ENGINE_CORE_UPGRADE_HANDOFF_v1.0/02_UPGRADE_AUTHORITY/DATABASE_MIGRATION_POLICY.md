# Database Migration Policy

Upgrades must preserve existing data and be recoverable.

## Required rules
- Never treat the upgraded database as a fresh install when upgrading an existing workspace.
- Before any migration, create a verified backup of the v1.2 data/database and relevant storage.
- Schema changes must use explicit versioned migrations or deterministic compatibility initialization logic with a recorded schema version.
- Prefer additive changes: new tables, nullable/defaulted columns, new indexes, and additive constraints that do not invalidate historical rows.
- Destructive operations (drop table/column, reinterpret data, rewrite identifiers, bulk deletion) are prohibited unless separately owner-approved and backed by a tested reversible migration.
- Never reset IDs that are referenced by historical course/class/student data.
- Migrations must be idempotent where appropriate and must fail closed on unexpected schema state.
- Validate database integrity after migration.
- Test exact v1.2 -> upgraded migration on a populated compatibility fixture, not only on an empty database.
- Test restart after migration.
- Test backup restoration/rollback into the original v1.2 Core or documented rollback target.

## Data migration evidence
The final upgrade report must list:
- prior schema/version,
- new schema/version,
- migrations applied,
- row/integrity checks performed,
- before/after counts for material tables,
- rollback evidence.
