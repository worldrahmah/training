# Quick Start — Training Engine v2.1 FINAL

1. Extract the ZIP to a writable Windows folder.
2. Run `START_TRAINING_ENGINE.bat`.
3. Open `http://localhost:3000/admin`.
4. Sign in with the first-run Super Admin: `TRAINER` / `TRAIN1234`.
5. Change the default password before real delivery.

## Recommended first FINAL verification

### Create a Course
Super Admin -> Courses -> Create Course. The system creates an initial Draft and can open it in the visual Course Builder.

### Build/preview content
Use Tree View, Edit View and Preview. Add a milestone, activity/mission/path and workflow branches. No raw JSON is required for normal authoring.

### Create a Class
Super Admin -> Classes -> Create Class:
- choose the exact Course Version;
- set dates/times/location/capacity;
- choose one Lead Trainer;
- optionally choose additional Trainers/Assistants;
- select existing Participants;
- optionally preview/import a CSV roster.

### Manage the Class
Use Manage Class to edit the delivery, trainers, participant roster, sessions, teams, attendance, readiness and lifecycle.

### Projector
Open `http://localhost:3000/present`. Use Previous/Next or Arrow/PageUp/PageDown/Space keys. The display should behave as a presentation stage rather than a scrolling webpage.

See `docs/CORE_ACCEPTANCE.md` for the FINAL verification checklist.
