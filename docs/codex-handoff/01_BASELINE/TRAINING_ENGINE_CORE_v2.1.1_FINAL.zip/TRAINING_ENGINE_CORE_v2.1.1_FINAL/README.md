# Training Engine Core v2.1.1 FINAL

Training Engine is a reusable, local-first platform for course administration, visual authoring, live classroom delivery and learning analytics. v2.1.1 is a bounded compatibility repair derived directly from v2.1 FINAL. It fixes the Trainer Workflow Progress Tracker for legacy modules that do not define an explicit schema 2.0 workflow, while preserving all v2.1 behavior and historical data compatibility.


## v2.1.1 workflow-tracker compatibility repair

- Legacy/schema 1.0/1.1 modules and schema 2.0 modules without an explicit workflow now receive a deterministic in-memory **implicit linear workflow** derived from their existing activity/mission order.
- The course package is not rewritten or mutated.
- Only the highlighted **Next** section is normally actionable in the Trainer Course Flow.
- Starting a section marks it **Current**; finishing it marks it **Done**; the next permitted section becomes **Next** and later sections remain **Upcoming**.
- Old direct live-control API calls remain backward compatible and are now mapped into the same persisted progress tracker.
- A section that was already open during an upgrade can still be inferred and completed correctly even when its pre-upgrade live state did not contain a workflow-node ID.
- Explicit schema 2.0 branching workflows keep their original class-level/participant-level behavior.

## FINAL release scope

FINAL preserves the accepted RC4 functionality: full responsive/UI closure across Super Admin, Trainer, Course Builder, Class Management, Participant and Projector surfaces; true presenter-stage Projector behavior; complete mobile navigation; and narrow-screen overflow protection.


### Full responsive UX closure
- Responsive acceptance is now a release gate, not a best-effort style layer.
- Supported acceptance widths include 320, 340, 375, 430, 480, 760/768, 980, 1366, 1920 and projector-sized displays, plus landscape-phone constraints.
- Desktop side navigation switches to a dedicated mobile shell before tablet layouts become cramped.
- Super Admin and Trainer mobile navigation now exposes every workspace through a professional More sheet instead of silently hiding sections.
- Page headers, action groups, forms, cards, class setup, permissions, progress boards, Help Queue, Course Builder, workflow editor, reports and analytics all reflow at bounded breakpoints.
- Tables and workflow graphs use local scrolling containers; page-level horizontal scrolling is prohibited.
- Mobile forms use touch-safe controls and 16px input text to avoid browser zoom.
- Modals/drawers become narrow-screen sheets while preserving keyboard/touch usability.
- Participant hero, Your Learning, live activities, guided practice and resource/prompt actions adapt down to 320px.
- Arabic RTL and English LTR use the same responsive contracts.

### Courses and versions
- Create a new Course from the Super Admin workspace and receive an initial editable Draft automatically.
- Manage course/version history from the Course workspace.
- Published/delivered versions remain immutable; editing derives a new Draft.
- Imported courses and courses created in the UI use the same canonical Course Builder and runtime model.
- Visual permissions replace raw technical permission strings for normal administration.

### Class setup and operations
A Class is now created as an operational delivery, not merely a title/date shell. The Super Admin creation flow supports:
- exact Course Version;
- class title, dates, times, capacity, location, timezone and lifecycle;
- Lead Trainer plus additional Trainer/Assistant assignments;
- enrollment of existing Participants at creation time;
- optional validated CSV roster import;
- initial session creation.

The Class management workspace supports:
- edit class details and lifecycle;
- assign/reassign Lead Trainer and additional trainers;
- add existing participants;
- preview/import a CSV participant roster;
- remove a participant from the class while preserving historical enrollment/activity records;
- create/delete class sessions;
- create/manage teams;
- attendance and classroom readiness;
- archive instead of destructive historical deletion.

Authorized Trainers receive the same operational controls only inside the classes/resources they are permitted to administer.

### Visual Course Builder
Normal course authoring no longer requires editing raw JSON. The canonical Builder provides:
- Tree View, Edit View and Preview Mode;
- modules/milestones, objectives, activities, missions and participant paths;
- presentation content blocks;
- guided mission/path steps;
- trainer cues and result display choices;
- visual workflow nodes and edges;
- class-level and participant-level branch scope;
- workflow start node and convergence design;
- reorder, duplicate and delete operations;
- preview as Trainer, Projector or Participant, including participant-path simulation.

JSON remains the import/export interchange format, but it is not required for normal visual authoring.

### Projector presenter experience
The Projector is now treated as a presentation stage rather than a webpage card:
- full-display stage with 16:9-friendly composition;
- presentation-scale titles, body text, cards, results, charts and media;
- minimal chrome during delivery;
- Previous/Next navigation plus Arrow, PageUp/PageDown, Space and clicker-compatible keys;
- Arabic/English direction and presentation typography preserved.

## v2 platform capabilities retained

- Separate Super Admin and Trainer workspaces.
- Read-only global live-operations monitoring for Super Admin.
- Granular resource-scoped Trainer permissions.
- Rich participant profiles, account settings, communication consent and sign-out.
- In-app notifications/messages.
- Arabic/English UI and presentation typography controls with safe course overrides.
- Independent participant practice paths with multi-step guided work and resume state.
- Participant Need Help and Trainer Help Queue.
- Live milestone progress per participant and aggregate class state.
- Rich reporting/analytics across courses, versions, classes, participants, objectives, paths, attendance, help and completion.
- Schema 2.0 authoring while retaining schema 1.0/1.1 package compatibility.

## Backward compatibility

The accepted v1.2 FINAL baseline remains the compatibility authority. Existing schema 1.0/1.1 course packages remain supported. Existing populated v1.2 databases migrate in place; historical courses, classes, participants and delivery data are preserved. Published versions remain immutable.

Legacy v1.2 regression, restart and backup/restore suites continue to pass under v2.0 FINAL.

## Start on Windows

1. Extract the ZIP to a normal writable folder.
2. Install Node.js 22.5+; Node.js 24 LTS is recommended.
3. Run `START_TRAINING_ENGINE.bat`.
4. Super Admin: `http://localhost:3000/admin`
5. Trainer: `http://localhost:3000/trainer`
6. Participant: `http://localhost:3000/student`
7. Projector: `http://localhost:3000/present`
8. Visual Course Builder: `http://localhost:3000/builder`

Default first-run Super Admin:
- Username: `TRAINER`
- Password: `TRAIN1234`

Change the default password before real delivery.

Demo participant:
- Username: `DEMO01`
- Password: `D1001`

## Self-test

Run `RUN_SELF_TEST.bat` or `npm test`.

The FINAL suite includes responsive UI contract checks, Arabic/English localization, v1.2 compatibility, restart persistence, backup/restore, v2 Super Admin/RBAC, Course Version lifecycle, Class creation with trainer assignment, participant enrollment/removal history, session management, independent participant paths, Help Queue, progress, projector navigation, analytics and live monitoring.

## RC status

This release is **v2.0 FINAL**, promoted from RC4 after owner acceptance of the responsive/UI closure. Runtime source behavior is unchanged from the accepted RC4 codebase; only release metadata/documentation were promoted.


## v2.1 — Trainer Workflow Progress Tracker
Live workflow sections are now persisted and shown as Done, Current, Next, Upcoming, Blocked or Skipped. The Trainer is guided to the next permitted section, deliberate skip is recorded, and state survives refresh/restart. Super Admin live monitoring also exposes the current/next workflow position.
