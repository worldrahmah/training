#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
node --no-warnings app/server.mjs
