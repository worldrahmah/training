import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { EngineDb } from './lib/db.mjs';
import { parseCoursePackage, findActivity, findMission, findPath, findModule } from './lib/course-package.mjs';
import { copyDir, ensureDir, hashPassword, mimeFromName, nowIso, preferredLanAddress, privateLanAddresses, randomToken, removeDirContents, rowsToCsv, safeJsonParse, safeRelativePath, sha256, slugify, verifyPassword } from './lib/utils.mjs';

const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);
const ROOT=path.resolve(__dirname,'..');
const PUBLIC=path.join(__dirname,'public');
const DATA_DIR=process.env.TRAINING_ENGINE_DATA_DIR?path.resolve(process.env.TRAINING_ENGINE_DATA_DIR):path.join(ROOT,'data');
const STORAGE_DIR=process.env.TRAINING_ENGINE_STORAGE_DIR?path.resolve(process.env.TRAINING_ENGINE_STORAGE_DIR):path.join(ROOT,'storage');
const BACKUP_DIR=process.env.TRAINING_ENGINE_BACKUP_DIR?path.resolve(process.env.TRAINING_ENGINE_BACKUP_DIR):path.join(ROOT,'backups');
const EXPORT_DIR=process.env.TRAINING_ENGINE_EXPORT_DIR?path.resolve(process.env.TRAINING_ENGINE_EXPORT_DIR):path.join(ROOT,'exports');
const DB_PATH=path.join(DATA_DIR,'training-engine.sqlite');
const PORT=Number(process.env.PORT||3000);
const HOST=process.env.HOST||'0.0.0.0';
const MAX_JSON=2*1024*1024;
const MAX_PACKAGE=30*1024*1024;
const MAX_SUBMISSION=15*1024*1024;

for(const p of [DATA_DIR,STORAGE_DIR,BACKUP_DIR,EXPORT_DIR,path.join(STORAGE_DIR,'course-assets'),path.join(STORAGE_DIR,'submissions')]) ensureDir(p);
let engine=new EngineDb(DB_PATH); engine.seedBase();
const db=()=>engine.db;

const sseClients=new Set();
function broadcast(event,data){
  const payload=`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for(const client of [...sseClients]){ try{client.res.write(payload);}catch{sseClients.delete(client);} }
}
function refresh(classId=null,reason='update'){ broadcast('refresh',{class_id:classId,reason,at:nowIso()}); }
setInterval(()=>{
  for(const c of [...sseClients]){ try{c.res.write(`: keepalive ${Date.now()}\n\n`);}catch{sseClients.delete(c);} }
},25000).unref();

function json(res,status,body,headers={}){
  const buf=Buffer.from(JSON.stringify(body));
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':buf.length,'Cache-Control':'no-store',...headers}); res.end(buf);
}
function send(res,status,body,type='text/plain; charset=utf-8',headers={}){
  const buf=Buffer.isBuffer(body)?body:Buffer.from(String(body));
  res.writeHead(status,{'Content-Type':type,'Content-Length':buf.length,...headers}); res.end(buf);
}
async function readBuffer(req,max=MAX_JSON){
  const chunks=[]; let total=0;
  for await(const ch of req){ total+=ch.length; if(total>max) throw Object.assign(new Error('PAYLOAD_TOO_LARGE'),{status:413}); chunks.push(ch); }
  return Buffer.concat(chunks);
}
async function readJson(req,max=MAX_JSON){
  const b=await readBuffer(req,max); if(!b.length) return {};
  try{return JSON.parse(b.toString('utf8'));}catch{throw Object.assign(new Error('INVALID_JSON'),{status:400});}
}
function tokenFrom(req,url=null){
  const h=String(req.headers['x-session-token']||'').trim(); if(h) return h;
  const auth=String(req.headers.authorization||''); if(/^Bearer\s+/i.test(auth)) return auth.replace(/^Bearer\s+/i,'').trim();
  if(url?.searchParams?.get('token')) return url.searchParams.get('token');
  return null;
}
function currentUser(req,url=null){
  const token=tokenFrom(req,url); if(!token) return null;
  const row=db().prepare(`SELECT u.id,u.username,u.role,u.display_name,u.email,u.active,u.is_demo,p.profile_json,sr.staff_role
    FROM sessions s JOIN users u ON u.id=s.user_id LEFT JOIN profiles p ON p.user_id=u.id LEFT JOIN staff_roles sr ON sr.user_id=u.id
    WHERE s.token=? AND u.active=1`).get(token);
  if(row){ db().prepare('UPDATE sessions SET last_seen=CURRENT_TIMESTAMP WHERE token=?').run(token); row.profile=safeJsonParse(row.profile_json,{}); delete row.profile_json; if(row.role==='trainer'&&!row.staff_role)row.staff_role='trainer'; }
  return row||null;
}
function requireUser(req,res,url,roles=null){
  const u=currentUser(req,url); if(!u || (roles&&!roles.includes(u.role))){ json(res,401,{ok:false,message:'Please sign in to continue.'}); return null; } return u;
}
function trainer(req,res,url){ return requireUser(req,res,url,['trainer']); }
function administrator(req,res,url){ const u=trainer(req,res,url); if(!u)return null; if(!['super_admin','administrator'].includes(u.staff_role||'trainer')){json(res,403,{ok:false,message:'Administrator access is required for this action.'});return null}return u; }
function superAdministrator(req,res,url){ const u=trainer(req,res,url); if(!u)return null; if((u.staff_role||'trainer')!=='super_admin'){json(res,403,{ok:false,message:'Super administrator access is required for this action.'});return null}return u; }
function isAdminLike(user){return !!user&&['super_admin','administrator'].includes(user.staff_role||'trainer')}
function hasGrant(user,resourceType,resourceId,action){if(!user)return false;if((user.staff_role||'trainer')==='super_admin')return true;if((user.staff_role||'trainer')==='administrator'&&resourceType!=='system')return true;const rid=resourceId==null?'*':String(resourceId);return !!db().prepare(`SELECT 1 FROM permission_grants WHERE user_id=? AND resource_type=? AND action=? AND resource_id IN (?, '*') LIMIT 1`).get(Number(user.id),String(resourceType),String(action),rid)}
function student(req,res,url){ return requireUser(req,res,url,['student']); }
function canManageClass(user,classId){ if(!user)return false; if(isAdminLike(user)||hasGrant(user,'class',classId,'view'))return true; return !!db().prepare('SELECT 1 FROM class_trainers WHERE class_id=? AND user_id=?').get(Number(classId),Number(user.id)); }
function canAdministerClass(user,classId){ if(!user)return false; if(isAdminLike(user)||hasGrant(user,'class',classId,'manage'))return true; return !!db().prepare("SELECT 1 FROM class_trainers WHERE class_id=? AND user_id=? AND assignment_role='lead'").get(Number(classId),Number(user.id)); }
function canAdministerStudent(user,studentId){ if(!user)return false; if(isAdminLike(user)||hasGrant(user,'student',studentId,'manage'))return true; return !!db().prepare("SELECT 1 FROM enrollments e JOIN class_trainers ct ON ct.class_id=e.class_id WHERE e.student_id=? AND e.status<>'withdrawn' AND ct.user_id=? AND ct.assignment_role='lead' LIMIT 1").get(Number(studentId),Number(user.id)); }
function requireClassAccess(user,classId,res){ if(canManageClass(user,classId))return true; json(res,403,{ok:false,message:'You do not have access to this class.'}); return false; }
function requireClassAdministration(user,classId,res){ if(canAdministerClass(user,classId))return true; json(res,403,{ok:false,message:'Lead trainer or administrator access is required for this action.'}); return false; }
function activeClassId(){ return Number(engine.getSetting('active_class_id',0)||0)||null; }
function setActiveClass(id){ engine.setSetting('active_class_id',Number(id)); refresh(Number(id),'active_class'); }
function getClassRow(id){
  return db().prepare(`SELECT cl.*,cv.version,cv.id course_version_id,c.id course_id,c.title course_title,c.language,c.direction,u.display_name trainer_name,
  COALESCE(lc.lifecycle_status,CASE cl.status WHEN 'planned' THEN 'scheduled' WHEN 'cancelled' THEN 'archived' ELSE cl.status END) lifecycle_status
  FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id JOIN courses c ON c.id=cv.course_id
  LEFT JOIN users u ON u.id=cl.trainer_id LEFT JOIN class_lifecycle lc ON lc.class_id=cl.id WHERE cl.id=?`).get(Number(id))||null;
}
function getCourseContentByClass(classId){
  const row=db().prepare(`SELECT cv.content_json FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id WHERE cl.id=?`).get(Number(classId));
  return row?safeJsonParse(row.content_json,null):null;
}
function getClassState(classId){
  const r=db().prepare('SELECT * FROM classroom_state WHERE class_id=?').get(Number(classId));
  if(!r) return {class_id:Number(classId),module_id:null,activity_id:null,phase:'waiting',payload:{},revision:0,updated_at:null};
  return {...r,payload:safeJsonParse(r.payload_json,{})};
}
function setClassState(classId,patch,userId=null){
  const current=getClassState(classId); const next={
    module_id:patch.module_id!==undefined?patch.module_id:current.module_id,
    activity_id:patch.activity_id!==undefined?patch.activity_id:current.activity_id,
    phase:patch.phase!==undefined?patch.phase:current.phase,
    payload:patch.payload!==undefined?patch.payload:current.payload,
    revision:Number(current.revision||0)+1
  };
  db().prepare(`INSERT INTO classroom_state(class_id,module_id,activity_id,phase,payload_json,revision,updated_at)
    VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(class_id) DO UPDATE SET module_id=excluded.module_id,activity_id=excluded.activity_id,phase=excluded.phase,payload_json=excluded.payload_json,revision=excluded.revision,updated_at=CURRENT_TIMESTAMP`)
    .run(Number(classId),next.module_id,next.activity_id,next.phase,JSON.stringify(next.payload||{}),next.revision);
  engine.log(classId,userId,'classroom_updated','classroom',classId,{phase:next.phase,module_id:next.module_id,activity_id:next.activity_id});
  refresh(Number(classId),'classroom'); return getClassState(classId);
}
function enrollment(classId,studentId){ return db().prepare('SELECT * FROM enrollments WHERE class_id=? AND student_id=? AND status<>\'withdrawn\'').get(Number(classId),Number(studentId)); }
function studentTeam(classId,studentId){ return db().prepare(`SELECT t.id,t.name FROM teams t JOIN team_members tm ON tm.team_id=t.id WHERE t.class_id=? AND tm.student_id=? LIMIT 1`).get(Number(classId),Number(studentId))||null; }
function markObjectives(classId,studentId,objectiveIds=[]){
  const ids=Array.isArray(objectiveIds)?objectiveIds.filter(Boolean).map(String):[];
  for(const oid of ids) db().prepare(`INSERT INTO objective_progress(class_id,student_id,objective_id,evidence_count,achieved,updated_at) VALUES(?,?,?,1,1,CURRENT_TIMESTAMP) ON CONFLICT(class_id,student_id,objective_id) DO UPDATE SET evidence_count=objective_progress.evidence_count+1,achieved=1,updated_at=CURRENT_TIMESTAMP`).run(Number(classId),Number(studentId),oid);
}
function awardAchievement(classId,studentId,achievement){
  if(!achievement||!achievement.key||!achievement.title)return;
  db().prepare(`INSERT OR IGNORE INTO achievements(class_id,student_id,achievement_key,title,metadata_json) VALUES(?,?,?,?,?)`).run(Number(classId),Number(studentId),String(achievement.key),String(achievement.title),JSON.stringify(achievement.metadata||{}));
}
function instanceResults(instanceId){
  const inst=db().prepare('SELECT * FROM activity_instances WHERE id=?').get(Number(instanceId)); if(!inst) return null;
  const def=safeJsonParse(inst.definition_json,{}); let answers=[];
  if(def.response_scope==='team'){
    const rows=db().prepare(`SELECT tr.*,t.name team_name,u.display_name submitted_by_name FROM team_responses tr JOIN teams t ON t.id=tr.team_id JOIN users u ON u.id=tr.submitted_by WHERE tr.instance_id=? ORDER BY tr.submitted_at`).all(Number(instanceId));
    answers=rows.map(r=>({...r,answer:safeJsonParse(r.answer_json,null),name:r.team_name}));
  }else{
    const rows=db().prepare(`SELECT r.*,u.display_name,u.username FROM responses r JOIN users u ON u.id=r.student_id WHERE r.instance_id=? ORDER BY r.submitted_at`).all(Number(instanceId));
    answers=rows.map(r=>({...r,answer:safeJsonParse(r.answer_json,null),name:r.display_name||r.username}));
  }
  const type=inst.activity_type; let summary={total:answers.length,response_scope:def.response_scope||'individual'};
  if(['poll','single_choice','true_false','reaction'].includes(type)){
    const opts=Array.isArray(def?.content?.options)?def.content.options:(type==='true_false'?['True','False']:[]); const counts={}; for(const o of opts) counts[String(o)]=0;
    for(const r of answers){ const v=typeof r.answer==='object'?r.answer?.value:r.answer; const k=String(v); counts[k]=(counts[k]||0)+1; }
    summary={...summary,counts,options:opts};
  }else if(type==='multiple_choice'){
    const opts=def?.content?.options||[]; const counts=Object.fromEntries(opts.map(o=>[String(o),0]));
    for(const r of answers){ const arr=Array.isArray(r.answer?.value)?r.answer.value:(Array.isArray(r.answer)?r.answer:[]); for(const v of arr) counts[String(v)]=(counts[String(v)]||0)+1; }
    summary={...summary,counts,options:opts};
  }else if(['rating','confidence','numeric_answer'].includes(type)){
    const vals=answers.map(r=>Number(r.answer?.value??r.answer)).filter(Number.isFinite); summary={...summary,average:vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0,values:vals,numeric_values:vals,min:vals.length?Math.min(...vals):null,max:vals.length?Math.max(...vals):null};
  }else if(type==='ranking'){
    const opts=Array.isArray(def?.content?.options)?def.content.options:[]; const totals=Object.fromEntries(opts.map(o=>[String(o),0])); const appearances=Object.fromEntries(opts.map(o=>[String(o),0]));
    for(const r of answers){const v=r.answer?.value??r.answer;if(Array.isArray(v)){v.forEach((o,i)=>{const k=String(o);totals[k]=(totals[k]||0)+(i+1);appearances[k]=(appearances[k]||0)+1;});}else if(v&&typeof v==='object'){for(const [k,rank] of Object.entries(v)){totals[k]=(totals[k]||0)+Number(rank||0);appearances[k]=(appearances[k]||0)+1;}}}
    const ranking=Object.keys(totals).map(label=>({label,score:appearances[label]?totals[label]/appearances[label]:999})).sort((a,b)=>a.score-b.score); summary={...summary,ranking};
  }else if(['short_answer','long_answer','reflection','self_assessment','team_challenge','url_submission','file_submission','image_submission','checklist'].includes(type)) summary={...summary,answers:answers.map(r=>({student_id:r.student_id||null,team_id:r.team_id||null,name:r.name||r.display_name||r.username||r.team_name,text:String(r.answer?.value??r.answer??'')}))};
  return {instance:{...inst,definition:def},answers,summary};
}

function suggestedNext(activity,results){
  const flow=activity?.flow||{};
  if(flow.next_activity_id) return String(flow.next_activity_id);
  const branches=Array.isArray(flow.branches)?flow.branches:[];
  if(branches.length&&results?.summary?.counts){
    const entries=Object.entries(results.summary.counts); if(!entries.length)return flow.default_next_activity_id?String(flow.default_next_activity_id):null;
    entries.sort((a,b)=>b[1]-a[1]); const winner=entries[0][0];
    const br=branches.find(x=>String(x.when??x.value??'')===String(winner)); if(br?.next_activity_id)return String(br.next_activity_id);
  }
  return flow.default_next_activity_id?String(flow.default_next_activity_id):null;
}
function workflowNodeTitle(mod,node){
  if(!node)return 'Section';
  if(String(node.title||'').trim())return String(node.title).trim();
  if(node.activity_id){const x=(mod.activities||[]).find(a=>String(a.id)===String(node.activity_id));if(x?.title)return String(x.title);}
  if(node.mission_id){const x=(mod.missions||[]).find(a=>String(a.id)===String(node.mission_id));if(x?.title)return String(x.title);}
  if(node.path_id){const x=(mod.paths||[]).find(a=>String(a.id)===String(node.path_id));if(x?.title)return String(x.title);}
  const names={trainer_scene:'Trainer introduction',class_interaction:'Class interaction',trainer_walkthrough:'Trainer demonstration',practice_start:'Start student activity',participant_choice:'Participant choice',participant_path:'Participant practice',convergence:'Practice complete',closing:'Closing',activity:'Activity',mission:'Mission'};
  return names[node.type]||'Section';
}
function implicitWorkflowForModule(mod){
  if(!mod)return null;
  const nodes=[];
  for(const a of (mod.activities||[])){
    if(!a?.id)continue;
    nodes.push({id:`__auto_activity__${String(a.id)}`,type:'activity',activity_id:String(a.id),title:a.title||'Activity',implicit:true});
  }
  for(const m of (mod.missions||[])){
    if(!m?.id)continue;
    nodes.push({id:`__auto_mission__${String(m.id)}`,type:'mission',mission_id:String(m.id),title:m.title||'Mission',implicit:true});
  }
  if(!nodes.length)return null;
  const edges=[];
  for(let i=0;i<nodes.length-1;i++)edges.push({from:nodes[i].id,to:nodes[i+1].id,scope:'class',implicit:true});
  return {start_node_id:nodes[0].id,nodes,edges,implicit:true};
}
function effectiveWorkflow(mod){
  const explicit=mod?.workflow;
  if(explicit?.nodes?.length)return {...explicit,implicit:false};
  return implicitWorkflowForModule(mod);
}
function workflowNodeForRef(mod,{activityId=null,missionId=null,type=null,nodeId=null}={}){
  const nodes=effectiveWorkflow(mod)?.nodes||[];
  if(nodeId)return nodes.find(n=>String(n.id)===String(nodeId))||null;
  if(activityId)return nodes.find(n=>String(n.activity_id||'')===String(activityId))||null;
  if(missionId)return nodes.find(n=>String(n.mission_id||'')===String(missionId))||null;
  if(type)return nodes.find(n=>String(n.type||'')===String(type))||null;
  return null;
}
function persistedWorkflowRows(classId,moduleId){
  return db().prepare('SELECT * FROM class_workflow_progress WHERE class_id=? AND module_id=? ORDER BY updated_at,node_id').all(Number(classId),String(moduleId));
}
function setWorkflowNodeState(classId,moduleId,nodeId,status,userId=null,{selectedNextNodeId=undefined}={}){
  const prev=db().prepare('SELECT * FROM class_workflow_progress WHERE class_id=? AND module_id=? AND node_id=?').get(Number(classId),String(moduleId),String(nodeId));
  const nextSel=selectedNextNodeId===undefined?(prev?.selected_next_node_id||null):(selectedNextNodeId||null);
  const started=status==='current'?(prev?.started_at||nowIso()):(prev?.started_at||null);
  const completed=['completed','skipped'].includes(status)?nowIso():null;
  db().prepare(`INSERT INTO class_workflow_progress(class_id,module_id,node_id,status,selected_next_node_id,started_at,completed_at,updated_at,updated_by)
    VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?) ON CONFLICT(class_id,module_id,node_id) DO UPDATE SET status=excluded.status,selected_next_node_id=excluded.selected_next_node_id,started_at=COALESCE(class_workflow_progress.started_at,excluded.started_at),completed_at=excluded.completed_at,updated_at=CURRENT_TIMESTAMP,updated_by=excluded.updated_by`)
    .run(Number(classId),String(moduleId),String(nodeId),status,nextSel,started,completed,userId||null);
  refresh(Number(classId),'workflow_progress');
}
function participantPathAggregate(classId,pathId){
  const rows=db().prepare(`SELECT status,COUNT(*) c FROM participant_runtime_state WHERE class_id=? AND path_id=? GROUP BY status`).all(Number(classId),String(pathId));
  const out={total:0,finished:0,working:0,need_help:0};for(const r of rows){out.total+=Number(r.c||0);if(r.status==='finished')out.finished+=Number(r.c||0);if(r.status==='working')out.working+=Number(r.c||0);if(r.status==='need_help')out.need_help+=Number(r.c||0);}return out;
}
function moduleWorkflowProgress(classId,mod,{allowNext=true}={}){
  const wf=effectiveWorkflow(mod);if(!wf?.nodes?.length)return {module_id:mod?.id,title:mod?.title||'',has_workflow:false,complete:false,nodes:[]};
  const nodes=wf.nodes,edges=wf.edges||[],rows=persistedWorkflowRows(classId,mod.id),byId=new Map(nodes.map(n=>[String(n.id),n])),state=new Map(rows.map(r=>[String(r.node_id),r]));
  const explicitDone=id=>['completed','skipped'].includes(state.get(String(id))?.status);
  const selectedFrom=id=>state.get(String(id))?.selected_next_node_id||null;
  const blocked=new Set();
  for(const e of edges){if((e.scope||'class')!=='class')continue;const sel=selectedFrom(e.from);if(sel&&String(e.to)!==String(sel))blocked.add(String(e.to));}
  const pathAgg=new Map();
  for(const n of nodes)if(n.type==='participant_path'&&n.path_id)pathAgg.set(String(n.id),participantPathAggregate(classId,n.path_id));
  const doneForReadiness=id=>{const n=byId.get(String(id));if(!n)return false;if(explicitDone(id))return true;if(n.type==='participant_path'){const a=pathAgg.get(String(id));return !!a&&a.total>0&&a.finished>=a.total;}return false};
  const currentRow=rows.find(r=>r.status==='current');
  let nextIds=[];
  if(!currentRow&&allowNext){
    if(!rows.length&&wf.start_node_id)nextIds=[String(wf.start_node_id)];
    else{
      for(const n of nodes){const id=String(n.id);if(explicitDone(id)||blocked.has(id)||state.get(id)?.status==='current'||n.type==='participant_path')continue;const incoming=edges.filter(e=>String(e.to)===id);if(!incoming.length){continue}
        let relevant=incoming.filter(e=>{const sel=selectedFrom(e.from);return !sel||String(sel)===id});
        if(!relevant.length)continue;
        if(relevant.every(e=>doneForReadiness(e.from)))nextIds.push(id);
      }
    }
  }
  const display=nodes.map(n=>{const id=String(n.id),row=state.get(id),agg=pathAgg.get(id);let status='upcoming';if(row?.status==='completed')status='completed';else if(row?.status==='skipped')status='skipped';else if(row?.status==='current')status='current';else if(blocked.has(id))status='blocked';else if(n.type==='participant_path'&&agg?.total){status=agg.finished>=agg.total?'completed':'working';}else if(nextIds.includes(id))status='next';return {id,title:workflowNodeTitle(mod,n),type:n.type,status,activity_id:n.activity_id||null,mission_id:n.mission_id||null,path_id:n.path_id||null,started_at:row?.started_at||null,completed_at:row?.completed_at||null,selected_next_node_id:row?.selected_next_node_id||null,participant_progress:agg||null};});
  const closing=display.filter(x=>x.type==='closing');const complete=closing.length?closing.every(x=>['completed','skipped'].includes(x.status)):display.filter(x=>x.status!=='blocked').every(x=>['completed','skipped'].includes(x.status));
  return {module_id:mod.id,title:mod.title||'',has_workflow:true,implicit:!!wf.implicit,complete,nodes:display,current:display.find(x=>x.status==='current')||null,next:display.find(x=>x.status==='next')||null};
}
function workflowProgressForClass(classId){
  const content=getCourseContentByClass(classId),mods=content?.course?.modules||[];let nextAllowed=true;const modules=[];
  for(const mod of mods){let m=moduleWorkflowProgress(classId,mod,{allowNext:nextAllowed});if(!m.has_workflow){modules.push(m);continue}if(m.complete){modules.push(m);continue}if(!nextAllowed){m={...m,nodes:m.nodes.map(n=>n.status==='next'?{...n,status:'upcoming'}:n),next:null};}else nextAllowed=false;modules.push(m);}
  const allNodes=modules.flatMap(m=>m.nodes.map(n=>({...n,module_id:m.module_id,module_title:m.title})));return {modules,current:allNodes.find(n=>n.status==='current')||null,next:allNodes.find(n=>n.status==='next')||null};
}
function canStartWorkflowNode(classId,moduleId,nodeId){const p=workflowProgressForClass(classId),n=p.modules.find(m=>String(m.module_id)===String(moduleId))?.nodes.find(x=>String(x.id)===String(nodeId));return n?.status==='next'||n?.status==='current'}
function beginWorkflowNode(classId,moduleId,node,userId,{override=false}={}){
  if(!node)return null;const existing=db().prepare("SELECT node_id FROM class_workflow_progress WHERE class_id=? AND status='current' LIMIT 1").get(Number(classId));if(existing&&String(existing.node_id)!==String(node.id))throw Object.assign(new Error('Finish the current workflow section before starting another one.'),{status:409});if(!override&&!canStartWorkflowNode(classId,moduleId,node.id))throw Object.assign(new Error('Complete the highlighted next section before jumping ahead.'),{status:409});setWorkflowNodeState(classId,moduleId,node.id,'current',userId);engine.log(classId,userId,'workflow_node_started','workflow_node',node.id,{module_id:moduleId,title:workflowNodeTitle(findModule(getCourseContentByClass(classId),moduleId),node)});return node;
}
function completeWorkflowNode(classId,moduleId,nodeId,userId,{selectedNextNodeId=undefined,status='completed'}={}){if(!moduleId||!nodeId)return;setWorkflowNodeState(classId,moduleId,nodeId,status,userId,{selectedNextNodeId});engine.log(classId,userId,status==='skipped'?'workflow_node_skipped':'workflow_node_completed','workflow_node',nodeId,{module_id:moduleId,selected_next_node_id:selectedNextNodeId||null});}
function updateWorkflowSelectedNext(classId,moduleId,nodeId,nextActivityId){if(!moduleId||!nodeId||!nextActivityId)return null;const mod=findModule(getCourseContentByClass(classId),moduleId);if(!mod)return null;const target=workflowNodeForRef(mod,{activityId:nextActivityId});if(!target)return null;const row=db().prepare('SELECT status FROM class_workflow_progress WHERE class_id=? AND module_id=? AND node_id=?').get(Number(classId),String(moduleId),String(nodeId));if(row) setWorkflowNodeState(classId,moduleId,nodeId,row.status,null,{selectedNextNodeId:target.id});return target.id;}
function closePracticeWorkflowPaths(classId,moduleId,userId){const mod=findModule(getCourseContentByClass(classId),moduleId),wf=effectiveWorkflow(mod);if(!wf?.nodes)return;for(const n of wf.nodes.filter(x=>x.type==='participant_path')){const a=n.path_id?participantPathAggregate(classId,n.path_id):{total:0,finished:0};const st=a.total>0&&a.finished>=a.total?'completed':'skipped';setWorkflowNodeState(classId,moduleId,n.id,st,userId);}}
function workflowNodeFromLiveState(classId,state){
  if(!state?.module_id)return null;
  const mod=findModule(getCourseContentByClass(classId),state.module_id);if(!mod)return null;
  if(state.payload?.workflow_node_id)return workflowNodeForRef(mod,{nodeId:state.payload.workflow_node_id});
  if(!state.activity_id)return null;
  if(state.phase==='mission')return workflowNodeForRef(mod,{missionId:state.activity_id});
  return workflowNodeForRef(mod,{activityId:state.activity_id})||workflowNodeForRef(mod,{missionId:state.activity_id});
}

function calculateScore(activity,answer){
  const c=activity?.content||{}; const pts=Number(activity?.score?.correct??activity?.score?.points??0);
  if(activity.type==='true_false' && c.correct_answer!==undefined) return String(answer).toLowerCase()===String(c.correct_answer).toLowerCase()?pts:0;
  if(activity.type==='single_choice' && c.correct_answer!==undefined) return String(answer)===String(c.correct_answer)?pts:0;
  if(activity.type==='numeric_answer' && c.correct_answer!==undefined){ const tol=Number(c.tolerance||0); return Math.abs(Number(answer)-Number(c.correct_answer))<=tol?pts:0; }
  if(activity.type==='multiple_choice' && Array.isArray(c.correct_answers)){
    const a=[...(Array.isArray(answer)?answer:[])].map(String).sort(); const b=[...c.correct_answers].map(String).sort(); return JSON.stringify(a)===JSON.stringify(b)?pts:0;
  }
  return activity?.score?.participation!=null?Number(activity.score.participation):null;
}
function courseList(){
  return db().prepare(`SELECT c.id,c.slug,c.title,c.description,c.language,c.direction,c.is_demo,c.created_at,c.archived_at,
    (SELECT COUNT(*) FROM course_versions v WHERE v.course_id=c.id) version_count,
    (SELECT COUNT(*) FROM classes cl JOIN course_versions v2 ON v2.id=cl.course_version_id WHERE v2.course_id=c.id) class_count,
    (SELECT version FROM course_versions v3 WHERE v3.course_id=c.id ORDER BY v3.id DESC LIMIT 1) latest_version
    FROM courses c ORDER BY c.is_demo DESC,c.updated_at DESC`).all();
}
function visibleClassIds(user){
  if(!user||isAdminLike(user))return null;
  return db().prepare('SELECT class_id FROM class_trainers WHERE user_id=? ORDER BY class_id').all(Number(user.id)).map(r=>Number(r.class_id));
}
function classList(user=null){
  const ids=visibleClassIds(user),where=ids===null?'':ids.length?` WHERE cl.id IN (${ids.map(()=>'?').join(',')})`:' WHERE 1=0';
  return db().prepare(`SELECT cl.id,cl.title,cl.start_date,cl.end_date,cl.start_time,cl.end_time,cl.location,cl.capacity,cl.status,cl.is_demo,
  c.title course_title,c.id course_id,cv.version,cv.id course_version_id,u.display_name trainer_name,
  COALESCE(lc.lifecycle_status,CASE cl.status WHEN 'planned' THEN 'scheduled' WHEN 'cancelled' THEN 'archived' ELSE cl.status END) lifecycle_status,
  (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=cl.id AND e.status='active') student_count,
  (SELECT COUNT(*) FROM class_trainers ct WHERE ct.class_id=cl.id) trainer_count
  FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id JOIN courses c ON c.id=cv.course_id LEFT JOIN users u ON u.id=cl.trainer_id LEFT JOIN class_lifecycle lc ON lc.class_id=cl.id${where} ORDER BY cl.start_date DESC,cl.id DESC`).all(...(ids||[]));
}
function studentList(classId=null){
  if(classId){
    return db().prepare(`SELECT u.id,u.username,u.display_name,u.email,u.is_demo,p.profile_json,e.status enrollment_status,
      (SELECT COUNT(*) FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE r.student_id=u.id AND ai.class_id=e.class_id) response_count,
      (SELECT COUNT(*) FROM mission_progress mp WHERE mp.student_id=u.id AND mp.class_id=e.class_id AND mp.status='completed') mission_count,
      (SELECT COALESCE(SUM(COALESCE(r2.score,0)),0) FROM responses r2 JOIN activity_instances ai2 ON ai2.id=r2.instance_id WHERE r2.student_id=u.id AND ai2.class_id=e.class_id) score
      FROM enrollments e JOIN users u ON u.id=e.student_id LEFT JOIN profiles p ON p.user_id=u.id WHERE e.class_id=? ORDER BY u.display_name,u.username`).all(Number(classId)).map(r=>({...r,profile:safeJsonParse(r.profile_json,{}),profile_json:undefined}));
  }
  return db().prepare(`SELECT u.id,u.username,u.display_name,u.email,u.active,u.is_demo,p.profile_json,
    (SELECT COUNT(*) FROM enrollments e WHERE e.student_id=u.id AND e.status='active') class_count
    FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.role='student' ORDER BY u.is_demo DESC,u.display_name,u.username`).all().map(r=>({...r,profile:safeJsonParse(r.profile_json,{}),profile_json:undefined}));
}
function publicLivePayload(classId){
  const cl=getClassRow(classId); if(!cl) return null; const state=getClassState(classId); const content=getCourseContentByClass(classId); let item=null,results=null;
  if(state.phase==='practice'&&state.module_id){ const mod=findModule(content,state.module_id); item=mod?{id:'practice',type:'practice',title:state.payload?.title||'Personal practice',paths:mod.paths||[],missions:mod.missions||[],content:state.payload?.content||{}}:null; }
  else if(state.module_id&&state.activity_id){ item=findActivity(content,state.module_id,state.activity_id)||findMission(content,state.module_id,state.activity_id); }
  let instance=null;
  if(state.payload?.instance_id){ const raw=db().prepare('SELECT id,status,opened_at,closed_at,revealed_at FROM activity_instances WHERE id=?').get(Number(state.payload.instance_id)); if(raw)instance=raw; }
  if(state.payload?.instance_id && ['results','closed','activity','presentation'].includes(state.phase)) results=instanceResults(state.payload.instance_id);
  return {class:cl,state,item,results,instance,course:{title:content?.course?.title||cl.course_title,subtitle:content?.course?.subtitle||'',language:content?.course?.language||cl.language,direction:content?.course?.direction||cl.direction,branding:content?.course?.branding||{}}};
}
function parseCsv(text){
  const lines=String(text).replace(/^\uFEFF/,'').split(/\r?\n/).filter(l=>l.trim()); if(!lines.length) return [];
  const parseLine=line=>{const a=[];let s='',q=false;for(let i=0;i<line.length;i++){const ch=line[i];if(ch==='"'){if(q&&line[i+1]==='"'){s+='"';i++;}else q=!q;}else if(ch===','&&!q){a.push(s);s='';}else s+=ch;}a.push(s);return a;};
  const headers=parseLine(lines[0]).map(h=>h.trim().toLowerCase()); return lines.slice(1).map(line=>{const vals=parseLine(line);const o={};headers.forEach((h,i)=>o[h]=(vals[i]??'').trim());return o;});
}

async function handleApi(req,res,url){
  const p=url.pathname;
  if(p==='/api/health') return json(res,200,{ok:true,version:'2.1.0',port:PORT,lan:preferredLanAddress(),addresses:privateLanAddresses(),active_class_id:activeClassId()});
  if(p==='/api/public-settings'&&req.method==='GET') return json(res,200,{ok:true,brand:engine.getSetting('brand',{name:'Training Studio'}),typography:engine.getSetting('typography',{}),profile_requirements:engine.getSetting('profile_requirements',{})});
  if(p==='/api/login'&&req.method==='POST'){
    const body=await readJson(req); const u=db().prepare('SELECT * FROM users WHERE username=? COLLATE NOCASE AND active=1').get(String(body.username||'').trim());
    if(!u||!verifyPassword(String(body.password||''),u.password_hash)) return json(res,401,{ok:false,message:'The username or password is incorrect.'});
    const token=randomToken(); db().prepare('INSERT INTO sessions(token,user_id) VALUES(?,?)').run(token,u.id); db().prepare('UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?').run(u.id); engine.log(null,u.id,'signed_in','user',u.id,{});
    const sr=u.role==='trainer'?db().prepare('SELECT staff_role FROM staff_roles WHERE user_id=?').get(u.id):null; return json(res,200,{ok:true,token,user:{id:u.id,username:u.username,role:u.role,display_name:u.display_name,staff_role:sr?.staff_role||null}});
  }
  if(p==='/api/logout'&&req.method==='POST'){ const token=tokenFrom(req,url); if(token) db().prepare('DELETE FROM sessions WHERE token=?').run(token); return json(res,200,{ok:true}); }
  if(p==='/api/me'){ const u=currentUser(req,url); return json(res,200,{ok:true,user:u}); }
  if(p==='/api/heartbeat'&&req.method==='POST'){ const u=currentUser(req,url); return json(res,200,{ok:!!u}); }
  if(p==='/api/account/password'&&req.method==='POST'){
    const u=requireUser(req,res,url,['trainer','student']); if(!u)return; const b=await readJson(req); const current=String(b.current_password||''),next=String(b.new_password||'');
    const row=db().prepare('SELECT password_hash FROM users WHERE id=?').get(u.id); if(!row||!verifyPassword(current,row.password_hash))return json(res,400,{ok:false,message:'Current password is incorrect.'}); if(next.length<8)return json(res,400,{ok:false,message:'New password must be at least 8 characters.'});
    db().prepare('UPDATE users SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(hashPassword(next),u.id); const token=tokenFrom(req,url); db().prepare('DELETE FROM sessions WHERE user_id=? AND token<>?').run(u.id,token||''); engine.log(null,u.id,'password_changed','user',u.id,{}); return json(res,200,{ok:true});
  }
  if(p==='/api/events'){
    const u=currentUser(req,url); // projector is intentionally allowed without login
    res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'}); res.write(`event: ready\ndata: ${JSON.stringify({at:nowIso(),authenticated:!!u})}\n\n`);
    const client={res,user_id:u?.id||null}; sseClients.add(client); req.on('close',()=>sseClients.delete(client)); return;
  }
  if(p==='/api/network'){
    const u=trainer(req,res,url); if(!u)return; const ip=preferredLanAddress(),key=engine.getSetting('projector_control_key',''); return json(res,200,{ok:true,ip,addresses:privateLanAddresses(),links:{trainer:`http://${ip}:${PORT}/trainer`,student:`http://${ip}:${PORT}/student`,projector:`http://${ip}:${PORT}/present`,projector_control:`http://${ip}:${PORT}/present?control_key=${encodeURIComponent(key)}`}});
  }
  if(p==='/api/settings'){
    const u=trainer(req,res,url); if(!u)return;
    if(req.method==='GET') return json(res,200,{ok:true,brand:engine.getSetting('brand',{name:'Training Studio'}),typography:engine.getSetting('typography',{}),profile_requirements:engine.getSetting('profile_requirements',{}),projector_control_key:engine.getSetting('projector_control_key',''),active_class_id:activeClassId()});
    if(req.method==='POST'){ const admin=administrator(req,res,url); if(!admin)return; const b=await readJson(req); if(b.brand?.name) engine.setSetting('brand',{name:String(b.brand.name).slice(0,80)}); if(b.typography&&typeof b.typography==='object') engine.setSetting('typography',b.typography); if(b.profile_requirements&&typeof b.profile_requirements==='object')engine.setSetting('profile_requirements',b.profile_requirements); engine.log(null,admin.id,'settings_updated','system',null,{});refresh(null,'settings');return json(res,200,{ok:true}); }
  }
  if(p==='/api/dashboard/trainer'){
    const u=trainer(req,res,url); if(!u)return; const classes=classList(u),ids=visibleClassIds(u),idCsv=ids&&ids.length?ids.map(Number).join(','):''; const aid=activeClassId(); const active=aid&&canManageClass(u,aid)?getClassRow(aid):null;
    const scope=(expr)=>ids===null?'1=1':ids.length?`${expr} IN (${idCsv})`:'1=0';
    const connected=db().prepare(`SELECT COUNT(DISTINCT us.id) c FROM sessions s JOIN users us ON us.id=s.user_id JOIN enrollments e ON e.student_id=us.id WHERE datetime(s.last_seen)>=datetime('now','-90 seconds') AND us.role='student' AND e.status='active' AND ${scope('e.class_id')}`).get().c;
    const students=db().prepare(`SELECT COUNT(DISTINCT e.student_id) c FROM enrollments e WHERE e.status='active' AND ${scope('e.class_id')}`).get().c;
    const courses=ids===null?courseList().length:db().prepare(`SELECT COUNT(DISTINCT cv.course_id) c FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id WHERE ${scope('cl.id')}`).get().c;
    const recentEvents=ids===null?db().prepare(`SELECT e.*,us.display_name FROM activity_events e LEFT JOIN users us ON us.id=e.user_id ORDER BY e.id DESC LIMIT 12`).all():ids.length?db().prepare(`SELECT e.*,us.display_name FROM activity_events e LEFT JOIN users us ON us.id=e.user_id WHERE e.class_id IN (${idCsv}) ORDER BY e.id DESC LIMIT 12`).all():[];
    const today=new Date().toISOString().slice(0,10); const todayClasses=classes.filter(c=>c.start_date<=today&&c.end_date>=today&&c.status!=='cancelled');
    return json(res,200,{ok:true,summary:{courses,classes:classes.length,students,connected},active_class:active,today_classes:todayClasses,recent_events:recentEvents});
  }
  if(p==='/api/courses/editable'&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;let rows=[];if(isAdminLike(u))rows=courseList();else rows=db().prepare(`SELECT DISTINCT c.*, (SELECT COUNT(*) FROM course_versions cv WHERE cv.course_id=c.id) version_count,(SELECT cv.version FROM course_versions cv WHERE cv.course_id=c.id ORDER BY cv.id DESC LIMIT 1) latest_version,(SELECT COUNT(*) FROM classes cl JOIN course_versions cv2 ON cv2.id=cl.course_version_id WHERE cv2.course_id=c.id) class_count FROM courses c JOIN permission_grants pg ON pg.resource_type='course' AND pg.resource_id=CAST(c.id AS TEXT) AND pg.user_id=? AND pg.action IN ('edit','*') ORDER BY c.title`).all(u.id);return json(res,200,{ok:true,courses:rows});
  }
  if(p==='/api/courses'){
    const u=trainer(req,res,url); if(!u)return;
    if(req.method==='GET') return json(res,200,{ok:true,courses:courseList()});
    if(req.method==='POST'){
      if(!isAdminLike(u)&&!hasGrant(u,'course','*','create'))return json(res,403,{ok:false,message:'You do not have permission to create courses.'});
      const b=await readJson(req); const title=String(b.title||'').trim(); if(!title)return json(res,400,{ok:false,message:'Course title is required.'});
      let slug=slugify(b.slug||title),n=2; while(db().prepare('SELECT id FROM courses WHERE slug=?').get(slug)) slug=`${slug}-${n++}`;
      const info=db().prepare('INSERT INTO courses(slug,title,description,language,direction) VALUES(?,?,?,?,?)').run(slug,title,String(b.description||''),String(b.language||'en'),b.direction==='rtl'?'rtl':'ltr');
      const courseId=Number(info.lastInsertRowid);
      const makeDraft=b.create_draft!==false;
      let versionId=null;
      if(makeDraft){
        const version=String(b.version||'1.0').trim()||'1.0';
        const content={format:'training-engine-course',schema_version:'2.0',course:{id:slug,version,title,subtitle:'',description:String(b.description||''),language:String(b.language||'en'),direction:b.direction==='rtl'?'rtl':'ltr',duration_minutes:0,branding:{typography:{}},objectives:[],modules:[]}};
        const contentJson=JSON.stringify(content);
        const vr=db().prepare('INSERT INTO course_versions(course_id,version,status,content_json,source_manifest_json,checksum,schema_version) VALUES(?,?,?,?,?,?,?)').run(courseId,version,'draft',contentJson,'{}',sha256(contentJson),'2.0');
        versionId=Number(vr.lastInsertRowid);
      }
      engine.log(null,u.id,'course_created','course',courseId,{title,version_id:versionId}); refresh(null,'courses'); return json(res,201,{ok:true,id:courseId,version_id:versionId});
    }
  }
  if(/^\/api\/courses\/\d+$/.test(p)){
    const u=trainer(req,res,url); if(!u)return; const id=Number(p.split('/').pop()); const c=db().prepare('SELECT * FROM courses WHERE id=?').get(id); if(!c)return json(res,404,{ok:false,message:'Course not found.'});
    if(req.method==='GET'){const versions=db().prepare('SELECT id,version,status,checksum,is_demo,created_at,updated_at,parent_version_id,schema_version FROM course_versions WHERE course_id=? ORDER BY id DESC').all(id); return json(res,200,{ok:true,course:c,versions});}
    if(req.method==='PATCH'){if(!isAdminLike(u)&&!hasGrant(u,'course',id,'edit'))return json(res,403,{ok:false,message:'You do not have permission to edit this course.'});const b=await readJson(req);db().prepare('UPDATE courses SET title=?,description=?,language=?,direction=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(String(b.title??c.title).trim()||c.title,String(b.description??c.description??''),String(b.language??c.language),b.direction==='rtl'?'rtl':'ltr',id);engine.log(null,u.id,'course_updated','course',id,{});refresh(null,'courses');return json(res,200,{ok:true});}
    if(req.method==='DELETE'){if(!isAdminLike(u)&&!hasGrant(u,'course',id,'delete'))return json(res,403,{ok:false,message:'You do not have permission to archive this course.'});db().prepare('UPDATE courses SET archived_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(id);engine.log(null,u.id,'course_archived','course',id,{});refresh(null,'courses');return json(res,200,{ok:true,archived:true});}
  }
  if(p==='/api/courses/validate'&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const b=await readBuffer(req,MAX_PACKAGE); const filename=decodeURIComponent(String(req.headers['x-file-name']||'course.json')); const result=parseCoursePackage(b,filename); return json(res,result.ok?200:422,{ok:result.ok,errors:result.errors,warnings:result.warnings,summary:result.summary,manifest:result.manifest});
  }
  if(p==='/api/courses/import'&&req.method==='POST'){
    const u=administrator(req,res,url); if(!u)return; const b=await readBuffer(req,MAX_PACKAGE); const filename=decodeURIComponent(String(req.headers['x-file-name']||'course.json')); const result=parseCoursePackage(b,filename);
    if(!result.ok) return json(res,422,{ok:false,errors:result.errors,warnings:result.warnings});
    const c=result.course.course; const version=String(req.headers['x-course-version']||c.version||'1.0').trim();
    let course=db().prepare('SELECT * FROM courses WHERE slug=?').get(slugify(c.id||c.title)); let createdAssetRoot=null;
    const tx=()=>engine.transaction(()=>{
      if(!course){ const cr=db().prepare('INSERT INTO courses(slug,title,description,language,direction) VALUES(?,?,?,?,?)').run(slugify(c.id||c.title),c.title,String(c.description||''),c.language||'en',c.direction||'ltr'); course={id:Number(cr.lastInsertRowid)}; }
      else db().prepare('UPDATE courses SET title=?,description=?,language=?,direction=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(c.title,String(c.description||''),c.language||'en',c.direction||'ltr',course.id);
      if(db().prepare('SELECT id FROM course_versions WHERE course_id=? AND version=?').get(course.id,version)) throw Object.assign(new Error('VERSION_EXISTS'),{friendly:`Version ${version} already exists for this course.`});
      const contentJson=JSON.stringify(result.course); const vr=db().prepare('INSERT INTO course_versions(course_id,version,status,content_json,source_manifest_json,checksum) VALUES(?,?,?,?,?,?)').run(course.id,version,'published',contentJson,JSON.stringify(result.manifest||{}),sha256(contentJson));
      const versionId=Number(vr.lastInsertRowid); const assetRoot=ensureDir(path.join(STORAGE_DIR,'course-assets',String(versionId))); createdAssetRoot=assetRoot;
      for(const a of result.assets){ const rel=safeRelativePath(a.key); if(!rel)continue; const dest=path.join(assetRoot,rel); ensureDir(path.dirname(dest)); fs.writeFileSync(dest,a.data); db().prepare('INSERT INTO course_assets(course_version_id,asset_key,stored_path,mime_type,size_bytes,sha256) VALUES(?,?,?,?,?,?)').run(versionId,rel,dest,a.mime,a.size,a.sha256); }
      return {course_id:course.id,version_id:versionId};
    });
    try{ const ids=tx(); engine.log(null,u.id,'course_imported','course',ids.course_id,{version,filename}); refresh(null,'courses'); return json(res,201,{ok:true,...ids,summary:result.summary,warnings:result.warnings}); }
    catch(e){ if(createdAssetRoot)fs.rmSync(createdAssetRoot,{recursive:true,force:true}); return json(res,409,{ok:false,message:e.friendly||'The course version could not be imported.'}); }
  }
  if(/^\/api\/course-versions\/\d+\/content$/.test(p)&&req.method==='GET'){
    const u=trainer(req,res,url); if(!u)return; const id=Number(p.split('/')[3]); const r=db().prepare('SELECT cv.*,c.title course_title FROM course_versions cv JOIN courses c ON c.id=cv.course_id WHERE cv.id=?').get(id); if(!r)return json(res,404,{ok:false,message:'Course version not found.'}); return json(res,200,{ok:true,version:{id:r.id,version:r.version,status:r.status,course_title:r.course_title},content:safeJsonParse(r.content_json,{})});
  }
  if(p==='/api/classes/import'&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return;
    const b=await readJson(req,MAX_JSON); if(b.format!=='training-engine-class'||!['1.0','1.1','2.0'].includes(String(b.schema_version||''))||!b.class)return json(res,422,{ok:false,message:'Class file does not match the Training Engine class format.'});
    const c=b.class,slug=slugify(c.course_slug||c.course_id||''),version=String(c.course_version||'').trim();
    const v=db().prepare(`SELECT cv.id FROM course_versions cv JOIN courses co ON co.id=cv.course_id WHERE co.slug=? AND cv.version=?`).get(slug,version);
    if(!v)return json(res,422,{ok:false,message:`Course ${slug} version ${version} is not installed.`});
    const title=String(c.title||'').trim(); if(!title)return json(res,422,{ok:false,message:'Class title is required.'});
    try{
      const result=engine.transaction(()=>{
        const info=db().prepare(`INSERT INTO classes(course_version_id,title,start_date,end_date,start_time,end_time,location,capacity,trainer_id,status) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(v.id,title,c.start_date||null,c.end_date||null,c.start_time||null,c.end_time||null,String(c.location||''),Math.max(1,Math.min(500,Number(c.capacity||20))),u.id,'planned');
        const classId=Number(info.lastInsertRowid); db().prepare('INSERT INTO classroom_state(class_id,phase,payload_json) VALUES(?,?,?)').run(classId,'waiting','{}'); const lifecycle=['draft','scheduled','active','completed','archived'].includes(String(c.status||''))?String(c.status):'scheduled'; db().prepare("INSERT OR IGNORE INTO class_lifecycle(class_id,lifecycle_status) VALUES(?,?)").run(classId,lifecycle); db().prepare("INSERT OR IGNORE INTO class_trainers(class_id,user_id,assignment_role) VALUES(?,?,'lead')").run(classId,u.id);
        const sessions=Array.isArray(c.sessions)?c.sessions:[];
        if(sessions.length) for(const se of sessions) db().prepare('INSERT INTO class_sessions(class_id,title,session_date,start_time,end_time) VALUES(?,?,?,?,?)').run(classId,String(se.title||'Session'),se.date||se.session_date||null,se.start_time||null,se.end_time||null);
        else if(c.start_date) db().prepare('INSERT INTO class_sessions(class_id,title,session_date,start_time,end_time) VALUES(?,?,?,?,?)').run(classId,'Session 1',c.start_date,c.start_time||null,c.end_time||null);
        return classId;
      });
      engine.log(result,u.id,'class_imported','class',result,{title}); refresh(result,'classes'); return json(res,201,{ok:true,id:result});
    }catch(e){return json(res,409,{ok:false,message:'The class could not be imported.'});}
  }
  if(p==='/api/classes'){
    const u=trainer(req,res,url); if(!u)return;
    if(req.method==='GET') return json(res,200,{ok:true,classes:classList(u),active_class_id:activeClassId()&&canManageClass(u,activeClassId())?activeClassId():null});
    if(req.method==='POST'){
      if(!isAdminLike(u)&&!hasGrant(u,'class','*','create'))return json(res,403,{ok:false,message:'You do not have permission to create classes.'});
      const b=await readJson(req); const versionId=Number(b.course_version_id); if(!db().prepare('SELECT id FROM course_versions WHERE id=?').get(versionId))return json(res,400,{ok:false,message:'Choose a valid course version.'});
      const title=String(b.title||'').trim(); if(!title)return json(res,400,{ok:false,message:'Class title is required.'});
      const cap=Math.max(1,Math.min(500,Number(b.capacity||20)));
      const requestedLead=Number(b.trainer_id||0); const leadUser=requestedLead?db().prepare("SELECT id FROM users WHERE id=? AND role='trainer' AND active=1").get(requestedLead):null;
      const leadId=leadUser?Number(leadUser.id):Number(u.id);
      const info=db().prepare(`INSERT INTO classes(course_version_id,title,start_date,end_date,start_time,end_time,location,capacity,trainer_id,status,timezone) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
        .run(versionId,title,b.start_date||null,b.end_date||null,b.start_time||null,b.end_time||null,String(b.location||''),cap,leadId,String(b.status||'planned'),String(b.timezone||''));
      const id=Number(info.lastInsertRowid); db().prepare('INSERT OR IGNORE INTO classroom_state(class_id,phase,payload_json) VALUES(?,?,?)').run(id,'waiting','{}'); db().prepare("INSERT OR IGNORE INTO class_lifecycle(class_id,lifecycle_status) VALUES(?,?)").run(id,b.lifecycle_status||'draft');
      const trainers=Array.isArray(b.trainers)?b.trainers:[]; if(!trainers.length)trainers.push({user_id:leadId,assignment_role:'lead'}); if(!trainers.some(x=>x.assignment_role==='lead'))trainers.unshift({user_id:leadId,assignment_role:'lead'});
      for(const x of trainers){const uid=Number(x.user_id);if(!db().prepare("SELECT id FROM users WHERE id=? AND role='trainer' AND active=1").get(uid))continue;const ar=['lead','trainer','assistant'].includes(x.assignment_role)?x.assignment_role:'trainer';db().prepare('INSERT OR REPLACE INTO class_trainers(class_id,user_id,assignment_role) VALUES(?,?,?)').run(id,uid,ar);if(ar==='lead')db().prepare('UPDATE classes SET trainer_id=? WHERE id=?').run(uid,id);}
      const participantIds=Array.isArray(b.participant_ids)?b.participant_ids:[];for(const sid0 of participantIds){const sid=Number(sid0);if(db().prepare("SELECT id FROM users WHERE id=? AND role='student' AND active=1").get(sid))db().prepare("INSERT INTO enrollments(class_id,student_id,status) VALUES(?,?,'active') ON CONFLICT(class_id,student_id) DO UPDATE SET status='active'").run(id,sid);}
      const sessions=Array.isArray(b.sessions)?b.sessions:[]; if(sessions.length){for(const ses of sessions){db().prepare('INSERT INTO class_sessions(class_id,title,session_date,start_time,end_time) VALUES(?,?,?,?,?)').run(id,String(ses.title||'Session'),ses.session_date||null,ses.start_time||null,ses.end_time||null)}} else if(b.start_date)db().prepare('INSERT INTO class_sessions(class_id,title,session_date,start_time,end_time) VALUES(?,?,?,?,?)').run(id,'Session 1',b.start_date||null,b.start_time||null,b.end_time||null);
      engine.log(id,u.id,'class_created','class',id,{title,trainers:trainers.length,participants:participantIds.length}); refresh(id,'classes'); return json(res,201,{ok:true,id});
    }
  }
  if(/^\/api\/classes\/\d+$/.test(p)){
    const u=trainer(req,res,url); if(!u)return; const id=Number(p.split('/').pop()); const cl=getClassRow(id); if(!cl)return json(res,404,{ok:false,message:'Class not found.'});
    if(req.method==='GET'){if(!requireClassAccess(u,id,res))return;const sessions=db().prepare('SELECT * FROM class_sessions WHERE class_id=? ORDER BY session_date,start_time').all(id); const students=studentList(id); const teams=db().prepare('SELECT * FROM teams WHERE class_id=? ORDER BY id').all(id).map(t=>({...t,members:db().prepare(`SELECT u.id,u.display_name,u.username FROM team_members tm JOIN users u ON u.id=tm.student_id WHERE tm.team_id=?`).all(t.id)})); const trainers=db().prepare(`SELECT u.id,u.username,u.display_name,u.email,ct.assignment_role,COALESCE(sr.staff_role,'trainer') staff_role FROM class_trainers ct JOIN users u ON u.id=ct.user_id LEFT JOIN staff_roles sr ON sr.user_id=u.id WHERE ct.class_id=? ORDER BY CASE ct.assignment_role WHEN 'lead' THEN 0 WHEN 'trainer' THEN 1 ELSE 2 END,u.display_name`).all(id); return json(res,200,{ok:true,class:cl,sessions,students,teams,trainers,state:getClassState(id)});}
    if(req.method==='PATCH'){if(!requireClassAdministration(u,id,res))return;const b=await readJson(req);db().prepare('UPDATE classes SET title=?,start_date=?,end_date=?,start_time=?,end_time=?,location=?,capacity=?,timezone=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(String(b.title??cl.title).trim()||cl.title,b.start_date??cl.start_date,b.end_date??cl.end_date,b.start_time??cl.start_time,b.end_time??cl.end_time,String(b.location??cl.location??''),Math.max(1,Math.min(500,Number(b.capacity??cl.capacity??20))),String(b.timezone??cl.timezone??''),id);engine.log(id,u.id,'class_updated','class',id,{});refresh(id,'classes');return json(res,200,{ok:true});}
    if(req.method==='DELETE'){if(!requireClassAdministration(u,id,res))return;db().prepare("INSERT INTO class_lifecycle(class_id,lifecycle_status,updated_at) VALUES(?,'archived',CURRENT_TIMESTAMP) ON CONFLICT(class_id) DO UPDATE SET lifecycle_status='archived',updated_at=CURRENT_TIMESTAMP").run(id);db().prepare("UPDATE classes SET status='cancelled',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(id);engine.log(id,u.id,'class_archived','class',id,{});refresh(id,'classes');return json(res,200,{ok:true,archived:true});}
  }

  if(/^\/api\/classes\/\d+\/sessions$/.test(p)){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'});if(!requireClassAdministration(u,classId,res))return;
    if(req.method==='GET')return json(res,200,{ok:true,sessions:db().prepare('SELECT * FROM class_sessions WHERE class_id=? ORDER BY session_date,start_time,id').all(classId)});
    if(req.method==='POST'){const b=await readJson(req);const title=String(b.title||'Session').trim()||'Session';const r=db().prepare('INSERT INTO class_sessions(class_id,title,session_date,start_time,end_time,status) VALUES(?,?,?,?,?,?)').run(classId,title,b.session_date||null,b.start_time||null,b.end_time||null,['planned','active','completed'].includes(b.status)?b.status:'planned');engine.log(classId,u.id,'class_session_created','session',r.lastInsertRowid,{title});refresh(classId,'sessions');return json(res,201,{ok:true,id:Number(r.lastInsertRowid)});}
  }
  if(/^\/api\/classes\/\d+\/sessions\/\d+$/.test(p)){
    const u=trainer(req,res,url);if(!u)return;const parts=p.split('/'),classId=Number(parts[3]),sessionId=Number(parts[5]);if(!requireClassAdministration(u,classId,res))return;const ses=db().prepare('SELECT * FROM class_sessions WHERE id=? AND class_id=?').get(sessionId,classId);if(!ses)return json(res,404,{ok:false,message:'Session not found.'});
    if(req.method==='PATCH'){const b=await readJson(req);db().prepare('UPDATE class_sessions SET title=?,session_date=?,start_time=?,end_time=?,status=? WHERE id=?').run(String(b.title??ses.title).trim()||ses.title,b.session_date??ses.session_date,b.start_time??ses.start_time,b.end_time??ses.end_time,['planned','active','completed'].includes(b.status)?b.status:ses.status,sessionId);engine.log(classId,u.id,'class_session_updated','session',sessionId,{});refresh(classId,'sessions');return json(res,200,{ok:true});}
    if(req.method==='DELETE'){db().prepare('DELETE FROM class_sessions WHERE id=? AND class_id=?').run(sessionId,classId);engine.log(classId,u.id,'class_session_deleted','session',sessionId,{});refresh(classId,'sessions');return json(res,200,{ok:true});}
  }
  if(/^\/api\/classes\/\d+\/enroll\/\d+$/.test(p)&&req.method==='DELETE'){
    const u=trainer(req,res,url);if(!u)return;const parts=p.split('/'),classId=Number(parts[3]),sid=Number(parts[5]);if(!requireClassAdministration(u,classId,res))return;if(!enrollment(classId,sid))return json(res,404,{ok:false,message:'Participant is not enrolled in this class.'});db().prepare("UPDATE enrollments SET status='withdrawn' WHERE class_id=? AND student_id=?").run(classId,sid);db().prepare('DELETE FROM team_members WHERE student_id=? AND team_id IN (SELECT id FROM teams WHERE class_id=?)').run(sid,classId);engine.log(classId,u.id,'participant_removed_from_class','student',sid,{});refresh(classId,'roster');return json(res,200,{ok:true});
  }
  if(/^\/api\/classes\/\d+\/teams$/.test(p)){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAdministration(u,classId,res))return;
    if(req.method==='POST'){const b=await readJson(req),name=String(b.name||'').trim();if(!name)return json(res,400,{ok:false,message:'Team name is required.'});const r=db().prepare('INSERT INTO teams(class_id,name) VALUES(?,?)').run(classId,name);for(const sid0 of Array.isArray(b.student_ids)?b.student_ids:[]){const sid=Number(sid0);if(enrollment(classId,sid)){db().prepare('DELETE FROM team_members WHERE student_id=? AND team_id IN (SELECT id FROM teams WHERE class_id=?)').run(sid,classId);db().prepare('INSERT OR IGNORE INTO team_members(team_id,student_id) VALUES(?,?)').run(Number(r.lastInsertRowid),sid)}}engine.log(classId,u.id,'team_created','team',r.lastInsertRowid,{name});refresh(classId,'teams');return json(res,201,{ok:true,id:Number(r.lastInsertRowid)});}
  }
  if(/^\/api\/classes\/\d+\/teams\/\d+$/.test(p)&&req.method==='DELETE'){
    const u=trainer(req,res,url);if(!u)return;const parts=p.split('/'),classId=Number(parts[3]),teamId=Number(parts[5]);if(!requireClassAdministration(u,classId,res))return;db().prepare('DELETE FROM teams WHERE id=? AND class_id=?').run(teamId,classId);engine.log(classId,u.id,'team_deleted','team',teamId,{});refresh(classId,'teams');return json(res,200,{ok:true});
  }
  if(/^\/api\/classes\/\d+\/teams\/auto$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAdministration(u,classId,res))return; if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'});
    const body=await readJson(req),count=Math.max(1,Math.min(50,Number(body.count||5))); const students=db().prepare(`SELECT student_id FROM enrollments WHERE class_id=? AND status='active' ORDER BY id`).all(classId).map(r=>r.student_id);
    if(!students.length)return json(res,409,{ok:false,message:'Add participants before creating teams.'});
    engine.transaction(()=>{db().prepare('DELETE FROM teams WHERE class_id=?').run(classId); const teamIds=[];for(let i=1;i<=count;i++){const r=db().prepare('INSERT INTO teams(class_id,name) VALUES(?,?)').run(classId,String(body.prefix||'Team')+' '+i);teamIds.push(Number(r.lastInsertRowid));}students.forEach((sid,i)=>db().prepare('INSERT INTO team_members(team_id,student_id) VALUES(?,?)').run(teamIds[i%teamIds.length],sid));});
    engine.log(classId,u.id,'teams_created','class',classId,{count});refresh(classId,'teams');return json(res,200,{ok:true,count});
  }
  if(/^\/api\/classes\/\d+\/activate$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const id=Number(p.split('/')[3]); if(!requireClassAccess(u,id,res))return; if(!getClassRow(id))return json(res,404,{ok:false,message:'Class not found.'}); setActiveClass(id); db().prepare("UPDATE classes SET status='active',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(id); db().prepare("INSERT INTO class_lifecycle(class_id,lifecycle_status,updated_at) VALUES(?,'active',CURRENT_TIMESTAMP) ON CONFLICT(class_id) DO UPDATE SET lifecycle_status='active',updated_at=CURRENT_TIMESTAMP").run(id); engine.log(id,u.id,'class_activated','class',id,{}); return json(res,200,{ok:true,class:getClassRow(id)});
  }
  if(/^\/api\/classes\/\d+\/attendance$/.test(p)){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAccess(u,classId,res))return; if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'});
    if(req.method==='GET'){
      const sessions=db().prepare('SELECT * FROM class_sessions WHERE class_id=? ORDER BY session_date,start_time,id').all(classId); const students=studentList(classId).map(x=>({id:x.id,username:x.username,display_name:x.display_name})); const records=db().prepare(`SELECT a.* FROM attendance a JOIN class_sessions cs ON cs.id=a.class_session_id WHERE cs.class_id=?`).all(classId); return json(res,200,{ok:true,sessions,students,records});
    }
    if(req.method==='POST'){
      const b=await readJson(req),sessionId=Number(b.session_id); const ses=db().prepare('SELECT id FROM class_sessions WHERE id=? AND class_id=?').get(sessionId,classId); if(!ses)return json(res,400,{ok:false,message:'Choose a valid class session.'}); const records=Array.isArray(b.records)?b.records:[]; engine.transaction(()=>{for(const r of records){const sid=Number(r.student_id),status=['present','late','absent','excused'].includes(r.status)?r.status:'present';if(enrollment(classId,sid))db().prepare(`INSERT INTO attendance(class_session_id,student_id,status,noted_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(class_session_id,student_id) DO UPDATE SET status=excluded.status,noted_at=CURRENT_TIMESTAMP`).run(sessionId,sid,status);}}); engine.log(classId,u.id,'attendance_saved','session',sessionId,{count:records.length});refresh(classId,'attendance');return json(res,200,{ok:true});
    }
  }
  if(/^\/api\/classes\/\d+\/notes$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAccess(u,classId,res))return; const b=await readJson(req); const sid=Number(b.student_id); const note=String(b.note||'').trim(); if(!note)return json(res,400,{ok:false,message:'Write a note first.'}); if(!enrollment(classId,sid))return json(res,400,{ok:false,message:'Student is not enrolled in this class.'}); const r=db().prepare('INSERT INTO student_notes(class_id,student_id,trainer_id,note) VALUES(?,?,?,?)').run(classId,sid,u.id,note); engine.log(classId,u.id,'student_note_added','student',sid,{}); return json(res,201,{ok:true,id:Number(r.lastInsertRowid)});
  }
  if(/^\/api\/classes\/\d+\/student\/\d+$/.test(p)&&req.method==='GET'){
    const u=trainer(req,res,url); if(!u)return; const parts=p.split('/'),classId=Number(parts[3]),sid=Number(parts[5]); if(!requireClassAccess(u,classId,res))return; const st=db().prepare(`SELECT u.id,u.username,u.display_name,u.email,p.profile_json FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.id=? AND u.role='student'`).get(sid); if(!st||!enrollment(classId,sid))return json(res,404,{ok:false,message:'Student not found in this class.'}); const notes=db().prepare(`SELECT n.*,u.display_name trainer_name FROM student_notes n JOIN users u ON u.id=n.trainer_id WHERE n.class_id=? AND n.student_id=? ORDER BY n.id DESC`).all(classId,sid); const responses=db().prepare(`SELECT r.id,r.answer_json,r.score,r.submitted_at,ai.title,ai.activity_type,ai.activity_id,ai.module_id FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE ai.class_id=? AND r.student_id=? ORDER BY r.id DESC`).all(classId,sid).map(r=>({...r,answer:safeJsonParse(r.answer_json,null),answer_json:undefined})); const missions=db().prepare('SELECT * FROM mission_progress WHERE class_id=? AND student_id=? ORDER BY id DESC').all(classId,sid); const achievements=db().prepare('SELECT * FROM achievements WHERE class_id=? AND student_id=? ORDER BY id DESC').all(classId,sid); const objectives=db().prepare('SELECT * FROM objective_progress WHERE class_id=? AND student_id=? ORDER BY objective_id').all(classId,sid); const events=db().prepare('SELECT * FROM activity_events WHERE class_id=? AND user_id=? ORDER BY id DESC LIMIT 100').all(classId,sid); return json(res,200,{ok:true,student:{...st,profile:safeJsonParse(st.profile_json,{}),profile_json:undefined},notes,responses,missions,achievements,objectives,events});
  }
  if(/^\/api\/classes\/\d+\/roster$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAdministration(u,classId,res))return; if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'}); const b=await readBuffer(req,2*1024*1024); const rows=parseCsv(b.toString('utf8')); let created=0,enrolled=0; const failures=[];
    const tx=()=>engine.transaction(()=>{for(const [i,row] of rows.entries()){
      const username=String(row.username||'').trim().toUpperCase(),name=String(row.full_name||row.name||'').trim(); if(!username||!name){failures.push(`Row ${i+2}: username and full_name are required.`);continue;}
      let st=db().prepare('SELECT id,role FROM users WHERE username=? COLLATE NOCASE').get(username);
      if(st&&st.role!=='student'){failures.push(`Row ${i+2}: username belongs to a staff account.`);continue;}
      if(!st){const password=String(row.password||`P${crypto.randomInt(1000,9999)}`);const r=db().prepare('INSERT INTO users(username,password_hash,role,display_name,email) VALUES(?,?,?,?,?)').run(username,hashPassword(password),'student',name,row.email||null);st={id:Number(r.lastInsertRowid),role:'student'};created++; db().prepare('INSERT OR IGNORE INTO profiles(user_id,profile_json) VALUES(?,?)').run(st.id,JSON.stringify({role:row.role||'',organization:row.organization||'',specialty:row.specialty||''}));}
      const er=db().prepare('INSERT OR IGNORE INTO enrollments(class_id,student_id) VALUES(?,?)').run(classId,st.id); if(er.changes)enrolled++;
    }}); tx(); engine.log(classId,u.id,'roster_imported','class',classId,{rows:rows.length,created,enrolled}); refresh(classId,'roster'); return json(res,200,{ok:true,rows:rows.length,created,enrolled,failures});
  }
  if(p==='/api/staff'){
    const u=trainer(req,res,url); if(!u)return;
    if(req.method==='GET'){
      const rows=db().prepare(`SELECT us.id,us.username,us.display_name,us.email,us.active,us.is_demo,COALESCE(sr.staff_role,'trainer') staff_role,
        (SELECT COUNT(*) FROM class_trainers ct WHERE ct.user_id=us.id) class_count,
        (SELECT MAX(last_seen) FROM sessions se WHERE se.user_id=us.id) last_seen
        FROM users us LEFT JOIN staff_roles sr ON sr.user_id=us.id WHERE us.role='trainer' ORDER BY us.active DESC,us.display_name`).all();
      return json(res,200,{ok:true,staff:rows});
    }
    if(req.method==='POST'){
      const admin=administrator(req,res,url); if(!admin)return; const b=await readJson(req),username=String(b.username||'').trim().toUpperCase(),name=String(b.display_name||'').trim(),password=String(b.password||'');
      if(!username||!name||password.length<8)return json(res,400,{ok:false,message:'Name, username and a password of at least 8 characters are required.'});
      if(db().prepare('SELECT id FROM users WHERE username=? COLLATE NOCASE').get(username))return json(res,409,{ok:false,message:'That username is already in use.'});
      const requestedRole=String(b.staff_role||'trainer'); if(requestedRole==='super_admin'&&(admin.staff_role||'')!=='super_admin')return json(res,403,{ok:false,message:'Only a super administrator can create another super administrator.'}); const role=['super_admin','administrator','trainer','assistant'].includes(requestedRole)?requestedRole:'trainer'; const r=db().prepare('INSERT INTO users(username,password_hash,role,display_name,email,active) VALUES(?,?,?,?,?,1)').run(username,hashPassword(password),'trainer',name,b.email||null); const id=Number(r.lastInsertRowid);
      db().prepare('INSERT INTO profiles(user_id,profile_json) VALUES(?,?)').run(id,JSON.stringify(b.profile||{})); db().prepare('INSERT INTO staff_roles(user_id,staff_role) VALUES(?,?)').run(id,role); db().prepare('INSERT OR IGNORE INTO account_controls(user_id,must_change_password) VALUES(?,?)').run(id,b.must_change_password?1:0); engine.log(null,admin.id,'staff_created','user',id,{staff_role:role}); refresh(null,'staff'); return json(res,201,{ok:true,id});
    }
  }
  if(/^\/api\/staff\/\d+$/.test(p)&&req.method==='PATCH'){
    const admin=administrator(req,res,url); if(!admin)return; const id=Number(p.split('/').pop()),b=await readJson(req); const row=db().prepare("SELECT id FROM users WHERE id=? AND role='trainer'").get(id); if(!row)return json(res,404,{ok:false,message:'Trainer not found.'});
    const name=String(b.display_name||'').trim(),email=b.email===undefined?undefined:String(b.email||'').trim(); if(name)db().prepare('UPDATE users SET display_name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(name,id); if(email!==undefined)db().prepare('UPDATE users SET email=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(email||null,id); if(b.active!==undefined)db().prepare('UPDATE users SET active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(b.active?1:0,id); if(['super_admin','administrator','trainer','assistant'].includes(b.staff_role)){if(b.staff_role==='super_admin'&&(admin.staff_role||'')!=='super_admin')return json(res,403,{ok:false,message:'Only a super administrator can grant super administrator access.'});db().prepare("INSERT INTO staff_roles(user_id,staff_role,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET staff_role=excluded.staff_role,updated_at=CURRENT_TIMESTAMP").run(id,b.staff_role);} engine.log(null,admin.id,'staff_updated','user',id,{}); refresh(null,'staff'); return json(res,200,{ok:true});
  }
  if(/^\/api\/staff\/\d+\/reset-password$/.test(p)&&req.method==='POST'){
    const admin=administrator(req,res,url); if(!admin)return; const id=Number(p.split('/')[3]),b=await readJson(req),password=String(b.password||''); if(password.length<8)return json(res,400,{ok:false,message:'Password must be at least 8 characters.'}); const r=db().prepare("UPDATE users SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND role='trainer'").run(hashPassword(password),id); if(!r.changes)return json(res,404,{ok:false,message:'Trainer not found.'}); db().prepare('DELETE FROM sessions WHERE user_id=?').run(id); db().prepare("INSERT INTO account_controls(user_id,must_change_password,last_password_reset_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET must_change_password=excluded.must_change_password,last_password_reset_at=CURRENT_TIMESTAMP").run(id,b.must_change_password?1:0); engine.log(null,admin.id,'password_reset','user',id,{}); return json(res,200,{ok:true});
  }
  if(/^\/api\/students\/\d+\/account$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const id=Number(p.split('/')[3]),b=await readJson(req); const st=db().prepare("SELECT id FROM users WHERE id=? AND role='student'").get(id); if(!st)return json(res,404,{ok:false,message:'Participant not found.'}); if(!canAdministerStudent(u,id))return json(res,403,{ok:false,message:'Lead trainer or administrator access is required for this participant.'});
    if(b.action==='deactivate'||b.action==='activate'){db().prepare('UPDATE users SET active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(b.action==='activate'?1:0,id); if(b.action==='deactivate')db().prepare('DELETE FROM sessions WHERE user_id=?').run(id); engine.log(null,u.id,b.action==='activate'?'participant_activated':'participant_deactivated','user',id,{});refresh(null,'students');return json(res,200,{ok:true});}
    if(b.action==='reset_password'){const password=String(b.password||'');if(password.length<4)return json(res,400,{ok:false,message:'Password must be at least 4 characters.'});db().prepare('UPDATE users SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(hashPassword(password),id);db().prepare('DELETE FROM sessions WHERE user_id=?').run(id);db().prepare("INSERT INTO account_controls(user_id,must_change_password,last_password_reset_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET must_change_password=excluded.must_change_password,last_password_reset_at=CURRENT_TIMESTAMP").run(id,b.must_change_password?1:0);engine.log(null,u.id,'password_reset','user',id,{});return json(res,200,{ok:true});}
    return json(res,400,{ok:false,message:'Choose a valid account action.'});
  }
  if(/^\/api\/classes\/\d+\/trainers$/.test(p)){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAccess(u,classId,res))return; if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'});
    if(req.method==='GET'){const rows=db().prepare(`SELECT us.id,us.username,us.display_name,us.email,ct.assignment_role,COALESCE(sr.staff_role,'trainer') staff_role FROM class_trainers ct JOIN users us ON us.id=ct.user_id LEFT JOIN staff_roles sr ON sr.user_id=us.id WHERE ct.class_id=? ORDER BY CASE ct.assignment_role WHEN 'lead' THEN 0 WHEN 'trainer' THEN 1 ELSE 2 END,us.display_name`).all(classId);return json(res,200,{ok:true,trainers:rows});}
    if(req.method==='POST'){if(!requireClassAdministration(u,classId,res))return;const b=await readJson(req),rows=Array.isArray(b.trainers)?b.trainers:[];engine.transaction(()=>{db().prepare('DELETE FROM class_trainers WHERE class_id=?').run(classId);for(const x of rows){const uid=Number(x.user_id);if(!db().prepare("SELECT id FROM users WHERE id=? AND role='trainer' AND active=1").get(uid))continue;const ar=['lead','trainer','assistant'].includes(x.assignment_role)?x.assignment_role:'trainer';db().prepare('INSERT INTO class_trainers(class_id,user_id,assignment_role) VALUES(?,?,?)').run(classId,uid,ar);}const lead=rows.find(x=>x.assignment_role==='lead');if(lead)db().prepare('UPDATE classes SET trainer_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(Number(lead.user_id),classId);});engine.log(classId,u.id,'class_trainers_updated','class',classId,{count:rows.length});refresh(classId,'class_trainers');return json(res,200,{ok:true});}
  }
  if(/^\/api\/classes\/\d+\/lifecycle$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAdministration(u,classId,res))return;const b=await readJson(req),status=String(b.status||'');if(!['draft','scheduled','active','completed','archived'].includes(status))return json(res,400,{ok:false,message:'Choose a valid class status.'});if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'});db().prepare("INSERT INTO class_lifecycle(class_id,lifecycle_status,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(class_id) DO UPDATE SET lifecycle_status=excluded.lifecycle_status,updated_at=CURRENT_TIMESTAMP").run(classId,status);const legacy=status==='draft'||status==='scheduled'?'planned':status==='archived'?'cancelled':status;db().prepare('UPDATE classes SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(legacy,classId);engine.log(classId,u.id,'class_status_changed','class',classId,{status});refresh(classId,'class_status');return json(res,200,{ok:true,status});
  }
  if(/^\/api\/classes\/\d+\/enroll$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAdministration(u,classId,res))return;const b=await readJson(req),sid=Number(b.student_id);if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'});if(!db().prepare("SELECT id FROM users WHERE id=? AND role='student' AND active=1").get(sid))return json(res,404,{ok:false,message:'Participant not found.'});db().prepare("INSERT INTO enrollments(class_id,student_id,status) VALUES(?,?,'active') ON CONFLICT(class_id,student_id) DO UPDATE SET status='active'").run(classId,sid);engine.log(classId,u.id,'participant_enrolled','student',sid,{});refresh(classId,'roster');return json(res,200,{ok:true});
  }
  if(/^\/api\/classes\/\d+\/roster\/preview$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!getClassRow(classId))return json(res,404,{ok:false,message:'Class not found.'});if(!requireClassAdministration(u,classId,res))return;const b=await readBuffer(req,2*1024*1024),rows=parseCsv(b.toString('utf8')),seen=new Set(),preview=[];let valid=0;for(const [i,row] of rows.entries()){const username=String(row.username||'').trim().toUpperCase(),name=String(row.full_name||row.name||'').trim(),issues=[];if(!username)issues.push('Username is required.');if(!name)issues.push('Full name is required.');if(username&&(seen.has(username)||db().prepare("SELECT id FROM users WHERE username=? COLLATE NOCASE AND role<>'student'").get(username)))issues.push('Username conflicts with another account.');if(username)seen.add(username);const existing=username?db().prepare("SELECT id,display_name FROM users WHERE username=? COLLATE NOCASE AND role='student'").get(username):null;if(!issues.length)valid++;preview.push({row:i+2,username,full_name:name,existing:!!existing,issues});}return json(res,200,{ok:true,total:rows.length,valid,invalid:rows.length-valid,preview:preview.slice(0,200)});
  }
  if(p==='/api/readiness'&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(url.searchParams.get('class_id')||activeClassId()||0);if(classId&&!requireClassAccess(u,classId,res))return;const cl=classId?getClassRow(classId):null,ip=preferredLanAddress();let dbOk=false;try{dbOk=db().prepare('PRAGMA quick_check').get().quick_check==='ok'}catch{}const participants=classId?db().prepare("SELECT COUNT(*) c FROM enrollments WHERE class_id=? AND status='active'").get(classId).c:0;const trainers=classId?db().prepare('SELECT COUNT(*) c FROM class_trainers WHERE class_id=?').get(classId).c:0;const contentOk=!!(classId&&getCourseContentByClass(classId));const connected=classId?db().prepare(`SELECT COUNT(DISTINCT us.id) c FROM enrollments e JOIN users us ON us.id=e.student_id JOIN sessions se ON se.user_id=us.id WHERE e.class_id=? AND datetime(se.last_seen)>=datetime('now','-90 seconds')`).get(classId).c:0;return json(res,200,{ok:true,class:cl,database_ok:dbOk,content_ok:contentOk,participants,trainers,connected,ip,links:{trainer:`http://${ip}:${PORT}/trainer`,participant:`http://${ip}:${PORT}/student`,projector:`http://${ip}:${PORT}/present`},checks:[{key:'database',ok:dbOk},{key:'course',ok:contentOk},{key:'trainer',ok:trainers>0},{key:'participants',ok:participants>0},{key:'network',ok:!!ip}]});
  }
  if(p==='/api/reports/center'&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;
    const ids=visibleClassIds(u),scope=(alias='cl')=>ids===null?'1=1':ids.length?`${alias}.id IN (${ids.map(Number).join(',')})`:'1=0';
    const courseVisible=ids===null?'1=1':`EXISTS (SELECT 1 FROM course_versions cvx JOIN classes clx ON clx.course_version_id=cvx.id WHERE cvx.course_id=c.id AND ${scope('clx')})`;
    const courses=db().prepare(`SELECT c.id,c.title,c.slug,
      (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id WHERE cv.course_id=c.id AND ${scope('cl')}) classes,
      (SELECT COUNT(DISTINCT e.student_id) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN enrollments e ON e.class_id=cl.id AND e.status='active' WHERE cv.course_id=c.id AND ${scope('cl')}) participants,
      (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id LEFT JOIN class_lifecycle lc ON lc.class_id=cl.id WHERE cv.course_id=c.id AND ${scope('cl')} AND COALESCE(lc.lifecycle_status,cl.status)='completed') completed_classes,
      (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN activity_instances ai ON ai.class_id=cl.id JOIN responses r ON r.instance_id=ai.id WHERE cv.course_id=c.id AND ${scope('cl')}) responses,
      (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN mission_progress mp ON mp.class_id=cl.id WHERE cv.course_id=c.id AND ${scope('cl')} AND mp.status='completed') missions,
      ROUND(COALESCE((SELECT AVG(r.score) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN activity_instances ai ON ai.class_id=cl.id JOIN responses r ON r.instance_id=ai.id WHERE cv.course_id=c.id AND ${scope('cl')} AND r.score IS NOT NULL),0),2) average_score
      FROM courses c WHERE ${courseVisible} ORDER BY c.is_demo DESC,c.title`).all();
    const classes=db().prepare(`SELECT cl.id,cl.title,c.title course_title,cv.version,COALESCE(lc.lifecycle_status,cl.status) status,
      (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=cl.id AND e.status='active') participants,
      (SELECT COUNT(*) FROM activity_instances ai JOIN responses r ON r.instance_id=ai.id WHERE ai.class_id=cl.id) responses,
      (SELECT COUNT(*) FROM mission_progress mp WHERE mp.class_id=cl.id AND mp.status='completed') missions,
      ROUND(COALESCE((SELECT AVG(r.score) FROM activity_instances ai JOIN responses r ON r.instance_id=ai.id WHERE ai.class_id=cl.id AND r.score IS NOT NULL),0),2) average_score,
      (SELECT COUNT(DISTINCT op.objective_id) FROM objective_progress op WHERE op.class_id=cl.id AND op.achieved=1) objectives_reached,
      (SELECT COUNT(*) FROM achievements ach WHERE ach.class_id=cl.id) achievements
      FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id JOIN courses c ON c.id=cv.course_id LEFT JOIN class_lifecycle lc ON lc.class_id=cl.id
      WHERE ${scope('cl')} ORDER BY cl.start_date DESC,cl.id DESC`).all();
    const studentVisible=ids===null?'1=1':ids.length?`EXISTS (SELECT 1 FROM enrollments ev WHERE ev.student_id=us.id AND ev.status<>'withdrawn' AND ev.class_id IN (${ids.map(Number).join(',')}))`:'1=0';
    const studentClassFilter=ids===null?'1=1':ids.length?`e.class_id IN (${ids.map(Number).join(',')})`:'1=0';
    const students=db().prepare(`SELECT us.id,us.username,us.display_name,us.active,
      (SELECT COUNT(DISTINCT e.class_id) FROM enrollments e WHERE e.student_id=us.id AND e.status<>'withdrawn' AND ${studentClassFilter}) classes,
      (SELECT COUNT(*) FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE r.student_id=us.id AND ${ids===null?'1=1':ids.length?`ai.class_id IN (${ids.map(Number).join(',')})`:'1=0'}) responses,
      (SELECT COUNT(*) FROM mission_progress mp WHERE mp.student_id=us.id AND mp.status='completed' AND ${ids===null?'1=1':ids.length?`mp.class_id IN (${ids.map(Number).join(',')})`:'1=0'}) missions,
      ROUND(COALESCE((SELECT SUM(COALESCE(r.score,0)) FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE r.student_id=us.id AND ${ids===null?'1=1':ids.length?`ai.class_id IN (${ids.map(Number).join(',')})`:'1=0'}),0),2) score,
      (SELECT COUNT(DISTINCT op.objective_id) FROM objective_progress op WHERE op.student_id=us.id AND op.achieved=1 AND ${ids===null?'1=1':ids.length?`op.class_id IN (${ids.map(Number).join(',')})`:'1=0'}) objectives,
      (SELECT COUNT(*) FROM achievements ach WHERE ach.student_id=us.id AND ${ids===null?'1=1':ids.length?`ach.class_id IN (${ids.map(Number).join(',')})`:'1=0'}) achievements
      FROM users us WHERE us.role='student' AND ${studentVisible} ORDER BY us.is_demo DESC,us.display_name`).all();
    const trainerFilter=isAdminLike(u)?'1=1':`us.id=${Number(u.id)}`;
    const trainers=db().prepare(`SELECT us.id,us.display_name,us.username,us.active,COALESCE(sr.staff_role,'trainer') staff_role,
      (SELECT COUNT(DISTINCT ct.class_id) FROM class_trainers ct WHERE ct.user_id=us.id AND ${ids===null?'1=1':ids.length?`ct.class_id IN (${ids.map(Number).join(',')})`:'1=0'}) classes,
      (SELECT COUNT(DISTINCT e.student_id) FROM class_trainers ct JOIN enrollments e ON e.class_id=ct.class_id AND e.status='active' WHERE ct.user_id=us.id AND ${ids===null?'1=1':ids.length?`ct.class_id IN (${ids.map(Number).join(',')})`:'1=0'}) participants
      FROM users us LEFT JOIN staff_roles sr ON sr.user_id=us.id WHERE us.role='trainer' AND ${trainerFilter} ORDER BY us.display_name`).all();
    return json(res,200,{ok:true,courses,classes,students,trainers});
  }
  if(p==='/api/reports/analytics'&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;const ids=visibleClassIds(u);const idList=ids===null?null:ids.map(Number);const scoped=(col)=>idList===null?'1=1':idList.length?`${col} IN (${idList.join(',')})`:'1=0';
    const summary={
      courses:idList===null?db().prepare('SELECT COUNT(*) c FROM courses').get().c:db().prepare(`SELECT COUNT(DISTINCT cv.course_id) c FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id WHERE ${scoped('cl.id')}`).get().c,
      classes:db().prepare(`SELECT COUNT(*) c FROM classes cl WHERE ${scoped('cl.id')}`).get().c,
      participants:db().prepare(`SELECT COUNT(DISTINCT e.student_id) c FROM enrollments e WHERE e.status='active' AND ${scoped('e.class_id')}`).get().c,
      responses:db().prepare(`SELECT COUNT(*) c FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE ${scoped('ai.class_id')}`).get().c,
      finished_paths:db().prepare(`SELECT COUNT(*) c FROM participant_runtime_state prs WHERE prs.status='finished' AND ${scoped('prs.class_id')}`).get().c,
      help_requests:db().prepare(`SELECT COUNT(*) c FROM help_requests hr WHERE ${scoped('hr.class_id')}`).get().c
    };
    const attendance=db().prepare(`SELECT a.status label,COUNT(*) value FROM attendance a JOIN class_sessions cs ON cs.id=a.class_session_id WHERE ${scoped('cs.class_id')} GROUP BY a.status ORDER BY value DESC`).all();
    const pathSelection=db().prepare(`SELECT COALESCE(NULLIF(prs.path_id,''),'Unselected') label,COUNT(*) value,SUM(CASE WHEN prs.status='finished' THEN 1 ELSE 0 END) finished FROM participant_runtime_state prs WHERE ${scoped('prs.class_id')} GROUP BY COALESCE(NULLIF(prs.path_id,''),'Unselected') ORDER BY value DESC LIMIT 20`).all();
    const helpByStatus=db().prepare(`SELECT hr.status label,COUNT(*) value FROM help_requests hr WHERE ${scoped('hr.class_id')} GROUP BY hr.status ORDER BY value DESC`).all();
    const completionByClass=db().prepare(`SELECT cl.id,cl.title label,COUNT(prs.student_id) participants,SUM(CASE WHEN prs.status='finished' THEN 1 ELSE 0 END) finished,ROUND(CASE WHEN COUNT(prs.student_id)=0 THEN 0 ELSE 100.0*SUM(CASE WHEN prs.status='finished' THEN 1 ELSE 0 END)/COUNT(prs.student_id) END,1) value FROM classes cl LEFT JOIN participant_runtime_state prs ON prs.class_id=cl.id WHERE ${scoped('cl.id')} GROUP BY cl.id ORDER BY cl.start_date DESC,cl.id DESC LIMIT 30`).all();
    const courseVersions=db().prepare(`SELECT c.title course,cv.version,COUNT(DISTINCT cl.id) classes,COUNT(DISTINCT e.student_id) participants,COUNT(r.id) responses,ROUND(COALESCE(AVG(r.score),0),2) average_score FROM course_versions cv JOIN courses c ON c.id=cv.course_id LEFT JOIN classes cl ON cl.course_version_id=cv.id LEFT JOIN enrollments e ON e.class_id=cl.id AND e.status='active' LEFT JOIN activity_instances ai ON ai.class_id=cl.id LEFT JOIN responses r ON r.instance_id=ai.id WHERE ${scoped('cl.id')} GROUP BY cv.id ORDER BY c.title,cv.id DESC`).all();
    const objectivePerformance=db().prepare(`SELECT op.objective_id label,COUNT(*) evidence,SUM(CASE WHEN op.achieved=1 THEN 1 ELSE 0 END) achieved,ROUND(100.0*SUM(CASE WHEN op.achieved=1 THEN 1 ELSE 0 END)/COUNT(*),1) value FROM objective_progress op WHERE ${scoped('op.class_id')} GROUP BY op.objective_id ORDER BY value ASC LIMIT 30`).all();
    const helpHotspots=db().prepare(`SELECT COALESCE(NULLIF(hr.path_id,''),'—') path,COALESCE(NULLIF(hr.activity_id,''),'—') activity,COALESCE(hr.step_index,-1) step,COUNT(*) requests FROM help_requests hr WHERE ${scoped('hr.class_id')} GROUP BY hr.path_id,hr.activity_id,hr.step_index ORDER BY requests DESC LIMIT 20`).all();
    const classActivity=db().prepare(`SELECT cl.title class_name,COUNT(DISTINCT ai.id) activities,COUNT(r.id) responses,COUNT(DISTINCT r.student_id) active_participants,ROUND(COALESCE(AVG(r.score),0),2) average_score FROM classes cl LEFT JOIN activity_instances ai ON ai.class_id=cl.id LEFT JOIN responses r ON r.instance_id=ai.id WHERE ${scoped('cl.id')} GROUP BY cl.id ORDER BY responses DESC LIMIT 30`).all();
    return json(res,200,{ok:true,summary,attendance,path_selection:pathSelection,help_by_status:helpByStatus,completion_by_class:completionByClass,course_versions:courseVersions,objectives:objectivePerformance,help_hotspots:helpHotspots,class_activity:classActivity});
  }
  if(/^\/api\/reports\/student\/\d+$/.test(p)&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;const sid=Number(p.split('/').pop());const ids=visibleClassIds(u),idCsv=ids&&ids.length?ids.map(Number).join(','):'';
    if(ids!==null){if(!ids.length||!db().prepare(`SELECT 1 FROM enrollments WHERE student_id=? AND class_id IN (${idCsv}) LIMIT 1`).get(sid))return json(res,403,{ok:false,message:'You do not have access to this participant.'});}
    const st=db().prepare(`SELECT us.id,us.username,us.display_name,us.email,us.active,p.profile_json FROM users us LEFT JOIN profiles p ON p.user_id=us.id WHERE us.id=? AND us.role='student'`).get(sid);if(!st)return json(res,404,{ok:false,message:'Participant not found.'});
    const classScope=(expr)=>ids===null?'1=1':ids.length?`${expr} IN (${idCsv})`:'1=0';
    const classes=db().prepare(`SELECT cl.id,cl.title,c.title course_title,cv.version,e.status enrollment_status,
      COALESCE((SELECT SUM(COALESCE(r.score,0)) FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE ai.class_id=cl.id AND r.student_id=?),0) score,
      (SELECT COUNT(*) FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE ai.class_id=cl.id AND r.student_id=?) responses,
      (SELECT COUNT(*) FROM mission_progress mp WHERE mp.class_id=cl.id AND mp.student_id=? AND mp.status='completed') missions,
      (SELECT COUNT(*) FROM objective_progress op WHERE op.class_id=cl.id AND op.student_id=? AND op.achieved=1) objectives,
      (SELECT COUNT(*) FROM achievements a WHERE a.class_id=cl.id AND a.student_id=?) achievements
      FROM enrollments e JOIN classes cl ON cl.id=e.class_id JOIN course_versions cv ON cv.id=cl.course_version_id JOIN courses c ON c.id=cv.course_id WHERE e.student_id=? AND ${classScope('cl.id')} ORDER BY cl.start_date DESC`).all(sid,sid,sid,sid,sid,sid);
    const attendance=db().prepare(`SELECT a.status,COUNT(*) count FROM attendance a JOIN class_sessions cs ON cs.id=a.class_session_id WHERE a.student_id=? AND ${classScope('cs.class_id')} GROUP BY a.status`).all(sid);
    const responses=db().prepare(`SELECT r.id,r.score,r.submitted_at,r.answer_json,ai.class_id,cl.title class_title,ai.module_id,ai.activity_id,ai.title,ai.activity_type FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id JOIN classes cl ON cl.id=ai.class_id WHERE r.student_id=? AND ${classScope('ai.class_id')} ORDER BY r.id DESC LIMIT 200`).all(sid).map(r=>({...r,answer:safeJsonParse(r.answer_json,null),answer_json:undefined}));
    const missions=db().prepare(`SELECT mp.*,cl.title class_title FROM mission_progress mp JOIN classes cl ON cl.id=mp.class_id WHERE mp.student_id=? AND ${classScope('mp.class_id')} ORDER BY mp.id DESC LIMIT 200`).all(sid).map(r=>({...r,progress:safeJsonParse(r.progress_json,{}),progress_json:undefined}));
    const objectives=db().prepare(`SELECT op.*,cl.title class_title FROM objective_progress op JOIN classes cl ON cl.id=op.class_id WHERE op.student_id=? AND ${classScope('op.class_id')} ORDER BY op.updated_at DESC,op.objective_id`).all(sid);
    const achievements=db().prepare(`SELECT ach.*,cl.title class_title FROM achievements ach JOIN classes cl ON cl.id=ach.class_id WHERE ach.student_id=? AND ${classScope('ach.class_id')} ORDER BY ach.id DESC`).all(sid).map(r=>({...r,metadata:safeJsonParse(r.metadata_json,{}),metadata_json:undefined}));
    const submissions=db().prepare(`SELECT sb.id,sb.class_id,cl.title class_title,sb.module_id,sb.activity_id,sb.mission_id,sb.kind,sb.original_name,sb.text_value,sb.url_value,sb.size_bytes,sb.created_at FROM submissions sb JOIN classes cl ON cl.id=sb.class_id WHERE sb.student_id=? AND ${classScope('sb.class_id')} ORDER BY sb.id DESC LIMIT 200`).all(sid);
    const recentScope=ids===null?'1=1':ids.length?`(ev.class_id IS NULL OR ev.class_id IN (${idCsv}))`:'ev.class_id IS NULL';
    const recent=db().prepare(`SELECT ev.*,cl.title class_title FROM activity_events ev LEFT JOIN classes cl ON cl.id=ev.class_id WHERE ev.user_id=? AND ${recentScope} ORDER BY ev.id DESC LIMIT 100`).all(sid).map(r=>({...r,payload:safeJsonParse(r.payload_json,{}),payload_json:undefined}));
    const totals={classes:classes.length,responses:responses.length,missions:missions.filter(x=>x.status==='completed').length,objectives:objectives.filter(x=>x.achieved).length,achievements:achievements.length,submissions:submissions.length,score:classes.reduce((a,c)=>a+Number(c.score||0),0)};
    return json(res,200,{ok:true,student:{...st,profile:safeJsonParse(st.profile_json,{}),profile_json:undefined},totals,classes,attendance,responses,missions,objectives,achievements,submissions,recent});
  }

  if(p==='/api/students'){
    const u=trainer(req,res,url); if(!u)return;
    if(req.method==='GET'){
      const classId=Number(url.searchParams.get('class_id')||0);
      if(classId){if(!requireClassAccess(u,classId,res))return;return json(res,200,{ok:true,students:studentList(classId)});}
      if(isAdminLike(u))return json(res,200,{ok:true,students:studentList()});
      const ids=visibleClassIds(u)||[];if(!ids.length)return json(res,200,{ok:true,students:[]});const q=ids.map(()=>'?').join(',');
      const rows=db().prepare(`SELECT DISTINCT us.id,us.username,us.display_name,us.email,us.active,us.is_demo,p.profile_json,(SELECT COUNT(*) FROM enrollments ee WHERE ee.student_id=us.id AND ee.status='active' AND ee.class_id IN (${q})) class_count FROM users us JOIN enrollments e ON e.student_id=us.id LEFT JOIN profiles p ON p.user_id=us.id WHERE us.role='student' AND e.class_id IN (${q}) ORDER BY us.is_demo DESC,us.display_name,us.username`).all(...ids,...ids).map(r=>({...r,profile:safeJsonParse(r.profile_json,{}),profile_json:undefined}));
      return json(res,200,{ok:true,students:rows});
    }
    if(req.method==='POST'){
      const b=await readJson(req),classId=Number(b.class_id||0);if(classId){if(!requireClassAdministration(u,classId,res))return;}else if(!isAdminLike(u))return json(res,403,{ok:false,message:'Administrator access is required to create a participant outside a class.'});
      const username=String(b.username||'').trim().toUpperCase(),name=String(b.display_name||'').trim(),password=String(b.password||''); if(!username||!name||password.length<8)return json(res,400,{ok:false,message:'Name, username and a password of at least 8 characters are required.'});
      if(db().prepare('SELECT id FROM users WHERE username=?').get(username))return json(res,409,{ok:false,message:'That username is already in use.'}); const r=db().prepare('INSERT INTO users(username,password_hash,role,display_name,email) VALUES(?,?,?,?,?)').run(username,hashPassword(password),'student',name,b.email||null); const id=Number(r.lastInsertRowid); db().prepare('INSERT INTO profiles(user_id,profile_json) VALUES(?,?)').run(id,JSON.stringify(b.profile||{})); if(classId) db().prepare('INSERT OR IGNORE INTO enrollments(class_id,student_id) VALUES(?,?)').run(classId,id); refresh(classId||null,'students'); return json(res,201,{ok:true,id});
    }
  }
  if(/^\/api\/students\/\d+\/profile$/.test(p)&&req.method==='POST'){
    const caller=requireUser(req,res,url,['trainer','student']); if(!caller)return; const sid=Number(p.split('/')[3]); if(caller.role==='student'&&caller.id!==sid)return json(res,403,{ok:false,message:'You can only edit your own profile.'}); if(caller.role==='trainer'&&!canAdministerStudent(caller,sid))return json(res,403,{ok:false,message:'Lead trainer or administrator access is required for this participant.'}); const b=await readJson(req); db().prepare('INSERT INTO profiles(user_id,profile_json,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET profile_json=excluded.profile_json,updated_at=CURRENT_TIMESTAMP').run(sid,JSON.stringify(b.profile||{})); if(b.display_name)db().prepare('UPDATE users SET display_name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(String(b.display_name).slice(0,120),sid); refresh(null,'profile'); return json(res,200,{ok:true});
  }
  if(p==='/api/live'){
    const classId=Number(url.searchParams.get('class_id')||activeClassId()||0); if(!classId)return json(res,200,{ok:true,live:null}); const viewer=currentUser(req,url); const live=publicLivePayload(classId);
    if(live?.results && viewer?.role!=='trainer'){
      const total=Number(live.results?.summary?.total||0);
      if(live.state.phase!=='results') live.results={summary:{total}};
      else {
        const summary={...live.results.summary};
        if(Array.isArray(summary.answers)) summary.answers=summary.answers.map(a=>({text:a.text}));
        live.results={summary};
      }
    }
    return json(res,200,{ok:true,live});
  }
  if(/^\/api\/live\/\d+\/launch$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAccess(u,classId,res))return; const b=await readJson(req),moduleId=String(b.module_id||''),activityId=String(b.activity_id||''); const content=getCourseContentByClass(classId); const activity=findActivity(content,moduleId,activityId); if(!activity)return json(res,404,{ok:false,message:'That activity is not part of this course version.'});
    const mod=findModule(content,moduleId),workflowNode=workflowNodeForRef(mod,{activityId,nodeId:b.workflow_node_id||null});if(workflowNode)beginWorkflowNode(classId,moduleId,workflowNode,u.id,{override:!!b.override||!b.workflow_node_id});
    const current=getClassState(classId); if(current.payload?.instance_id){ const old=db().prepare('SELECT status FROM activity_instances WHERE id=?').get(Number(current.payload.instance_id)); if(old&&old.status==='open')return json(res,409,{ok:false,message:'Finish the current activity before starting another one.'}); }
    const ir=db().prepare('INSERT INTO activity_instances(class_id,module_id,activity_id,activity_type,title,status,definition_json,created_by) VALUES(?,?,?,?,?,?,?,?)').run(classId,moduleId,activityId,activity.type,String(activity.title||'Activity'),'open',JSON.stringify(activity),u.id); const instanceId=Number(ir.lastInsertRowid); setActiveClass(classId); const phase=['presentation','announcement','timer','reveal'].includes(activity.type)?'presentation':'activity'; const state=setClassState(classId,{module_id:moduleId,activity_id:activityId,phase,payload:{instance_id:instanceId,workflow_node_id:workflowNode?.id||null}},u.id); engine.log(classId,u.id,'activity_opened','activity',activityId,{instance_id:instanceId,title:activity.title,type:activity.type}); return json(res,200,{ok:true,state,instance_id:instanceId});
  }
  if(/^\/api\/live\/\d+\/mission$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAccess(u,classId,res))return; const b=await readJson(req),moduleId=String(b.module_id||''),missionId=String(b.mission_id||''); const content=getCourseContentByClass(classId),mission=findMission(content,moduleId,missionId); if(!mission)return json(res,404,{ok:false,message:'That mission is not part of this course version.'}); const mod=findModule(content,moduleId),workflowNode=workflowNodeForRef(mod,{missionId,nodeId:b.workflow_node_id||null});if(workflowNode)beginWorkflowNode(classId,moduleId,workflowNode,u.id,{override:!!b.override||!b.workflow_node_id}); setActiveClass(classId); const state=setClassState(classId,{module_id:moduleId,activity_id:missionId,phase:'mission',payload:{mission_id:missionId,workflow_node_id:workflowNode?.id||null}},u.id); engine.log(classId,u.id,'mission_opened','mission',missionId,{title:mission.title}); return json(res,200,{ok:true,state});
  }
  if(/^\/api\/live\/\d+\/practice$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAccess(u,classId,res))return;const b=await readJson(req),moduleId=String(b.module_id||''),mod=findModule(getCourseContentByClass(classId),moduleId);if(!mod)return json(res,404,{ok:false,message:'That milestone is not part of this course version.'});
    const choices=(mod.paths||[]).length?mod.paths:(mod.missions||[]).map(m=>({id:m.id,title:m.title,goal:m.goal,steps:m.steps||[],submission:m.submission,score:m.score,achievement:m.achievement,objective_ids:m.objective_ids}));if(!choices.length)return json(res,409,{ok:false,message:'This milestone has no participant practice paths.'});
    const workflowNode=workflowNodeForRef(mod,{type:'practice_start',nodeId:b.workflow_node_id||null});if(workflowNode)beginWorkflowNode(classId,moduleId,workflowNode,u.id,{override:!!b.override||!b.workflow_node_id});
    setActiveClass(classId);db().prepare(`DELETE FROM participant_runtime_state WHERE class_id=? AND status='not_started'`).run(classId);const state=setClassState(classId,{module_id:moduleId,activity_id:null,phase:'practice',payload:{title:b.title||mod.practice_title||'Personal practice',opened_at:nowIso(),choice_count:choices.length,workflow_node_id:workflowNode?.id||null}},u.id);engine.log(classId,u.id,'practice_opened','module',moduleId,{choices:choices.length});refresh(classId,'practice');return json(res,200,{ok:true,state,choices:choices.map(x=>({id:x.id,title:x.title,goal:x.goal||''}))});
  }
  if(/^\/api\/live\/\d+\/practice\/close$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAccess(u,classId,res))return;const state=getClassState(classId);if(state.phase!=='practice')return json(res,409,{ok:false,message:'Personal practice is not currently open.'});if(state.payload?.workflow_node_id)completeWorkflowNode(classId,state.module_id,state.payload.workflow_node_id,u.id);closePracticeWorkflowPaths(classId,state.module_id,u.id);const next=setClassState(classId,{phase:'waiting',activity_id:null,payload:{practice_closed_at:nowIso()}},u.id);engine.log(classId,u.id,'practice_closed','module',state.module_id,{});refresh(classId,'practice');return json(res,200,{ok:true,state:next});
  }
  if(/^\/api\/live\/\d+\/(close|reveal|clear)$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const parts=p.split('/'),classId=Number(parts[3]),action=parts[4]; if(!requireClassAccess(u,classId,res))return; const state=getClassState(classId); const iid=Number(state.payload?.instance_id||0);
    if(action==='close'){
      if(!iid)return json(res,409,{ok:false,message:'There is no open activity to close.'});
      const instFull=db().prepare('SELECT * FROM activity_instances WHERE id=?').get(iid); if(!instFull||instFull.status!=='open')return json(res,409,{ok:false,message:'This activity is already closed.'});
      const activity=safeJsonParse(instFull.definition_json,{}),gate=activity.completion_gate||{}; let body={}; try{body=await readJson(req)}catch{};
      const resultsNow=instanceResults(iid),received=Number(resultsNow?.summary?.total||0); const eligible=activity.response_scope==='team'?db().prepare('SELECT COUNT(*) c FROM teams WHERE class_id=?').get(classId).c:db().prepare("SELECT COUNT(*) c FROM enrollments WHERE class_id=? AND status='active'").get(classId).c;
      const minimum=gate.minimum_responses!=null?Number(gate.minimum_responses):gate.minimum_response_rate!=null?Math.ceil(Number(gate.minimum_response_rate)*eligible):0;
      if(minimum>0&&received<minimum&&!body.override)return json(res,409,{ok:false,code:'gate_not_met',message:`Wait for ${minimum-received} more response${minimum-received===1?'':'s'} or choose to close anyway.`,received,required:minimum,eligible});
      db().prepare("UPDATE activity_instances SET status='closed',closed_at=CURRENT_TIMESTAMP WHERE id=? AND status='open'").run(iid); setClassState(classId,{phase:'closed'},u.id); engine.log(classId,u.id,'activity_closed','activity',state.activity_id,{instance_id:iid,gate_override:!!body.override}); return json(res,200,{ok:true,results:instanceResults(iid)});
    }
    if(action==='reveal'){
      if(!iid)return json(res,409,{ok:false,message:'There is no activity result to show.'}); const inst=db().prepare('SELECT status,definition_json FROM activity_instances WHERE id=?').get(iid); if(!inst||!['closed','revealed'].includes(inst.status))return json(res,409,{ok:false,message:'Close the activity before showing results.'}); db().prepare("UPDATE activity_instances SET status='revealed',revealed_at=COALESCE(revealed_at,CURRENT_TIMESTAMP) WHERE id=?").run(iid); const results=instanceResults(iid); const activity=safeJsonParse(inst.definition_json,{}); const next=suggestedNext(activity,results);const selectedWorkflowNext=state.payload?.workflow_node_id?updateWorkflowSelectedNext(classId,state.module_id,state.payload.workflow_node_id,next):null; setClassState(classId,{phase:'results',payload:{...state.payload,instance_id:iid,suggested_next_activity_id:next||null,selected_next_workflow_node_id:selectedWorkflowNext||null}},u.id); engine.log(classId,u.id,'results_revealed','activity',state.activity_id,{instance_id:iid,suggested_next_activity_id:next||null}); return json(res,200,{ok:true,results,suggested_next_activity_id:next||null});
    }
    if(action==='clear'){
      if(iid)db().prepare("UPDATE activity_instances SET status='completed',closed_at=COALESCE(closed_at,CURRENT_TIMESTAMP) WHERE id=?").run(iid);const finishedNode=workflowNodeFromLiveState(classId,state);if(finishedNode)completeWorkflowNode(classId,state.module_id,finishedNode.id,u.id,{selectedNextNodeId:state.payload?.selected_next_workflow_node_id||undefined}); const next=setClassState(classId,{module_id:null,activity_id:null,phase:'waiting',payload:{}},u.id); engine.log(classId,u.id,'classroom_cleared','class',classId,{}); return json(res,200,{ok:true,state:next});
    }
  }
  if(/^\/api\/live\/\d+\/workflow$/.test(p)&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAccess(u,classId,res))return;return json(res,200,{ok:true,workflow:workflowProgressForClass(classId)});
  }
  if(/^\/api\/live\/\d+\/workflow\/generic$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAccess(u,classId,res))return;const b=await readJson(req),moduleId=String(b.module_id||''),nodeId=String(b.node_id||''),mod=findModule(getCourseContentByClass(classId),moduleId),node=workflowNodeForRef(mod,{nodeId});if(!node)return json(res,404,{ok:false,message:'That workflow section is not part of this course version.'});beginWorkflowNode(classId,moduleId,node,u.id,{override:!!b.override});setActiveClass(classId);const st=setClassState(classId,{module_id:moduleId,activity_id:null,phase:'workflow',payload:{workflow_node_id:node.id,workflow_node_title:workflowNodeTitle(mod,node),workflow_node_type:node.type}},u.id);return json(res,200,{ok:true,state:st});
  }
  if(/^\/api\/live\/\d+\/workflow\/skip$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAccess(u,classId,res))return;const b=await readJson(req),moduleId=String(b.module_id||''),nodeId=String(b.node_id||''),mod=findModule(getCourseContentByClass(classId),moduleId),node=workflowNodeForRef(mod,{nodeId});if(!node)return json(res,404,{ok:false,message:'That workflow section is not part of this course version.'});const progress=workflowProgressForClass(classId),view=progress.modules.find(m=>String(m.module_id)===moduleId)?.nodes.find(n=>String(n.id)===nodeId);if(!view||!['next','current'].includes(view.status))return json(res,409,{ok:false,message:'Only the current or highlighted next section can be skipped.'});completeWorkflowNode(classId,moduleId,nodeId,u.id,{status:'skipped'});if(node.type==='practice_start')closePracticeWorkflowPaths(classId,moduleId,u.id);const st=getClassState(classId);if(st.payload?.workflow_node_id===nodeId)setClassState(classId,{module_id:null,activity_id:null,phase:'waiting',payload:{}},u.id);return json(res,200,{ok:true,workflow:workflowProgressForClass(classId)});
  }
  if(/^\/api\/live\/\d+\/connected$/.test(p)&&req.method==='GET'){
    const u=trainer(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!requireClassAccess(u,classId,res))return; const rows=db().prepare(`SELECT u.id,u.username,u.display_name,MAX(s.last_seen) last_seen FROM enrollments e JOIN users u ON u.id=e.student_id LEFT JOIN sessions s ON s.user_id=u.id WHERE e.class_id=? GROUP BY u.id ORDER BY u.display_name`).all(classId); const live=rows.filter(r=>r.last_seen&&new Date(r.last_seen+'Z').getTime()>Date.now()-95000); return json(res,200,{ok:true,total:rows.length,connected:live.length,students:rows.map(r=>({...r,connected:live.some(x=>x.id===r.id)}))});
  }
  if(/^\/api\/responses\/\d+$/.test(p)&&req.method==='POST'){
    const u=student(req,res,url); if(!u)return;
    const instanceId=Number(p.split('/').pop());
    const inst=db().prepare('SELECT * FROM activity_instances WHERE id=?').get(instanceId);
    if(!inst||inst.status!=='open')return json(res,409,{ok:false,message:'This activity is no longer accepting responses.'});
    if(!enrollment(inst.class_id,u.id))return json(res,403,{ok:false,message:'You are not enrolled in this class.'});
    const activity=safeJsonParse(inst.definition_json,{}),body=await readJson(req),answer=body.answer,score=calculateScore(activity,answer);
    if(activity.response_scope==='team'){
      const team=studentTeam(inst.class_id,u.id); if(!team)return json(res,409,{ok:false,message:'You are not assigned to a team for this activity.'});
      db().prepare(`INSERT INTO team_responses(instance_id,team_id,submitted_by,answer_json,score) VALUES(?,?,?,?,?) ON CONFLICT(instance_id,team_id) DO UPDATE SET submitted_by=excluded.submitted_by,answer_json=excluded.answer_json,score=excluded.score,updated_at=CURRENT_TIMESTAMP`).run(instanceId,team.id,u.id,JSON.stringify({value:answer}),score);
      const members=db().prepare(`SELECT student_id FROM team_members WHERE team_id=?`).all(team.id);
      for(const m of members){ markObjectives(inst.class_id,m.student_id,activity.objective_ids||[]); if(activity.achievement)awardAchievement(inst.class_id,m.student_id,activity.achievement); }
      engine.log(inst.class_id,u.id,'team_response_submitted','activity',inst.activity_id,{instance_id:instanceId,team_id:team.id});
    }else{
      db().prepare(`INSERT INTO responses(instance_id,student_id,answer_json,score) VALUES(?,?,?,?) ON CONFLICT(instance_id,student_id) DO UPDATE SET answer_json=excluded.answer_json,score=excluded.score,updated_at=CURRENT_TIMESTAMP`).run(instanceId,u.id,JSON.stringify({value:answer}),score);
      markObjectives(inst.class_id,u.id,activity.objective_ids||[]); if(activity.achievement)awardAchievement(inst.class_id,u.id,activity.achievement);
      engine.log(inst.class_id,u.id,'response_submitted','activity',inst.activity_id,{instance_id:instanceId});
    }
    refresh(inst.class_id,'response'); return json(res,200,{ok:true,score,response_scope:activity.response_scope||'individual'});
  }
  if(p==='/api/student/dashboard'){
    const u=student(req,res,url); if(!u)return; const classes=db().prepare(`SELECT cl.id,cl.title,cl.start_date,cl.end_date,cl.status,c.title course_title,cv.version,cv.id course_version_id,c.direction FROM enrollments e JOIN classes cl ON cl.id=e.class_id JOIN course_versions cv ON cv.id=cl.course_version_id JOIN courses c ON c.id=cv.course_id WHERE e.student_id=? AND e.status='active' ORDER BY cl.start_date DESC,cl.id DESC`).all(u.id); const aid=activeClassId(); const active=aid&&enrollment(aid,u.id)?publicLivePayload(aid):null; if(active){const runtime=db().prepare('SELECT * FROM participant_runtime_state WHERE class_id=? AND student_id=?').get(aid,u.id);if(runtime){active.personal_state={...runtime,progress:safeJsonParse(runtime.progress_json,{}),progress_json:undefined};if(runtime.path_id)active.personal_path=findPath(getCourseContentByClass(aid),runtime.module_id||active.state.module_id,runtime.path_id)||findMission(getCourseContentByClass(aid),runtime.module_id||active.state.module_id,runtime.path_id);}} const recent=db().prepare(`SELECT e.*,cl.title class_title FROM activity_events e LEFT JOIN classes cl ON cl.id=e.class_id WHERE e.user_id=? ORDER BY e.id DESC LIMIT 30`).all(u.id); const progress=classes.map(cl=>{const missions=db().prepare("SELECT COUNT(*) c FROM mission_progress WHERE class_id=? AND student_id=? AND status='completed'").get(cl.id,u.id).c;const responses=db().prepare('SELECT COUNT(*) c FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE ai.class_id=? AND r.student_id=?').get(cl.id,u.id).c;const score=db().prepare('SELECT COALESCE(SUM(COALESCE(r.score,0)),0) s FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE ai.class_id=? AND r.student_id=?').get(cl.id,u.id).s;const achievements=db().prepare('SELECT COUNT(*) c FROM achievements WHERE class_id=? AND student_id=?').get(cl.id,u.id).c;const objectives=db().prepare('SELECT COUNT(*) c FROM objective_progress WHERE class_id=? AND student_id=? AND achieved=1').get(cl.id,u.id).c;return {class_id:cl.id,missions,responses,score,achievements,objectives};}); return json(res,200,{ok:true,user:u,classes,active,recent,progress});
  }
  if(/^\/api\/missions\/\d+\/progress$/.test(p)&&req.method==='POST'){
    const u=student(req,res,url); if(!u)return; const classId=Number(p.split('/')[3]); if(!enrollment(classId,u.id))return json(res,403,{ok:false,message:'You are not enrolled in this class.'}); const b=await readJson(req),moduleId=String(b.module_id||''),missionId=String(b.mission_id||''); const mission=findMission(getCourseContentByClass(classId),moduleId,missionId); if(!mission)return json(res,404,{ok:false,message:'Mission not found.'}); const status=['available','in_progress','completed'].includes(b.status)?b.status:'in_progress'; const completed=status==='completed'?nowIso():null; const score=status==='completed'?Number(mission?.score?.completion||0):null; db().prepare(`INSERT INTO mission_progress(class_id,student_id,module_id,mission_id,status,progress_json,score,started_at,completed_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?) ON CONFLICT(class_id,student_id,mission_id) DO UPDATE SET status=excluded.status,progress_json=excluded.progress_json,score=excluded.score,started_at=COALESCE(mission_progress.started_at,CURRENT_TIMESTAMP),completed_at=excluded.completed_at`).run(classId,u.id,moduleId,missionId,status,JSON.stringify(b.progress||{}),score,completed); if(status==='completed'){markObjectives(classId,u.id,mission.objective_ids||[]);if(mission.achievement)awardAchievement(classId,u.id,mission.achievement);} engine.log(classId,u.id,status==='completed'?'mission_completed':'mission_updated','mission',missionId,{status}); refresh(classId,'mission'); return json(res,200,{ok:true,status,score});
  }
  if(/^\/api\/submissions\/\d+$/.test(p)&&req.method==='POST'){
    const u=student(req,res,url); if(!u)return; const classId=Number(p.split('/').pop()); if(!enrollment(classId,u.id))return json(res,403,{ok:false,message:'You are not enrolled in this class.'}); const kind=String(req.headers['x-submission-kind']||'file'); const moduleId=String(req.headers['x-module-id']||'')||null,activityId=String(req.headers['x-activity-id']||'')||null,missionId=String(req.headers['x-mission-id']||'')||null;
    if(kind==='text'||kind==='url'){const body=await readJson(req);const r=db().prepare('INSERT INTO submissions(class_id,student_id,module_id,activity_id,mission_id,kind,text_value,url_value) VALUES(?,?,?,?,?,?,?,?)').run(classId,u.id,moduleId,activityId,missionId,kind,kind==='text'?String(body.value||''):null,kind==='url'?String(body.value||''):null);engine.log(classId,u.id,'submission_added','submission',r.lastInsertRowid,{kind});refresh(classId,'submission');return json(res,201,{ok:true,id:Number(r.lastInsertRowid)});}
    const filename=decodeURIComponent(String(req.headers['x-file-name']||'upload.bin')); const safeName=path.basename(filename).replace(/[^A-Za-z0-9._\-\u0600-\u06ff ]/g,'_').slice(0,120)||'upload.bin'; const buf=await readBuffer(req,MAX_SUBMISSION); const ext=path.extname(safeName).toLowerCase(); const allowed=['.png','.jpg','.jpeg','.webp','.pdf','.txt','.csv','.doc','.docx','.ppt','.pptx','.xlsx']; if(!allowed.includes(ext))return json(res,400,{ok:false,message:'This file type is not allowed.'}); const folder=ensureDir(path.join(STORAGE_DIR,'submissions',String(classId),String(u.id))); const stored=`${Date.now()}_${crypto.randomBytes(4).toString('hex')}${ext}`; const dest=path.join(folder,stored); fs.writeFileSync(dest,buf); const r=db().prepare('INSERT INTO submissions(class_id,student_id,module_id,activity_id,mission_id,kind,stored_path,original_name,mime_type,size_bytes) VALUES(?,?,?,?,?,?,?,?,?,?)').run(classId,u.id,moduleId,activityId,missionId,kind,dest,safeName,mimeFromName(safeName),buf.length); engine.log(classId,u.id,'submission_added','submission',r.lastInsertRowid,{kind,file:safeName});refresh(classId,'submission');return json(res,201,{ok:true,id:Number(r.lastInsertRowid),name:safeName,size:buf.length});
  }
  if(/^\/api\/assets\/\d+\/.+/.test(p)&&req.method==='GET'){
    const parts=p.split('/'),versionId=Number(parts[3]),assetKey=decodeURIComponent(parts.slice(4).join('/')); const row=db().prepare('SELECT * FROM course_assets WHERE course_version_id=? AND asset_key=?').get(versionId,assetKey); if(!row||!fs.existsSync(row.stored_path))return send(res,404,'Not found'); const data=fs.readFileSync(row.stored_path); return send(res,200,data,row.mime_type,{'Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(path.basename(assetKey))}`});
  }
  if(p==='/api/reports/export'&&req.method==='GET'){
    const u=trainer(req,res,url); if(!u)return; const kind=String(url.searchParams.get('kind')||'students'),requested=Number(url.searchParams.get('class_id')||0),visible=visibleClassIds(u);
    if(requested&&visible!==null&&!visible.includes(requested))return json(res,403,{ok:false,message:'You do not have access to this class.'});
    const scopeIds=requested?[requested]:visible,idCsv=scopeIds&&scopeIds.length?scopeIds.map(Number).join(','):'',scope=(expr)=>scopeIds===null?'1=1':scopeIds.length?`${expr} IN (${idCsv})`:'1=0';
    let headers=[],rows=[];
    if(kind==='students'){
      headers=['id','username','display_name','email','class_count'];
      rows=db().prepare(`SELECT us.id,us.username,us.display_name,us.email,(SELECT COUNT(DISTINCT e2.class_id) FROM enrollments e2 WHERE e2.student_id=us.id AND e2.status<>'withdrawn' AND ${scope('e2.class_id')}) class_count FROM users us WHERE us.role='student' AND EXISTS(SELECT 1 FROM enrollments e WHERE e.student_id=us.id AND e.status<>'withdrawn' AND ${scope('e.class_id')}) ORDER BY us.display_name`).all();
    }
    else if(kind==='class_students'){
      if(!requested)return json(res,400,{ok:false,message:'Choose a class before exporting its participant roster.'});
      headers=['id','username','display_name','email','enrollment_status','response_count','mission_count','score'];rows=studentList(requested);
    }
    else if(kind==='responses'){headers=['class_title','student','username','activity','type','answer','score','submitted_at'];rows=db().prepare(`SELECT cl.title class_title,u.display_name student,u.username,ai.title activity,ai.activity_type type,r.answer_json answer,r.score,r.submitted_at FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id JOIN classes cl ON cl.id=ai.class_id JOIN users u ON u.id=r.student_id WHERE ${scope('cl.id')} ORDER BY r.id`).all().map(r=>({...r,answer:JSON.stringify(safeJsonParse(r.answer,null))}));}
    else if(kind==='activity'){headers=['class_title','user','event_type','entity_type','entity_id','created_at'];rows=db().prepare(`SELECT cl.title class_title,u.display_name user,e.event_type,e.entity_type,e.entity_id,e.created_at FROM activity_events e LEFT JOIN classes cl ON cl.id=e.class_id LEFT JOIN users u ON u.id=e.user_id WHERE e.class_id IS NOT NULL AND ${scope('e.class_id')} ORDER BY e.id`).all();}
    else if(kind==='course_summary'){
      headers=['course','slug','classes','participants','completed_classes','responses','missions','average_score'];
      const courseVisible=scopeIds===null?'1=1':`EXISTS(SELECT 1 FROM course_versions cvx JOIN classes clx ON clx.course_version_id=cvx.id WHERE cvx.course_id=c.id AND ${scope('clx.id')})`;
      rows=db().prepare(`SELECT c.title course,c.slug,
        (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id WHERE cv.course_id=c.id AND ${scope('cl.id')}) classes,
        (SELECT COUNT(DISTINCT e.student_id) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN enrollments e ON e.class_id=cl.id AND e.status='active' WHERE cv.course_id=c.id AND ${scope('cl.id')}) participants,
        (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id LEFT JOIN class_lifecycle lc ON lc.class_id=cl.id WHERE cv.course_id=c.id AND ${scope('cl.id')} AND COALESCE(lc.lifecycle_status,cl.status)='completed') completed_classes,
        (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN activity_instances ai ON ai.class_id=cl.id JOIN responses r ON r.instance_id=ai.id WHERE cv.course_id=c.id AND ${scope('cl.id')}) responses,
        (SELECT COUNT(*) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN mission_progress mp ON mp.class_id=cl.id WHERE cv.course_id=c.id AND ${scope('cl.id')} AND mp.status='completed') missions,
        ROUND(COALESCE((SELECT AVG(r.score) FROM course_versions cv JOIN classes cl ON cl.course_version_id=cv.id JOIN activity_instances ai ON ai.class_id=cl.id JOIN responses r ON r.instance_id=ai.id WHERE cv.course_id=c.id AND ${scope('cl.id')} AND r.score IS NOT NULL),0),2) average_score
        FROM courses c WHERE ${courseVisible} ORDER BY c.title`).all();
    }
    else if(kind==='class_summary'){
      headers=['class','course','version','status','participants','responses','missions','average_score','objectives_reached','achievements'];
      rows=db().prepare(`SELECT cl.title class,c.title course,cv.version,COALESCE(lc.lifecycle_status,cl.status) status,
        (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=cl.id AND e.status='active') participants,
        (SELECT COUNT(*) FROM activity_instances ai JOIN responses r ON r.instance_id=ai.id WHERE ai.class_id=cl.id) responses,
        (SELECT COUNT(*) FROM mission_progress mp WHERE mp.class_id=cl.id AND mp.status='completed') missions,
        ROUND(COALESCE((SELECT AVG(r.score) FROM activity_instances ai JOIN responses r ON r.instance_id=ai.id WHERE ai.class_id=cl.id AND r.score IS NOT NULL),0),2) average_score,
        (SELECT COUNT(DISTINCT op.objective_id) FROM objective_progress op WHERE op.class_id=cl.id AND op.achieved=1) objectives_reached,
        (SELECT COUNT(*) FROM achievements ach WHERE ach.class_id=cl.id) achievements
        FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id JOIN courses c ON c.id=cv.course_id LEFT JOIN class_lifecycle lc ON lc.class_id=cl.id WHERE ${scope('cl.id')} ORDER BY cl.start_date DESC,cl.id DESC`).all();
    }
    else if(kind==='student_summary'){
      headers=['id','username','participant','active','classes','responses','missions','score','objectives','achievements'];
      rows=db().prepare(`SELECT us.id,us.username,us.display_name participant,us.active,
        (SELECT COUNT(DISTINCT e.class_id) FROM enrollments e WHERE e.student_id=us.id AND e.status<>'withdrawn' AND ${scope('e.class_id')}) classes,
        (SELECT COUNT(*) FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE r.student_id=us.id AND ${scope('ai.class_id')}) responses,
        (SELECT COUNT(*) FROM mission_progress mp WHERE mp.student_id=us.id AND mp.status='completed' AND ${scope('mp.class_id')}) missions,
        ROUND(COALESCE((SELECT SUM(COALESCE(r.score,0)) FROM responses r JOIN activity_instances ai ON ai.id=r.instance_id WHERE r.student_id=us.id AND ${scope('ai.class_id')}),0),2) score,
        (SELECT COUNT(DISTINCT op.objective_id) FROM objective_progress op WHERE op.student_id=us.id AND op.achieved=1 AND ${scope('op.class_id')}) objectives,
        (SELECT COUNT(*) FROM achievements ach WHERE ach.student_id=us.id AND ${scope('ach.class_id')}) achievements
        FROM users us WHERE us.role='student' AND EXISTS(SELECT 1 FROM enrollments e WHERE e.student_id=us.id AND e.status<>'withdrawn' AND ${scope('e.class_id')}) ORDER BY us.display_name`).all();
    }
    else if(kind==='trainer_summary'){
      headers=['id','username','trainer','role','active','classes','participants'];
      const trainerFilter=isAdminLike(u)?'1=1':`us.id=${Number(u.id)}`;
      rows=db().prepare(`SELECT us.id,us.username,us.display_name trainer,COALESCE(sr.staff_role,'trainer') role,us.active,
        (SELECT COUNT(DISTINCT ct.class_id) FROM class_trainers ct WHERE ct.user_id=us.id AND ${scope('ct.class_id')}) classes,
        (SELECT COUNT(DISTINCT e.student_id) FROM class_trainers ct JOIN enrollments e ON e.class_id=ct.class_id AND e.status='active' WHERE ct.user_id=us.id AND ${scope('ct.class_id')}) participants
        FROM users us LEFT JOIN staff_roles sr ON sr.user_id=us.id WHERE us.role='trainer' AND ${trainerFilter} ORDER BY us.display_name`).all();
    }
    else return json(res,400,{ok:false,message:'Unknown export type.'});
    const csv=rowsToCsv(headers,rows); return send(res,200,csv,'text/csv; charset=utf-8',{'Content-Disposition':`attachment; filename="${kind}_${new Date().toISOString().slice(0,10)}.csv"`});
  }
  if(p==='/api/history'&&req.method==='GET'){
    const u=trainer(req,res,url); if(!u)return; const requested=Number(url.searchParams.get('class_id')||0),limit=Math.min(300,Math.max(10,Number(url.searchParams.get('limit')||100))),visible=visibleClassIds(u);
    if(requested&&visible!==null&&!visible.includes(requested))return json(res,403,{ok:false,message:'You do not have access to this class.'});
    const ids=requested?[requested]:visible,idCsv=ids&&ids.length?ids.map(Number).join(','):'';
    let rows=[];
    if(ids===null)rows=db().prepare(`SELECT e.*,u.display_name,cl.title class_title FROM activity_events e LEFT JOIN users u ON u.id=e.user_id LEFT JOIN classes cl ON cl.id=e.class_id ORDER BY e.id DESC LIMIT ?`).all(limit);
    else if(ids.length)rows=db().prepare(`SELECT e.*,u.display_name,cl.title class_title FROM activity_events e LEFT JOIN users u ON u.id=e.user_id LEFT JOIN classes cl ON cl.id=e.class_id WHERE e.class_id IN (${idCsv}) ORDER BY e.id DESC LIMIT ?`).all(limit);
    return json(res,200,{ok:true,events:rows.map(r=>({...r,payload:safeJsonParse(r.payload_json,{}),payload_json:undefined}))});
  }
  // ---- v2 account, operations, communications and authoring APIs ----
  if(p==='/api/profile'){
    const u=requireUser(req,res,url,['trainer','student']); if(!u)return;
    if(req.method==='GET'){
      const row=db().prepare(`SELECT us.id,us.username,us.role,us.display_name,us.email,us.preferred_language,us.active,p.profile_json FROM users us LEFT JOIN profiles p ON p.user_id=us.id WHERE us.id=?`).get(u.id);
      const consents=db().prepare('SELECT consent_key,granted,policy_version,updated_at FROM consents WHERE user_id=? ORDER BY consent_key').all(u.id);
      return json(res,200,{ok:true,profile:{...row,profile:safeJsonParse(row.profile_json,{}),profile_json:undefined,consents}});
    }
    if(req.method==='PATCH'){
      const b=await readJson(req),profile={...(u.profile||{}),...(b.profile&&typeof b.profile==='object'?b.profile:{})};
      const email=String(b.email??u.email??'').trim().slice(0,160)||null,display=String(b.display_name??u.display_name??u.username).trim().slice(0,160)||u.username;
      if(u.role==='student'&&b.complete_profile===true){const missing=[];if(!String(profile.full_name_ar||'').trim())missing.push('full_name_ar');if(!String(profile.full_name_en||'').trim())missing.push('full_name_en');if(!email)missing.push('email');if(!String(profile.mobile||'').trim())missing.push('mobile');if(missing.length)return json(res,422,{ok:false,message:'Arabic name, English name, email and mobile number are required.',missing});}
      const lang=['en','ar'].includes(String(b.preferred_language||''))?String(b.preferred_language):null;
      db().prepare('UPDATE users SET display_name=?,email=?,preferred_language=COALESCE(?,preferred_language),updated_at=CURRENT_TIMESTAMP WHERE id=?').run(display,email,lang,u.id);
      db().prepare(`INSERT INTO profiles(user_id,profile_json,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET profile_json=excluded.profile_json,updated_at=CURRENT_TIMESTAMP`).run(u.id,JSON.stringify(profile));
      if(b.consents&&typeof b.consents==='object') for(const [key,val] of Object.entries(b.consents)) db().prepare(`INSERT INTO consents(user_id,consent_key,granted,policy_version,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,consent_key) DO UPDATE SET granted=excluded.granted,policy_version=excluded.policy_version,updated_at=CURRENT_TIMESTAMP`).run(u.id,String(key),val?1:0,String(b.policy_version||'1.0'));
      engine.log(null,u.id,'profile_updated','user',u.id,{}); refresh(null,'profile'); return json(res,200,{ok:true});
    }
  }
  if(p==='/api/notifications'&&req.method==='GET'){
    const u=requireUser(req,res,url,['trainer','student']); if(!u)return;
    const classIds=u.role==='student'?db().prepare(`SELECT class_id FROM enrollments WHERE student_id=? AND status<>'withdrawn'`).all(u.id).map(r=>String(r.class_id)):(visibleClassIds(u)||classList(u).map(c=>String(c.id)));
    const courseIds=u.role==='student'?db().prepare(`SELECT DISTINCT cv.course_id id FROM enrollments e JOIN classes cl ON cl.id=e.class_id JOIN course_versions cv ON cv.id=cl.course_version_id WHERE e.student_id=? AND e.status<>'withdrawn'`).all(u.id).map(r=>String(r.id)):[];
    const classClause=classIds.length?`OR (n.scope_type='class' AND n.scope_id IN (${classIds.map(()=>'?').join(',')}))`:'';const courseClause=courseIds.length?`OR (n.scope_type='course' AND n.scope_id IN (${courseIds.map(()=>'?').join(',')}))`:'';
    const rows=db().prepare(`SELECT n.*,nr.read_at,us.display_name sender_name FROM notifications n LEFT JOIN notification_receipts nr ON nr.notification_id=n.id AND nr.user_id=? LEFT JOIN users us ON us.id=n.sender_id WHERE (n.scope_type='system' OR (n.scope_type='user' AND n.scope_id=?) ${classClause} ${courseClause}) AND (n.expires_at IS NULL OR datetime(n.expires_at)>datetime('now')) ORDER BY n.id DESC LIMIT 100`).all(u.id,String(u.id),...classIds,...courseIds);
    return json(res,200,{ok:true,notifications:rows.map(r=>({...r,link:safeJsonParse(r.link_json,{}),link_json:undefined})),unread:rows.filter(r=>!r.read_at).length});
  }
  if(p==='/api/notifications'&&req.method==='POST'){
    const u=trainer(req,res,url); if(!u)return; const b=await readJson(req),scope=String(b.scope_type||'class'),scopeId=String(b.scope_id||'');
    if(scope==='system'&&!isAdminLike(u))return json(res,403,{ok:false,message:'Administrator access is required.'});
    if(scope==='class'&&!canManageClass(u,Number(scopeId)))return json(res,403,{ok:false,message:'You do not have access to this class.'});
    if(scope==='course'&&!isAdminLike(u)&&!hasGrant(u,'course',Number(scopeId),'edit'))return json(res,403,{ok:false,message:'You do not have access to this course.'});
    if(scope==='user'&&!canAdministerStudent(u,Number(scopeId))&&!isAdminLike(u))return json(res,403,{ok:false,message:'You do not have access to this participant.'});
    if(!['user','class','course','system'].includes(scope))return json(res,400,{ok:false,message:'Choose a valid message audience.'});
    const title=String(b.title||'').trim(),body=String(b.body||'').trim();if(!title||!body)return json(res,400,{ok:false,message:'Title and message are required.'});
    const r=db().prepare(`INSERT INTO notifications(sender_id,scope_type,scope_id,title,body,priority,link_json,expires_at) VALUES(?,?,?,?,?,?,?,?)`).run(u.id,scope,scopeId||null,title,body,['low','normal','high'].includes(b.priority)?b.priority:'normal',JSON.stringify(b.link||{}),b.expires_at||null);
    engine.log(scope==='class'?Number(scopeId):null,u.id,'notification_sent','notification',r.lastInsertRowid,{scope_type:scope,scope_id:scopeId});refresh(scope==='class'?Number(scopeId):null,'notification');return json(res,201,{ok:true,id:Number(r.lastInsertRowid)});
  }
  if(/^\/api\/notifications\/\d+\/read$/.test(p)&&req.method==='POST'){
    const u=requireUser(req,res,url,['trainer','student']);if(!u)return;const id=Number(p.split('/')[3]);if(!db().prepare('SELECT id FROM notifications WHERE id=?').get(id))return json(res,404,{ok:false,message:'Message not found.'});db().prepare(`INSERT INTO notification_receipts(notification_id,user_id,read_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(notification_id,user_id) DO UPDATE SET read_at=CURRENT_TIMESTAMP`).run(id,u.id);return json(res,200,{ok:true});
  }
  if(p==='/api/dashboard/admin'&&req.method==='GET'){
    const u=superAdministrator(req,res,url);if(!u)return;
    const live=db().prepare(`SELECT cl.id,cl.title,c.title course_title,cv.version,cl.start_date,cl.start_time,cl.location,u.display_name trainer_name,cs.phase,cs.module_id,cs.activity_id,cs.updated_at,
      (SELECT COUNT(*) FROM enrollments e WHERE e.class_id=cl.id AND e.status='active') participants,
      (SELECT COUNT(DISTINCT se.user_id) FROM sessions se JOIN enrollments e ON e.student_id=se.user_id WHERE e.class_id=cl.id AND datetime(se.last_seen)>=datetime('now','-90 seconds')) connected,
      (SELECT COUNT(*) FROM participant_runtime_state prs WHERE prs.class_id=cl.id AND prs.status='working') working,
      (SELECT COUNT(*) FROM participant_runtime_state prs WHERE prs.class_id=cl.id AND prs.status='need_help') need_help,
      (SELECT COUNT(*) FROM participant_runtime_state prs WHERE prs.class_id=cl.id AND prs.status='finished') finished,
      (SELECT COUNT(*) FROM help_requests hr WHERE hr.class_id=cl.id AND hr.status<>'resolved') open_help
      FROM classes cl JOIN course_versions cv ON cv.id=cl.course_version_id JOIN courses c ON c.id=cv.course_id LEFT JOIN users u ON u.id=cl.trainer_id LEFT JOIN classroom_state cs ON cs.class_id=cl.id LEFT JOIN class_lifecycle lc ON lc.class_id=cl.id WHERE COALESCE(lc.lifecycle_status,cl.status)='active' ORDER BY cl.id DESC`).all();
    const counts={courses:db().prepare('SELECT COUNT(*) c FROM courses').get().c,classes:db().prepare('SELECT COUNT(*) c FROM classes').get().c,participants:db().prepare("SELECT COUNT(*) c FROM users WHERE role='student' AND active=1").get().c,trainers:db().prepare("SELECT COUNT(*) c FROM users WHERE role='trainer' AND active=1").get().c,live_classes:live.length};
    const recent=db().prepare(`SELECT e.*,us.display_name,cl.title class_title FROM activity_events e LEFT JOIN users us ON us.id=e.user_id LEFT JOIN classes cl ON cl.id=e.class_id ORDER BY e.id DESC LIMIT 25`).all();
    return json(res,200,{ok:true,counts,live,recent});
  }
  if(/^\/api\/admin\/live\/\d+$/.test(p)&&req.method==='GET'){
    const u=superAdministrator(req,res,url);if(!u)return;const classId=Number(p.split('/').pop()),cl=getClassRow(classId);if(!cl)return json(res,404,{ok:false,message:'Class not found.'});
    const students=db().prepare(`SELECT us.id,us.username,us.display_name,MAX(se.last_seen) last_seen,prs.path_id,prs.activity_id,prs.step_index,prs.step_total,COALESCE(prs.status,'not_started') progress_status,prs.updated_at,
      (SELECT COUNT(*) FROM help_requests hr WHERE hr.class_id=? AND hr.student_id=us.id AND hr.status<>'resolved') help_open
      FROM enrollments e JOIN users us ON us.id=e.student_id LEFT JOIN sessions se ON se.user_id=us.id LEFT JOIN participant_runtime_state prs ON prs.class_id=e.class_id AND prs.student_id=us.id WHERE e.class_id=? AND e.status='active' GROUP BY us.id ORDER BY us.display_name`).all(classId,classId).map(r=>({...r,connected:!!(r.last_seen&&new Date(r.last_seen+'Z').getTime()>Date.now()-95000)}));
    const sessions=db().prepare('SELECT * FROM class_sessions WHERE class_id=? ORDER BY session_date,id').all(classId),attendance=db().prepare(`SELECT a.* FROM attendance a JOIN class_sessions cs ON cs.id=a.class_session_id WHERE cs.class_id=?`).all(classId),help=db().prepare(`SELECT hr.*,us.display_name FROM help_requests hr JOIN users us ON us.id=hr.student_id WHERE hr.class_id=? ORDER BY CASE hr.status WHEN 'open' THEN 0 WHEN 'helping' THEN 1 ELSE 2 END,hr.requested_at`).all(classId);
    return json(res,200,{ok:true,class:cl,state:getClassState(classId),workflow:workflowProgressForClass(classId),students,sessions,attendance,help});
  }
  if(/^\/api\/staff\/\d+\/permissions$/.test(p)){
    const admin=administrator(req,res,url);if(!admin)return;const uid=Number(p.split('/')[3]);if(!db().prepare("SELECT id FROM users WHERE id=? AND role='trainer'").get(uid))return json(res,404,{ok:false,message:'Trainer not found.'});
    if(req.method==='GET')return json(res,200,{ok:true,permissions:db().prepare('SELECT * FROM permission_grants WHERE user_id=? ORDER BY resource_type,resource_id,action').all(uid)});
    if(req.method==='PUT'){const b=await readJson(req),rows=Array.isArray(b.permissions)?b.permissions:[];engine.transaction(()=>{db().prepare('DELETE FROM permission_grants WHERE user_id=?').run(uid);for(const r of rows){if(!r?.resource_type||!r?.action)continue;db().prepare('INSERT OR IGNORE INTO permission_grants(user_id,resource_type,resource_id,action,granted_by) VALUES(?,?,?,?,?)').run(uid,String(r.resource_type),String(r.resource_id??'*'),String(r.action),admin.id);}});engine.log(null,admin.id,'permissions_updated','user',uid,{count:rows.length});return json(res,200,{ok:true});}
  }
  if(p==='/api/students'&&req.method==='POST'){
    const admin=administrator(req,res,url);if(!admin)return;const b=await readJson(req),username=String(b.username||'').trim().toUpperCase(),password=String(b.password||'');const profile=b.profile&&typeof b.profile==='object'?b.profile:{};const name=String(b.display_name||profile.full_name_en||profile.full_name_ar||'').trim();
    if(!username||!name||password.length<8)return json(res,400,{ok:false,message:'Name, username and a password of at least 8 characters are required.'});if(db().prepare('SELECT id FROM users WHERE username=? COLLATE NOCASE').get(username))return json(res,409,{ok:false,message:'That username is already in use.'});
    const r=db().prepare('INSERT INTO users(username,password_hash,role,display_name,email,active) VALUES(?,?,?,?,?,1)').run(username,hashPassword(password),'student',name,b.email||profile.email||null);const id=Number(r.lastInsertRowid);db().prepare('INSERT INTO profiles(user_id,profile_json) VALUES(?,?)').run(id,JSON.stringify(profile));engine.log(null,admin.id,'participant_created','user',id,{});refresh(null,'students');return json(res,201,{ok:true,id});
  }
  if(/^\/api\/students\/\d+$/.test(p)){
    const actor=trainer(req,res,url);if(!actor)return;const sid=Number(p.split('/').pop());if(!canAdministerStudent(actor,sid)&&!isAdminLike(actor))return json(res,403,{ok:false,message:'You do not have permission to manage this participant.'});const st=db().prepare("SELECT us.*,p.profile_json FROM users us LEFT JOIN profiles p ON p.user_id=us.id WHERE us.id=? AND us.role='student'").get(sid);if(!st)return json(res,404,{ok:false,message:'Participant not found.'});
    if(req.method==='GET')return json(res,200,{ok:true,student:{...st,profile:safeJsonParse(st.profile_json,{}),profile_json:undefined}});
    if(req.method==='PATCH'){const b=await readJson(req),profile={...safeJsonParse(st.profile_json,{}),...(b.profile||{})};db().prepare('UPDATE users SET display_name=?,email=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(String(b.display_name??st.display_name).trim()||st.display_name,String(b.email??st.email??'').trim()||null,b.active===undefined?st.active:(b.active?1:0),sid);db().prepare('UPDATE profiles SET profile_json=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').run(JSON.stringify(profile),sid);engine.log(null,actor.id,'participant_updated','user',sid,{});refresh(null,'students');return json(res,200,{ok:true});}
    if(req.method==='DELETE'){db().prepare('UPDATE users SET active=0,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(sid);db().prepare('DELETE FROM sessions WHERE user_id=?').run(sid);engine.log(null,actor.id,'participant_deactivated','user',sid,{});refresh(null,'students');return json(res,200,{ok:true,archived:true});}
  }
  if(/^\/api\/live\/\d+\/progress$/.test(p)&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAccess(u,classId,res))return;
    const rows=db().prepare(`SELECT us.id student_id,us.username,us.display_name,prs.module_id,prs.path_id,prs.activity_id,prs.step_index,prs.step_total,COALESCE(prs.status,'not_started') status,prs.started_at,prs.finished_at,prs.updated_at,
      (SELECT COUNT(*) FROM submissions s WHERE s.class_id=? AND s.student_id=us.id) submissions,
      (SELECT COUNT(*) FROM help_requests h WHERE h.class_id=? AND h.student_id=us.id AND h.status<>'resolved') open_help
      FROM enrollments e JOIN users us ON us.id=e.student_id LEFT JOIN participant_runtime_state prs ON prs.class_id=e.class_id AND prs.student_id=us.id WHERE e.class_id=? AND e.status='active' ORDER BY us.display_name`).all(classId,classId,classId);
    const totals={not_started:0,working:0,need_help:0,finished:0};for(const r of rows)totals[r.status]=(totals[r.status]||0)+1;return json(res,200,{ok:true,students:rows,totals});
  }
  if(/^\/api\/live\/\d+\/help$/.test(p)&&req.method==='GET'){
    const u=trainer(req,res,url);if(!u)return;const classId=Number(p.split('/')[3]);if(!requireClassAccess(u,classId,res))return;const rows=db().prepare(`SELECT hr.*,us.display_name,us.username FROM help_requests hr JOIN users us ON us.id=hr.student_id WHERE hr.class_id=? ORDER BY CASE hr.status WHEN 'open' THEN 0 WHEN 'helping' THEN 1 ELSE 2 END,hr.requested_at`).all(classId);return json(res,200,{ok:true,requests:rows});
  }
  if(/^\/api\/help\/\d+$/.test(p)&&req.method==='PATCH'){
    const u=trainer(req,res,url);if(!u)return;const id=Number(p.split('/').pop()),hr=db().prepare('SELECT * FROM help_requests WHERE id=?').get(id);if(!hr)return json(res,404,{ok:false,message:'Help request not found.'});if(!requireClassAccess(u,hr.class_id,res))return;const b=await readJson(req),status=['open','helping','resolved'].includes(b.status)?b.status:hr.status;db().prepare(`UPDATE help_requests SET status=?,helping_at=CASE WHEN ?='helping' THEN COALESCE(helping_at,CURRENT_TIMESTAMP) ELSE helping_at END,resolved_at=CASE WHEN ?='resolved' THEN CURRENT_TIMESTAMP ELSE resolved_at END,resolved_by=CASE WHEN ?='resolved' THEN ? ELSE resolved_by END WHERE id=?`).run(status,status,status,status,u.id,id);if(status==='resolved')db().prepare(`UPDATE participant_runtime_state SET status=CASE WHEN status='need_help' THEN 'working' ELSE status END,updated_at=CURRENT_TIMESTAMP WHERE class_id=? AND student_id=?`).run(hr.class_id,hr.student_id);engine.log(hr.class_id,u.id,'help_request_updated','help_request',id,{status});refresh(hr.class_id,'help');return json(res,200,{ok:true,status});
  }
  if(/^\/api\/student\/runtime\/\d+$/.test(p)){
    const u=student(req,res,url);if(!u)return;const classId=Number(p.split('/').pop());if(!enrollment(classId,u.id))return json(res,403,{ok:false,message:'You are not enrolled in this class.'});
    if(req.method==='GET'){const st=db().prepare('SELECT * FROM participant_runtime_state WHERE class_id=? AND student_id=?').get(classId,u.id);return json(res,200,{ok:true,state:st?{...st,progress:safeJsonParse(st.progress_json,{}),progress_json:undefined}:null});}
    if(req.method==='PUT'){const b=await readJson(req),status=['not_started','working','need_help','finished'].includes(b.status)?b.status:'working';db().prepare(`INSERT INTO participant_runtime_state(class_id,student_id,module_id,path_id,activity_id,step_index,step_total,status,progress_json,started_at,finished_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,CASE WHEN ?<>'not_started' THEN CURRENT_TIMESTAMP END,CASE WHEN ?='finished' THEN CURRENT_TIMESTAMP END,CURRENT_TIMESTAMP) ON CONFLICT(class_id,student_id) DO UPDATE SET module_id=excluded.module_id,path_id=excluded.path_id,activity_id=excluded.activity_id,step_index=excluded.step_index,step_total=excluded.step_total,status=excluded.status,progress_json=excluded.progress_json,started_at=COALESCE(participant_runtime_state.started_at,excluded.started_at),finished_at=excluded.finished_at,updated_at=CURRENT_TIMESTAMP`).run(classId,u.id,b.module_id||null,b.path_id||null,b.activity_id||null,Math.max(0,Number(b.step_index||0)),Math.max(0,Number(b.step_total||0)),status,JSON.stringify(b.progress||{}),status,status);if(status==='finished'&&b.path_id){const content=getCourseContentByClass(classId),pathDef=findPath(content,b.module_id,b.path_id)||findMission(content,b.module_id,b.path_id);if(pathDef){markObjectives(classId,u.id,pathDef.objective_ids||[]);if(pathDef.achievement)awardAchievement(classId,u.id,pathDef.achievement);}}engine.log(classId,u.id,'participant_progress_updated','student',u.id,{status,path_id:b.path_id||null,step_index:Number(b.step_index||0)});refresh(classId,'participant_progress');return json(res,200,{ok:true});}
  }
  if(/^\/api\/student\/runtime\/\d+\/help$/.test(p)&&req.method==='POST'){
    const u=student(req,res,url);if(!u)return;const classId=Number(p.split('/')[4]);if(!enrollment(classId,u.id))return json(res,403,{ok:false,message:'You are not enrolled in this class.'});const b=await readJson(req),st=db().prepare('SELECT * FROM participant_runtime_state WHERE class_id=? AND student_id=?').get(classId,u.id);const existing=db().prepare("SELECT id FROM help_requests WHERE class_id=? AND student_id=? AND status<>'resolved' ORDER BY id DESC LIMIT 1").get(classId,u.id);if(existing)return json(res,200,{ok:true,id:existing.id,existing:true});const r=db().prepare(`INSERT INTO help_requests(class_id,student_id,module_id,path_id,activity_id,step_index,message) VALUES(?,?,?,?,?,?,?)`).run(classId,u.id,st?.module_id||b.module_id||null,st?.path_id||b.path_id||null,st?.activity_id||b.activity_id||null,st?.step_index??b.step_index??null,String(b.message||'').slice(0,500));db().prepare(`INSERT INTO participant_runtime_state(class_id,student_id,status,progress_json,updated_at) VALUES(?,?,'need_help','{}',CURRENT_TIMESTAMP) ON CONFLICT(class_id,student_id) DO UPDATE SET status='need_help',updated_at=CURRENT_TIMESTAMP`).run(classId,u.id);engine.log(classId,u.id,'help_requested','student',u.id,{request_id:Number(r.lastInsertRowid)});refresh(classId,'help');return json(res,201,{ok:true,id:Number(r.lastInsertRowid)});
  }
  if(/^\/api\/courses\/\d+\/drafts$/.test(p)&&req.method==='POST'){
    const u=trainer(req,res,url);if(!u)return;const courseId=Number(p.split('/')[3]);if(!isAdminLike(u)&&!hasGrant(u,'course',courseId,'edit'))return json(res,403,{ok:false,message:'You do not have permission to edit this course.'});const b=await readJson(req),sourceId=Number(b.source_version_id||0);let source=sourceId?db().prepare('SELECT * FROM course_versions WHERE id=? AND course_id=?').get(sourceId,courseId):db().prepare("SELECT * FROM course_versions WHERE course_id=? ORDER BY id DESC LIMIT 1").get(courseId);if(!source)return json(res,404,{ok:false,message:'Source course version not found.'});const requested=String(b.version||'').trim()||`${source.version}-draft-${Date.now()}`;if(db().prepare('SELECT id FROM course_versions WHERE course_id=? AND version=?').get(courseId,requested))return json(res,409,{ok:false,message:'That version already exists.'});const r=db().prepare(`INSERT INTO course_versions(course_id,version,status,content_json,source_manifest_json,checksum,is_demo,parent_version_id,schema_version,updated_at) VALUES(?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`).run(courseId,requested,'draft',source.content_json,source.source_manifest_json,source.checksum,0,source.id,'2.0');const id=Number(r.lastInsertRowid);db().prepare('INSERT INTO course_draft_snapshots(course_version_id,revision,content_json,saved_by) VALUES(?,?,?,?)').run(id,1,source.content_json,u.id);engine.log(null,u.id,'course_draft_created','course_version',id,{source_version_id:source.id});return json(res,201,{ok:true,version_id:id,version:requested});
  }
  if(/^\/api\/course-versions\/\d+\/draft$/.test(p)){
    const u=trainer(req,res,url);if(!u)return;const id=Number(p.split('/')[3]);const v=db().prepare('SELECT cv.*,c.id course_id,c.title course_title FROM course_versions cv JOIN courses c ON c.id=cv.course_id WHERE cv.id=?').get(id);if(!v)return json(res,404,{ok:false,message:'Course version not found.'});if(!isAdminLike(u)&&!hasGrant(u,'course',v.course_id,'edit'))return json(res,403,{ok:false,message:'You do not have permission to edit this course.'});if(v.status!=='draft'&&req.method!=='GET')return json(res,409,{ok:false,message:'Published course versions are immutable. Create a draft first.'});
    if(req.method==='GET')return json(res,200,{ok:true,version:{id:v.id,version:v.version,status:v.status,course_id:v.course_id,course_title:v.course_title,parent_version_id:v.parent_version_id},content:safeJsonParse(v.content_json,{})});
    if(req.method==='PUT'){const b=await readJson(req,MAX_JSON),content=b.content;const validation=parseCoursePackage(Buffer.from(JSON.stringify(content)),'course.json');if(!validation.ok)return json(res,422,{ok:false,errors:validation.errors,warnings:validation.warnings});const jsonText=JSON.stringify(validation.course),rev=Number(db().prepare('SELECT COALESCE(MAX(revision),0)+1 r FROM course_draft_snapshots WHERE course_version_id=?').get(id).r);engine.transaction(()=>{db().prepare('UPDATE course_versions SET content_json=?,checksum=?,schema_version=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(jsonText,sha256(jsonText),'2.0',id);db().prepare('INSERT INTO course_draft_snapshots(course_version_id,revision,content_json,saved_by) VALUES(?,?,?,?)').run(id,rev,jsonText,u.id);});engine.log(null,u.id,'course_draft_saved','course_version',id,{revision:rev});return json(res,200,{ok:true,revision:rev,warnings:validation.warnings});}
  }
  if(/^\/api\/course-versions\/\d+\/publish$/.test(p)&&req.method==='POST'){
    const u=administrator(req,res,url);if(!u)return;const id=Number(p.split('/')[3]),v=db().prepare('SELECT * FROM course_versions WHERE id=?').get(id);if(!v)return json(res,404,{ok:false,message:'Course version not found.'});if(v.status!=='draft')return json(res,409,{ok:false,message:'Only a draft can be published.'});const validation=parseCoursePackage(Buffer.from(v.content_json),'course.json');if(!validation.ok)return json(res,422,{ok:false,errors:validation.errors,warnings:validation.warnings});db().prepare("UPDATE course_versions SET status='published',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(id);engine.log(null,u.id,'course_version_published','course_version',id,{version:v.version});refresh(null,'courses');return json(res,200,{ok:true,warnings:validation.warnings});
  }
  if(/^\/api\/live\/\d+\/navigate$/.test(p)&&req.method==='POST'){
    let u=currentUser(req,url);const controlKey=String(url.searchParams.get('control_key')||req.headers['x-projector-control-key']||'');const projectorAuthorized=!u&&controlKey&&controlKey===String(engine.getSetting('projector_control_key',''));if(!u&&!projectorAuthorized)return json(res,401,{ok:false,message:'Trainer control is required.'});const classId=Number(p.split('/')[3]);if(u&&!canManageClass(u,classId))return json(res,403,{ok:false,message:'You do not have access to this class.'});const b=await readJson(req),state=getClassState(classId),content=getCourseContentByClass(classId),modules=content?.course?.modules||[];let mi=Math.max(0,modules.findIndex(m=>String(m.id)===String(state.module_id))),module=modules[mi]||modules[0];if(!module)return json(res,409,{ok:false,message:'This course has no presentation content.'});let items=(module.activities||[]).filter(a=>['presentation','announcement','reveal'].includes(a.type));if(!items.length)items=module.activities||[];let ai=Math.max(0,items.findIndex(a=>String(a.id)===String(state.activity_id)));if(b.activity_id){const idx=items.findIndex(a=>String(a.id)===String(b.activity_id));if(idx>=0)ai=idx}else if(b.direction==='previous')ai=Math.max(0,ai-1);else ai=Math.min(items.length-1,ai+1);const item=items[ai];setClassState(classId,{module_id:module.id,activity_id:item.id,phase:['presentation','announcement','reveal'].includes(item.type)?item.type:'presentation',payload:{slide_index:ai,slide_total:items.length}},u?.id||null);engine.log(classId,u?.id||null,'projector_navigated','activity',item.id,{slide_index:ai});return json(res,200,{ok:true,item_id:item.id,index:ai,total:items.length});
  }
  if(p==='/api/system/demo/remove'&&req.method==='POST'){
    const u=administrator(req,res,url); if(!u)return; engine.removeDemo(); engine.log(null,u.id,'demo_removed','system',null,{}); refresh(null,'demo'); return json(res,200,{ok:true});
  }
  if(p==='/api/system/demo/reset'&&req.method==='POST'){
    const u=administrator(req,res,url); if(!u)return; engine.removeDemo(); engine.seedDemo(); engine.log(null,u.id,'demo_reset','system',null,{}); refresh(null,'demo'); return json(res,200,{ok:true});
  }
  if(p==='/api/system/backups'&&req.method==='GET'){
    const u=administrator(req,res,url); if(!u)return; const items=fs.readdirSync(BACKUP_DIR,{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>{const manPath=path.join(BACKUP_DIR,x.name,'manifest.json');const man=fs.existsSync(manPath)?safeJsonParse(fs.readFileSync(manPath,'utf8'),{}):{};return {name:x.name,...man};}).sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||'')));return json(res,200,{ok:true,backups:items});
  }
  if(p==='/api/system/backups/create'&&req.method==='POST'){
    const u=administrator(req,res,url); if(!u)return; const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z'); const name=`backup_${stamp}`,dir=ensureDir(path.join(BACKUP_DIR,name)); engine.checkpoint(); const backupDb=path.join(dir,'training-engine.sqlite'); const escaped=backupDb.replace(/'/g,"''"); db().exec(`VACUUM INTO '${escaped}'`); copyDir(STORAGE_DIR,path.join(dir,'storage')); const manifest={created_at:nowIso(),name,app_version:'2.1.0'}; fs.writeFileSync(path.join(dir,'manifest.json'),JSON.stringify(manifest,null,2)); engine.log(null,u.id,'backup_created','system',name,{}); return json(res,201,{ok:true,backup:manifest});
  }
  if(p==='/api/system/backups/restore'&&req.method==='POST'){
    const u=administrator(req,res,url); if(!u)return; const b=await readJson(req),name=safeRelativePath(String(b.name||'')); if(!name||name.includes('/'))return json(res,400,{ok:false,message:'Invalid backup name.'}); const dir=path.join(BACKUP_DIR,name),sourceDb=path.join(dir,'training-engine.sqlite'); if(!fs.existsSync(sourceDb))return json(res,404,{ok:false,message:'Backup not found.'}); engine.close(); try{fs.rmSync(DB_PATH+'-wal',{force:true});fs.rmSync(DB_PATH+'-shm',{force:true});fs.copyFileSync(sourceDb,DB_PATH);removeDirContents(STORAGE_DIR);copyDir(path.join(dir,'storage'),STORAGE_DIR);engine=new EngineDb(DB_PATH);db().prepare('DELETE FROM sessions').run();refresh(null,'restore');return json(res,200,{ok:true,message:'Backup restored. Please sign in again.'});}catch(e){engine=new EngineDb(DB_PATH);return json(res,500,{ok:false,message:'Restore failed.'});}
  }
  return false;
}

function staticPathFor(urlPath){
  if(urlPath==='/'||urlPath==='/trainer')return path.join(PUBLIC,'trainer.html');
  if(urlPath==='/admin')return path.join(PUBLIC,'admin.html');
  if(urlPath==='/builder')return path.join(PUBLIC,'builder.html');
  if(urlPath==='/student')return path.join(PUBLIC,'student.html');
  if(urlPath==='/present')return path.join(PUBLIC,'present.html');
  if(urlPath==='/preview')return path.join(PUBLIC,'preview.html');
  const rel=safeRelativePath(urlPath.replace(/^\//,'')); if(!rel)return null; const f=path.join(PUBLIC,rel); return f.startsWith(PUBLIC)?f:null;
}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  try{
    if(url.pathname.startsWith('/api/')){const handled=await handleApi(req,res,url);if(handled===false)return json(res,404,{ok:false,message:'Not found.'});return;}
    const f=staticPathFor(url.pathname); if(f&&fs.existsSync(f)&&fs.statSync(f).isFile()){const data=fs.readFileSync(f);return send(res,200,data,mimeFromName(f),{'Cache-Control':'no-cache'});} return send(res,404,'Not found');
  }catch(e){const status=e.status||500;console.error(e);return json(res,status,{ok:false,message:status===500?'Something went wrong. Please try again.':String(e.message||'Request failed.')});}
});
server.on('error',e=>{if(e?.code==='EADDRINUSE'){console.error(`Port ${PORT} is already in use. Stop the other Training Engine/server or set a different PORT.`);process.exit(1)}console.error('Training Engine server error:',e);process.exit(1)});
server.listen(PORT,HOST,()=>{
  const ip=preferredLanAddress();
  console.log('');
  console.log('Training Engine is ready');
  console.log(`Trainer:   http://localhost:${PORT}/trainer`);
  console.log(`Projector: http://localhost:${PORT}/present`);
  console.log(`Student:   http://${ip}:${PORT}/student`);
  console.log(`Mobile trainer: http://${ip}:${PORT}/trainer`);
  console.log('');
});
