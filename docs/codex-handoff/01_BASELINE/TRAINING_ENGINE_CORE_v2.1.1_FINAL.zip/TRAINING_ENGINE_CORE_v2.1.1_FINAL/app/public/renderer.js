import {esc,md,t} from '/core.js';

const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
export function assetUrl(versionId,ref=''){
  let r=String(ref||'').trim();
  if(r.startsWith('asset://'))r=r.slice(8);
  r=r.replace(/^\/+/, '');
  return versionId&&r?`/api/assets/${Number(versionId)}/${r.split('/').map(encodeURIComponent).join('/')}`:'';
}
function safeExternal(url=''){try{const u=new URL(String(url));return ['http:','https:'].includes(u.protocol)?u.href:''}catch{return ''}}
function blockText(block){return block.body_md||block.text_md||block.body||block.text||''}
function heading(block){return block.heading||block.title||''}
function imageHtml(block,ctx,cls='content-image'){
  const src=block.asset?assetUrl(ctx.versionId,block.asset):safeExternal(block.src||'');
  if(!src)return '';
  return `<figure class="${cls}"><img src="${esc(src)}" alt="${esc(block.alt||block.caption||'')}" loading="lazy" style="object-fit:${esc(['cover','contain'].includes(block.fit)?block.fit:'cover')}">${block.caption?`<figcaption>${esc(block.caption)}</figcaption>`:''}</figure>`;
}
function chartData(block){return Array.isArray(block.data)?block.data:[]}
function chartColors(){return ['var(--series-1)','var(--series-2)','var(--series-3)','var(--series-4)','var(--series-5)','var(--series-6)']}
export function renderStaticChart(block){
  const type=String(block.chart_type||'bar'),data=chartData(block),labelKey=block.label_key||'label',valueKey=block.value_key||'value';
  if(!data.length)return `<div class="empty">${esc(t('No chart data.'))}</div>`;
  const vals=data.map(x=>Number(x?.[valueKey])||0),max=Math.max(1,...vals),sum=vals.reduce((a,b)=>a+b,0)||1;
  if(type==='donut'||type==='pie'){
    let at=0;const seg=data.map((x,i)=>{const pct=(Number(x?.[valueKey])||0)/sum*100;const from=at;at+=pct;return `${chartColors()[i%6]} ${from}% ${at}%`}).join(',');
    return `<div class="viz-donut-wrap"><div class="viz-donut ${type==='pie'?'pie':''}" style="background:conic-gradient(${seg})" role="img" aria-label="${esc(block.title||t('Chart'))}"></div><div class="viz-legend">${data.map((x,i)=>`<div><span class="viz-dot s${i%6}"></span><span>${esc(x?.[labelKey]??'')}</span><strong>${esc(x?.[valueKey]??0)}</strong></div>`).join('')}</div></div>`;
  }
  if(type==='line'){
    const w=720,h=280,p=28;const points=data.map((x,i)=>{const xx=data.length===1?w/2:p+(w-2*p)*i/(data.length-1);const yy=h-p-(h-2*p)*(Number(x?.[valueKey])||0)/max;return [xx,yy]}),poly=points.map(p=>p.join(',')).join(' ');
    return `<div class="viz-line"><svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(block.title||t('Chart'))}"><line x1="${p}" y1="${h-p}" x2="${w-p}" y2="${h-p}" class="axis"/><polyline points="${poly}" class="line-path"/>${points.map((pt,i)=>`<circle cx="${pt[0]}" cy="${pt[1]}" r="5" class="line-point"><title>${esc(data[i]?.[labelKey]??'')}: ${esc(data[i]?.[valueKey]??0)}</title></circle>`).join('')}</svg><div class="viz-axis-labels">${data.map(x=>`<span>${esc(x?.[labelKey]??'')}</span>`).join('')}</div></div>`;
  }
  if(type==='progress'){
    const row=data[0]||{},v=clamp(Number(row?.[valueKey])||0,0,Number(block.max||100));const maxv=Number(block.max||100)||100;return `<div class="viz-progress"><div class="viz-progress-value">${esc(row?.[valueKey]??0)}${block.suffix?esc(block.suffix):''}</div><div class="progress large"><span style="width:${clamp(v/maxv*100,0,100)}%"></span></div><div class="small muted">${esc(row?.[labelKey]||block.label||'')}</div></div>`;
  }
  if(type==='ranking'){
    return `<div class="viz-ranking">${[...data].sort((a,b)=>(Number(b?.[valueKey])||0)-(Number(a?.[valueKey])||0)).map((x,i)=>`<div class="rank-row"><span class="rank-num">${i+1}</span><span>${esc(x?.[labelKey]??'')}</span><strong>${esc(x?.[valueKey]??0)}</strong></div>`).join('')}</div>`;
  }
  if(type==='stacked_bar' && data.some(x=>Array.isArray(x?.segments))){
    return `<div class="viz-stacked">${data.map(row=>{const segs=(row.segments||[]).map(x=>({...x,value:Number(x?.value)||0})),total=segs.reduce((a,b)=>a+b.value,0)||1;return `<div class="viz-stacked-row"><div class="viz-bar-label">${esc(row?.[labelKey]??'')}</div><div class="viz-stack-track">${segs.map((seg,i)=>`<span class="s${i%6}" style="width:${clamp(seg.value/total*100,0,100)}%" title="${esc(seg.label||'')}: ${esc(seg.value)}"></span>`).join('')}</div><strong>${esc(segs.reduce((a,b)=>a+b.value,0))}</strong></div>`}).join('')}</div>`;
  }
  const horizontal=type==='horizontal_bar'||type==='bar';
  return `<div class="viz-bars">${data.map((x,i)=>{const v=Number(x?.[valueKey])||0,pct=clamp(v/max*100,0,100);return `<div class="viz-bar-row"><div class="viz-bar-label">${esc(x?.[labelKey]??'')}</div><div class="viz-bar-track"><div class="viz-bar-fill s${i%6}" style="width:${pct}%"></div></div><strong>${esc(x?.[valueKey]??0)}</strong></div>`}).join('')}</div>`;
}
export function renderBlock(block={},ctx={}){
  const type=String(block.type||'text');
  if(type==='hero')return `<section class="content-hero ${block.align==='center'?'center':''}">${block.eyebrow?`<div class="eyebrow">${esc(block.eyebrow)}</div>`:''}${heading(block)?`<h1>${esc(heading(block))}</h1>`:''}${blockText(block)?`<div class="rich">${md(blockText(block))}</div>`:''}${block.asset||block.src?imageHtml(block,ctx,'hero-media'):''}</section>`;
  if(type==='text')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="rich">${md(blockText(block))}</div></section>`;
  if(type==='image')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}${imageHtml(block,ctx)}</section>`;
  if(type==='image_text')return `<section class="content-split ${block.image_side==='right'?'reverse':''}">${imageHtml(block,ctx)}<div>${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="rich">${md(blockText(block))}</div></div></section>`;
  if(type==='cards')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="content-cards">${(block.items||[]).map(x=>`<article>${x.icon?`<div class="card-icon">${esc(x.icon)}</div>`:''}<h3>${esc(x.title||'')}</h3>${x.body_md?`<div class="rich small">${md(x.body_md)}</div>`:''}</article>`).join('')}</div></section>`;
  if(type==='steps')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="content-steps">${(block.items||[]).map((x,i)=>`<div class="content-step"><span>${i+1}</span><div><h3>${esc(x.title||'')}</h3>${x.body_md?`<div class="rich small">${md(x.body_md)}</div>`:''}</div></div>`).join('')}</div></section>`;
  if(type==='comparison')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="comparison">${(block.columns||[]).map(x=>`<article><div class="eyebrow">${esc(x.label||'')}</div><h3>${esc(x.title||'')}</h3>${x.body_md?`<div class="rich">${md(x.body_md)}</div>`:''}</article>`).join('')}</div></section>`;
  if(type==='table')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="table-wrap"><table class="table content-table"><thead><tr>${(block.columns||[]).map(c=>`<th>${esc(typeof c==='string'?c:c.label||c.key||'')}</th>`).join('')}</tr></thead><tbody>${(block.rows||[]).map(row=>`<tr>${(block.columns||[]).map(c=>{const k=typeof c==='string'?c:c.key;return `<td>${esc(Array.isArray(row)?row[(block.columns||[]).indexOf(c)]:row?.[k]??'')}</td>`}).join('')}</tr>`).join('')}</tbody></table></div></section>`;
  if(type==='callout')return `<aside class="content-callout ${esc(block.tone||'info')}">${block.icon?`<span class="callout-icon">${esc(block.icon)}</span>`:''}<div>${heading(block)?`<h3>${esc(heading(block))}</h3>`:''}<div class="rich">${md(blockText(block))}</div></div></aside>`;
  if(type==='statistic')return `<section class="content-stat"><div class="content-stat-value">${esc(block.value??'')}</div><div><strong>${esc(block.label||'')}</strong>${block.body_md?`<div class="small muted">${md(block.body_md)}</div>`:''}</div></section>`;
  if(type==='quote')return `<blockquote class="content-quote">${esc(block.quote||block.text||'')}${block.by?`<footer>— ${esc(block.by)}</footer>`:''}</blockquote>`;
  if(type==='checklist')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<ul class="content-checklist">${(block.items||[]).map(x=>`<li><span>✓</span><div>${typeof x==='string'?esc(x):`<strong>${esc(x.title||'')}</strong>${x.body_md?`<div class="small muted">${md(x.body_md)}</div>`:''}`}</div></li>`).join('')}</ul></section>`;
  if(type==='asset'){
    const href=block.asset?assetUrl(ctx.versionId,block.asset):safeExternal(block.src||'');return `<section class="content-block"><a class="asset-card" href="${esc(href)}" ${block.src?'target="_blank" rel="noopener"':''}><span class="asset-icon">↧</span><span><strong>${esc(block.label||block.title||t('Open resource'))}</strong>${block.description?`<small>${esc(block.description)}</small>`:''}</span></a></section>`;
  }
  if(type==='gallery')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="content-gallery">${(block.items||[]).map(x=>imageHtml(x,ctx,'content-gallery-item')).join('')}</div></section>`;
  if(type==='prompt'||type==='editable_prompt'){const text=String(block.prompt||block.template||blockText(block)||'');const editable=type==='editable_prompt'&&ctx.interactive!==false;return `<section class="content-block prompt-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}${editable?`<textarea class="textarea prompt-editor" data-prompt-editor>${esc(text)}</textarea>`:`<pre class="prompt-preview"><code>${esc(text)}</code></pre>`}${ctx.interactive!==false?`<button class="btn" type="button" data-copy-prompt>${esc(t('Copy Prompt'))}</button>`:''}</section>`;}
  if(type==='resource_list')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<div class="resource-list">${(block.items||[]).map(x=>{const href=x.asset?assetUrl(ctx.versionId,x.asset):safeExternal(x.url||x.src||'');return `<a class="asset-card" href="${esc(href)}" ${x.url||x.src?'target="_blank" rel="noopener"':''}><span class="asset-icon">↗</span><span><strong>${esc(x.title||x.label||t('Open resource'))}</strong>${x.description?`<small>${esc(x.description)}</small>`:''}</span></a>`}).join('')}</div></section>`;
  if(type==='chart')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}${renderStaticChart(block)}</section>`;
  if(type==='video'||type==='audio'){
    const src=block.asset?assetUrl(ctx.versionId,block.asset):safeExternal(block.src||'');if(!src)return '';
    if(type==='audio')return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<audio controls preload="metadata" src="${esc(src)}"></audio></section>`;
    return `<section class="content-block">${heading(block)?`<h2>${esc(heading(block))}</h2>`:''}<video class="content-video" controls preload="metadata" src="${esc(src)}"></video></section>`;
  }
  if(type==='divider')return `<hr class="content-divider">`;
  if(type==='spacer')return `<div class="content-spacer" style="height:${clamp(block.size||24,8,80)}px"></div>`;
  return '';
}
export function renderContent(content={},ctx={}){
  const blocks=Array.isArray(content.blocks)?content.blocks:[];
  if(blocks.length)return `<div class="content-stack">${blocks.map(b=>renderBlock(b,ctx)).join('')}</div>`;
  if(ctx.surface==='projector'){
    const isQuestion=Boolean(content.question),title=content.heading||content.question||content.title||'';
    const options=Array.isArray(content.options)?content.options:[];
    return `<section class="projector-default-scene ${isQuestion?'question-scene':''}">${content.hero_word?`<div class="projector-kicker">${esc(content.hero_word)}</div>`:''}${title?`<h1>${esc(title)}</h1>`:''}${content.body_md?`<div class="projector-lead rich">${md(content.body_md)}</div>`:''}${options.length?`<div class="projector-options">${options.map((x,i)=>`<div class="projector-option"><span>${i+1}</span><strong>${esc(typeof x==='string'?x:x?.label||x?.title||'')}</strong></div>`).join('')}</div>`:''}</section>`;
  }
  let out='';if(content.heading)out+=`<h1>${esc(content.heading)}</h1>`;if(content.question)out+=`<h2>${esc(content.question)}</h2>`;if(content.body_md)out+=`<div class="rich">${md(content.body_md)}</div>`;return out;
}
export function renderLiveResults(results,display='horizontal_bar',opts={}){
  const s=results?.summary||{};
  if(s.counts){const data=Object.entries(s.counts).map(([label,value])=>({label,value}));return renderStaticChart({type:'chart',chart_type:display==='cards'?'ranking':display,data,label_key:'label',value_key:'value',title:opts.title||''});}
  if(s.average!=null){return `<div class="result-average"><div>${Number(s.average).toFixed(1)}</div><span>${esc(t('Class average'))}</span><small>${esc(t('{n} responses',{n:s.total||0}))}</small></div>`;}
  if(Array.isArray(s.answers))return `<div class="answer-wall">${s.answers.slice(0,24).map(a=>`<article><p>${esc(a.text)}</p>${opts.showNames?`<small>${esc(a.name||'')}</small>`:''}</article>`).join('')}</div>`;
  if(Array.isArray(s.numeric_values)){return renderStaticChart({type:'chart',chart_type:display==='line'?'line':'bar',data:s.numeric_values.map((v,i)=>({label:String(i+1),value:v})),label_key:'label',value_key:'value'});}
  return `<div class="empty">${esc(t('{n} responses',{n:s.total||0}))}</div>`;
}
