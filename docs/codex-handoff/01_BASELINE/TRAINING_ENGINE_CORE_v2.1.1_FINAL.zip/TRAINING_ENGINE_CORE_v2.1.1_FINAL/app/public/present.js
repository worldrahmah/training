import {api,applyTypography,cycleLocale,cycleTheme,esc,eventSource,initLocale,initTheme,langButton,t,themeIcon} from '/core.js';
import {renderContent,renderLiveResults} from '/renderer.js';
initTheme();initLocale();
const app=document.querySelector('#app');
const params=new URLSearchParams(location.search);const controlKey=params.get('control_key')||'';
let live=null,brand='Training Studio',settings={};let timerId=null;
const mergeTypography=(base={},override={})=>{const out=structuredClone(base||{});for(const k of ['ui','presentation','title','body'])out[k]={...(out[k]||{}),...(override?.[k]||{})};return out};
async function refresh(){const [d,s]=await Promise.all([api('/api/live'),api('/api/public-settings')]);live=d.live;settings=s||{};brand=s?.brand?.name||'Training Studio';const typo=mergeTypography(s?.typography||{},live?.course?.branding?.typography||{});applyTypography(typo,'presentation');render()}
function render(){
  clearInterval(timerId);timerId=null;document.title=`${t('Training Studio')} — ${t('Projector')}`;
  if(!live){app.innerHTML=`<div class="projector"><div class="projector-top"><div class="brand"><span class="brand-mark">T</span><span>${esc(brand==='Training Studio'?t('Training Studio'):brand)}</span></div><div class="topbar-actions"><button class="btn" id="langBtn" aria-label="${esc(t('Change language'))}">${esc(langButton())}</button><button class="btn icon" id="themeBtn" aria-label="${esc(t('Change appearance'))}">${themeIcon()}</button></div></div><div class="projector-stage"><div class="projector-card projector-idle"><h1>${esc(t('Ready when you are'))}</h1><p>${esc(t('Start a class from the trainer workspace to begin.'))}</p></div></div></div>`;bind();return}
  const cl=live.class,item=live.item,state=live.state,dir=live.course?.direction||'ltr';const slide=Number(state?.payload?.slide_index??0)+1,total=Number(state?.payload?.slide_total||0);
  app.innerHTML=`<div class="projector is-live"><div class="projector-stage"><main class="projector-safe-frame" dir="${dir}"><div class="projector-card">${renderStage(item,state,live)}</div></main></div>${controlKey?`<nav class="projector-controls" aria-label="${esc(t('Presentation controls'))}"><button class="btn" id="prevSlide" type="button" aria-label="${esc(t('Previous'))}">← <span>${esc(t('Previous'))}</span></button>${total?`<span class="projector-counter">${slide} / ${total}</span>`:''}<button class="btn primary" id="nextSlide" type="button" aria-label="${esc(t('Next'))}"><span>${esc(t('Next'))}</span> →</button></nav>`:''}</div>`;bind();
}
function renderStage(item,state,live){
  if(state.phase==='waiting'||!item)return `<div class="projector-message"><div class="eyebrow">${esc(live.course?.title||live.class.course_title)}</div><h1>${esc(live.class.title)}</h1><p>${esc(t('The next activity will appear here when it begins.'))}</p></div>`;
  if(state.phase==='practice')return `<div class="projector-message"><div class="eyebrow">${esc(t('Practice time'))}</div><h1>${esc(item.title||t('Personal practice'))}</h1><p>${esc(item.goal||t('Continue on your device and follow the mission steps.'))}</p><div class="projector-status">${esc(t('Participants can work independently on their selected paths.'))}</div></div>`;
  let h=`<div class="projector-content">${renderContent(item.content||{heading:item.title},{versionId:live.class.course_version_id,interactive:false,surface:'projector'})}</div>`;
  if(state.phase==='results'&&live.results)h+=`<div class="projector-results">${renderLiveResults(live.results,item.results_display||item?.results?.display||'horizontal_bar',{showNames:item?.results?.show_names===true})}</div>`;
  else if(state.phase==='closed')h+=`<div class="projector-status">${esc(t('Responses are closed.'))}</div>`;
  else if(!['presentation','announcement','reveal','timer'].includes(item.type))h+=`<div class="projector-status">${esc(item.content?.prompt_on_projector||t('Respond on your device.'))}</div>`;
  if(item.type==='timer')h+=renderTimer(item.content||{},live.instance);return h;
}
function renderTimer(c,inst){const seconds=Number(c.seconds||60);let remain=seconds;if(inst?.opened_at){const start=new Date(inst.opened_at.endsWith?.('Z')?inst.opened_at:inst.opened_at+'Z').getTime();remain=Math.max(0,seconds-Math.floor((Date.now()-start)/1000));}return `<div class="projector-timer" data-timer="${remain}">${format(remain)}</div>`}
function format(s){s=Math.max(0,Number(s)||0);return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(Math.floor(s%60)).padStart(2,'0')}`}
async function navigate(direction){if(!controlKey||!live?.class?.id)return;try{await api(`/api/live/${live.class.id}/navigate?control_key=${encodeURIComponent(controlKey)}`,{method:'POST',json:{direction}});await refresh()}catch(e){console.warn(e)}}
function bind(){document.querySelector('#themeBtn')?.addEventListener('click',()=>{cycleTheme();render()});document.querySelector('#langBtn')?.addEventListener('click',()=>{cycleLocale();refresh()});document.querySelector('#prevSlide')?.addEventListener('click',()=>navigate('previous'));document.querySelector('#nextSlide')?.addEventListener('click',()=>navigate('next'));const timer=document.querySelector('[data-timer]');if(timer){let s=Number(timer.dataset.timer);timerId=setInterval(()=>{s=Math.max(0,s-1);timer.textContent=format(s);if(s<=0){clearInterval(timerId);timerId=null}},1000)}}
window.addEventListener('keydown',e=>{if(!controlKey||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;if(['ArrowRight','PageDown',' ','Enter'].includes(e.key)){e.preventDefault();navigate('next')}else if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();navigate('previous')}});
eventSource(()=>refresh());setInterval(refresh,15000);refresh();
