# Training Engine ONE v3.2.0 RC3 — Platform Capabilities Available to Course Designers

The machine-readable `CORE_CAPABILITIES.json` is authority. This file explains the most important runtime facilities a course-authoring chat may design around without changing Core.

## Delivery surfaces
- private Trainer management workspace;
- dedicated class-bound Trainer Live Classroom;
- Participant learning workspace;
- presentation-only Projector;
- visual Course Builder;
- Super Admin operations surface.

## Live-class facilities
Course designs may rely on hierarchical Course Flow, persisted workflow states, class/participant branching, Help Queue, participant progress, private trainer presenter notes, classroom health, class timing, short join codes, multiple simultaneous classes, class-scoped Projector pairing and Projector special screens (welcome/focus/break/countdown/celebration/blackout/course).

## Learning lifecycle
The platform can support schedules/calendar, submissions and trainer review, attendance, participant paths, achievements, surveys/evaluations, question banks/randomized quizzes, prerequisites, capacity waitlists, transcript and verifiable printable certificates. These are platform facilities; do not encode database IDs into course packages.

## Authoring facilities
Drafts are mutable and published versions immutable. Builder/runtime support autosave, Undo/Redo, revisions, compare/restore, reusable templates, searchable assets with exact used-by paths, workflow validation and workflow simulation.

## Analytics
ONE can report course/version/class/trainer/participant performance, time-on-step, abandonment, help wait, path funnels, course-health signals, version-to-version impact and generated course-improvement findings. Design stable activity/objective IDs so analytics remain meaningful across versions.

## Local-first constraint
Mandatory classroom delivery must remain workable on the local network. Internet resources may enrich a course but should have a truthful fallback when they are required for a milestone.
