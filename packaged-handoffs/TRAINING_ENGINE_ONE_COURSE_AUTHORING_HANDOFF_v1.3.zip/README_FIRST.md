# Training Engine ONE v3.3.0 RC4 — External Course Authoring Handoff

This package is the authoritative starting point for creating a Training Engine ONE course in a separate ChatGPT conversation.

## Authority order
1. `CORE_CAPABILITIES.json` — exact machine-readable capabilities of the ONE runtime.
2. `WORKFLOW_AND_AUTHORING_RULES.md` — hard authoring/runtime rules.
3. `COMPONENT_CATALOG_ONE.md` — human-readable course component catalog generated to match ONE.
4. `ONE_PLATFORM_CAPABILITIES.md` — role/runtime features that course designers may rely on.
5. `schemas/*` and `templates/*` — reusable structures inherited from the compatible schema-2 authoring model.
6. `examples/*` — reference only; do not copy defects or assume an example overrides the capability contract.
7. `CHATGPT_MASTER_COURSE_AUTHORING_PROMPT.md` — prompt for a new course-authoring chat.

If an older v2.0/v2.1 document conflicts with ONE capability/runtime rules, ONE wins.

## Recommended workflow
Build a course **one milestone/module at a time**:
1. Course architecture and learning outcomes.
2. Milestone 1 design.
3. Milestone 1 package mapping.
4. Validation and independent review.
5. Classroom rehearsal.
6. Continue to Milestone 2 only after Milestone 1 is accepted.

Do not modify Core source merely to make one course work. If a genuinely necessary interaction is absent from `CORE_CAPABILITIES.json`, treat it as a Core-extension request rather than inventing unsupported JSON.

## Required final output for each authored course
A course-authoring chat should return:
- import-ready `.course.zip` or equivalent course JSON/package;
- exact package SHA-256;
- validation report;
- workflow simulation report where explicit workflow exists;
- coverage list of objectives/activities/paths/assets;
- known limitations, if any;
- no custom executable JavaScript/CSS/SQL/server code.
