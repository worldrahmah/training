# Training Engine ONE — Component Catalog

The authoritative machine-readable list is `CORE_CAPABILITIES.json`. This document is the human-readable map.

## Activity types

### Presentation / facilitation
- `presentation`
- `announcement`
- `timer`
- `reveal`
- `anonymous_spotlight`
- `leaderboard`

### Responses / assessment
- `poll`
- `single_choice`
- `multiple_choice`
- `true_false`
- `short_answer`
- `long_answer`
- `numeric_answer`
- `rating`
- `reaction`
- `confidence`
- `ranking`
- `checklist`
- `reflection`
- `self_assessment`

### Submission / practice
- `url_submission`
- `file_submission`
- `image_submission`
- `mission`
- `practice_gate`

### Group / branching
- `team_challenge`
- `participant_choice`

## Presentation content blocks
- `hero`
- `text`
- `image`
- `image_text`
- `cards`
- `steps`
- `comparison`
- `table`
- `timeline`
- `callout`
- `statistic`
- `quote`
- `checklist`
- `asset`
- `chart`
- `video`
- `audio`
- `divider`
- `spacer`
- `gallery`
- `prompt`
- `editable_prompt`
- `resource_list`
- `leaderboard`

## Result displays
- `bar`
- `horizontal_bar`
- `stacked_bar`
- `donut`
- `pie`
- `line`
- `ranking`
- `progress`
- `leaderboard`
- `cards`

## Static chart types
- `bar`
- `horizontal_bar`
- `stacked_bar`
- `donut`
- `pie`
- `line`
- `ranking`
- `progress`

## Workflow node types
- `trainer_scene`
- `class_interaction`
- `trainer_walkthrough`
- `practice_start`
- `participant_choice`
- `participant_path`
- `convergence`
- `closing`
- `activity`
- `mission`

## Submission types
- `none`
- `text`
- `url`
- `file`
- `image`

## Participant-step completion types
- `acknowledge`
- `text`
- `url`
- `file`
- `image`
- `checklist`
- `external`
- `none`

## Attendance states (class operations)
- `present`
- `late`
- `absent`
- `excused`
- `left_early`

## Supported engine surfaces
- Super Admin
- Trainer Management
- Trainer Live
- Participant
- Projector
- Course Builder

## Authoring capabilities supplied by ONE
External course packages do not implement these features themselves. Core supplies:
- visual Builder;
- autosave;
- Undo/Redo;
- revision history;
- compare/restore;
- publish readiness;
- asset library + dependency safety;
- reusable templates;
- explicit workflow validation/simulation;
- immutable published versions;
- persisted participant progress/resume;
- class/participant branching;
- Help Queue;
- submission review;
- Projector rendering;
- English LTR / Arabic RTL engine UI;
- responsive rendering.
- private Trainer presenter notes (`cue`, `explanation`, `talking_points`, `expected_answer`, `common_mistakes`, `transition`);
- classroom health/readiness and multiple simultaneous live classes;
- class-scoped Projector pairing and welcome/focus/break/countdown/celebration/blackout screens;
- surveys, question banks/randomized quizzes, prerequisites, waitlists, transcripts and certificates;
- version-to-version impact analytics and course-improvement findings.
