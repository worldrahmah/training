# External ChatGPT Course Development Process

## Recommended conversations
Use separate chats/roles when practical:
1. **Course Architect** — pedagogy, sequence, objectives, timing.
2. **Package Builder** — maps accepted design into exact ONE components/schema.
3. **Independent Reviewer** — checks package/graph/coverage without trusting Builder conclusions.
4. **Class Builder** — prepares class/session/roster/team setup only after course version is accepted.

## Milestone cycle
For each milestone:
1. design;
2. map to ONE components;
3. build package;
4. validate;
5. simulate explicit workflow;
6. independent review;
7. import to a clean ONE Core copy;
8. classroom rehearsal;
9. accept/freeze milestone;
10. proceed to next milestone.

## Do not freeze a future Course Creator against guesses
A separate wizard-style Course Creator may be built later from the exact final ONE schemas/catalog/validator/runtime. This handoff is already aligned to ONE but remains a course-authoring contract, not a license to create an incompatible second model.
