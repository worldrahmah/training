Training Engine v2 schema example fixture.
